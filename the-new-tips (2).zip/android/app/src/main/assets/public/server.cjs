var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// src/lib/seedData.ts
var DEFAULT_COURSES = [
  {
    id: "mern-bootcamp",
    title: "Full-Stack Web Development Bootcamp (MERN Stack)",
    description: "Master HTML, CSS, JavaScript, React 19, Node.js, Express, and MongoDB. Build and deploy real production-ready websites and APIs from scratch.",
    price: 499,
    originalPrice: 4999,
    thumbnail: "https://images.unsplash.com/photo-1547082299-de196ea013d6?q=80&w=600&auto=format&fit=crop",
    category: "DEVELOPMENT",
    lecturesCount: 2,
    filesCount: 3,
    videos: [
      { id: "v1", title: "Getting Started with React 19 & Vite", url: "https://www.youtube.com/watch?v=kYJ462wX1i0" },
      { id: "v2", title: "Express & Node JS Server Setup", url: "https://www.youtube.com/watch?v=ZfKn_7YtK04" },
      { id: "v3", title: "MongoDB Database Integration", url: "https://www.youtube.com/watch?v=kYJ462wX1i0" },
      { id: "v4", title: "Building the UI Components", url: "https://www.youtube.com/watch?v=ZfKn_7YtK04" },
      { id: "v5", title: "Authentication & Deployment", url: "https://www.youtube.com/watch?v=kYJ462wX1i0" }
    ],
    attachments: [
      { id: "a1", name: "React 19 Core Cheat Sheet.pdf", url: "https://raw.githubusercontent.com/duong-g/react-cheat-sheet/master/react-cheat-sheet.pdf", size: "1.2 MB" },
      { id: "a2", name: "Express Boilerplate Architecture Guide.pdf", url: "https://raw.githubusercontent.com/duong-g/react-cheat-sheet/master/react-cheat-sheet.pdf", size: "4.5 MB" },
      { id: "a3", name: "MERN Stack Architecture Roadmap.png", url: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?q=80&w=1200&auto=format&fit=crop", size: "840 KB" },
      { id: "a4", name: "MongoDB Setup Guide.pdf", url: "https://raw.githubusercontent.com/duong-g/react-cheat-sheet/master/react-cheat-sheet.pdf", size: "2.1 MB" },
      { id: "a5", name: "Deployment Checklist.pdf", url: "https://raw.githubusercontent.com/duong-g/react-cheat-sheet/master/react-cheat-sheet.pdf", size: "950 KB" }
    ],
    createdAt: Date.now() - 5 * 24 * 60 * 60 * 1e3
  },
  {
    id: "ai-automation",
    title: "Artificial Intelligence & ChatGPT Automation Guide",
    description: "Learn professional prompt engineering, setting up LLM agent automations, writing custom GPTS, and running high-speed neural networks in custom workflows.",
    price: 199,
    originalPrice: 1999,
    thumbnail: "https://images.unsplash.com/photo-1677442136019-21780efad99a?q=80&w=600&auto=format&fit=crop",
    category: "AI / AUTOMATION",
    lecturesCount: 1,
    filesCount: 2,
    videos: [
      { id: "v1", title: "Automating Workflows with Gemini & ChatGPT API", url: "https://www.youtube.com/watch?v=Ke90Tje7VS0" },
      { id: "v2", title: "Building Custom AI Agents", url: "https://www.youtube.com/watch?v=Ke90Tje7VS0" },
      { id: "v3", title: "Advanced Prompt Engineering", url: "https://www.youtube.com/watch?v=Ke90Tje7VS0" },
      { id: "v4", title: "Integrating LLMs into Web Apps", url: "https://www.youtube.com/watch?v=Ke90Tje7VS0" }
    ],
    attachments: [
      { id: "a1", name: "ChatGPT Prompt Engineering Handbook.pdf", url: "https://static.googleusercontent.com/media/www.google.com/en//webmasters/docs/search-engine-optimization-starter-guide.pdf", size: "2.8 MB" },
      { id: "a2", name: "Gemini API Quickstart Script.js", url: "https://raw.githubusercontent.com/google-gemini/cookbook/main/quickstarts/Gemini_API_Quickstart.ipynb", size: "12 KB" },
      { id: "a3", name: "AI Agent Architecture Guide.pdf", url: "https://static.googleusercontent.com/media/www.google.com/en//webmasters/docs/search-engine-optimization-starter-guide.pdf", size: "1.5 MB" },
      { id: "a4", name: "LLM Integration Checklist.pdf", url: "https://static.googleusercontent.com/media/www.google.com/en//webmasters/docs/search-engine-optimization-starter-guide.pdf", size: "800 KB" }
    ],
    createdAt: Date.now() - 2 * 24 * 60 * 60 * 1e3
  },
  {
    id: "digital-marketing",
    title: "Digital Marketing & Content Mastery",
    description: "Unlock Google Ads, SEO blueprint formulas, copy writing with conversion optimization, and social media organic growth frameworks easily.",
    price: 299,
    originalPrice: 2999,
    thumbnail: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=600&auto=format&fit=crop",
    category: "MARKETING",
    lecturesCount: 2,
    filesCount: 3,
    videos: [
      { id: "v1", title: "SEO Keyword Research Masterclass", url: "https://www.youtube.com/watch?v=9_pco8X5F5E" },
      { id: "v2", title: "High-Converting Landing Page Frameworks", url: "https://www.youtube.com/watch?v=U_P2FNDoMlw" },
      { id: "v3", title: "Google Ads Campaign Setup", url: "https://www.youtube.com/watch?v=9_pco8X5F5E" },
      { id: "v4", title: "Facebook Ads Targeting Strategy", url: "https://www.youtube.com/watch?v=U_P2FNDoMlw" }
    ],
    attachments: [
      { id: "a1", name: "High-Converting Copywriting Templates.docx", url: "https://raw.githubusercontent.com/dianper/copywriting-templates/master/README.md", size: "150 KB" },
      { id: "a2", name: "Google Ads Launch Checklist.xlsx", url: "https://raw.githubusercontent.com/google/google-ads-api-report-templates/main/README.md", size: "220 KB" },
      { id: "a3", name: "Social Media Growth Roadmap.pdf", url: "https://raw.githubusercontent.com/facebook/facebook-nodejs-business-sdk/main/README.md", size: "1.7 MB" },
      { id: "a4", name: "SEO Optimization Guide.pdf", url: "https://raw.githubusercontent.com/facebook/facebook-nodejs-business-sdk/main/README.md", size: "2.5 MB" },
      { id: "a5", name: "Email Marketing Campaign Planner.xlsx", url: "https://raw.githubusercontent.com/facebook/facebook-nodejs-business-sdk/main/README.md", size: "300 KB" }
    ],
    createdAt: Date.now() - 1 * 24 * 60 * 60 * 1e3
  }
];
var DEFAULT_TRANSACTIONS = [
  {
    id: "tx_1",
    studentEmail: "google_student@gmail.com",
    studentName: "Google Student",
    courseId: "mern-bootcamp",
    courseTitle: "Full-Stack Web Development Bootcamp (MERN Stack)",
    amount: 499,
    method: "UPI",
    refUtrId: "5431282781349",
    status: "SUCCESS",
    timestamp: Date.now() - 4 * 3600 * 1e3
  },
  {
    id: "tx_2",
    studentEmail: "satendrlodhi711@gmail.com",
    studentName: "Satendra Lodhi",
    courseId: "mern-bootcamp",
    courseTitle: "Full-Stack Web Development Bootcamp (MERN Stack)",
    amount: 499,
    method: "UPI",
    refUtrId: "247791760872",
    status: "SUCCESS",
    timestamp: Date.now() - 2 * 3600 * 1e3
  },
  {
    id: "tx_3",
    studentEmail: "satendrlodhi711@gmail.com",
    studentName: "Satendra Lodhi",
    courseId: "ai-automation",
    courseTitle: "Artificial Intelligence & ChatGPT Automation Guide",
    amount: 199,
    method: "UPI",
    refUtrId: "904857391039",
    status: "SUCCESS",
    timestamp: Date.now() - 1 * 3600 * 1e3
  },
  {
    id: "tx_4",
    studentEmail: "rahul_kumar@gmail.com",
    studentName: "Rahul Kumar",
    courseId: "mern-bootcamp",
    courseTitle: "Full-Stack Web Development Bootcamp (MERN Stack)",
    amount: 499,
    method: "UPI",
    refUtrId: "103948573920",
    status: "PENDING",
    timestamp: Date.now() - 30 * 60 * 1e3
  }
];

// server.ts
var import_config = require("dotenv/config");
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_razorpay = __toESM(require("razorpay"), 1);
var import_crypto = __toESM(require("crypto"), 1);
var import_cors = __toESM(require("cors"), 1);
var import_node_cron = __toESM(require("node-cron"), 1);
var import_vite = require("vite");
var import_nodemailer = __toESM(require("nodemailer"), 1);
var import_app = require("firebase/app");
var import_firestore = require("firebase/firestore");
var import_fs = __toESM(require("fs"), 1);
var import_genai = require("@google/genai");
var import_pdfkit = __toESM(require("pdfkit"), 1);
var import_multer = __toESM(require("multer"), 1);
var import_app2 = require("firebase-admin/app");
var RAZORPAY_KEY_ID = process.env.RAZORPAY_KEY_ID || "";
var RAZORPAY_KEY_SECRET = process.env.RAZORPAY_KEY_SECRET || "";
var RAZORPAY_WEBHOOK_SECRET = process.env.RAZORPAY_WEBHOOK_SECRET || "";
var firebaseConfig;
try {
  const configFile = import_fs.default.readFileSync(import_path.default.join(process.cwd(), "firebase-applet-config.json"), "utf-8");
  firebaseConfig = JSON.parse(configFile);
  console.log("[DEBUG] Firebase config loaded successfully:", !!firebaseConfig);
} catch (error) {
  console.error("Could not load firebase-applet-config.json", error);
}
var firebaseApp = (0, import_app.initializeApp)(firebaseConfig || {});
var db = (0, import_firestore.initializeFirestore)(firebaseApp, {
  experimentalForceLongPolling: true
}, firebaseConfig?.firestoreDatabaseId);
var existingApp = (0, import_app2.getApps)().find((app) => app.options.projectId === firebaseConfig?.projectId);
var adminInstance = existingApp ? existingApp : firebaseConfig ? (0, import_app2.initializeApp)({
  projectId: firebaseConfig.projectId,
  credential: (0, import_app2.applicationDefault)()
}) : void 0;
if (adminInstance) {
  console.log("[DEBUG] Firebase Admin initialized with project:", firebaseConfig?.projectId);
} else {
  console.log("[DEBUG] Firebase Admin NOT initialized.");
}
var adminDb = void 0;
console.log("[DEBUG] adminDb is bypassed to force reliable, fast client-side SDK usage in server.");
var AdaptiveDocRef = class {
  constructor(clientRef, pathParts) {
    this.clientRef = clientRef;
    this.path = pathParts.filter(Boolean).join("/");
  }
};
var AdaptiveCollectionRef = class {
  constructor(clientRef, pathParts) {
    this.clientRef = clientRef;
    this.path = pathParts.filter(Boolean).join("/");
  }
};
var AdaptiveQuery = class {
  constructor(clientQueryRef, path2, constraints = []) {
    this.clientQueryRef = clientQueryRef;
    this.path = path2;
    this.constraints = constraints;
  }
};
function doc(parent, ...segments) {
  let clientParent = parent;
  let allSegments = [];
  if (parent instanceof AdaptiveCollectionRef) {
    clientParent = parent.clientRef;
    allSegments = [parent.path, ...segments];
  } else if (parent instanceof AdaptiveDocRef) {
    clientParent = parent.clientRef;
    allSegments = [parent.path, ...segments];
  } else {
    allSegments = segments;
  }
  const clientRef = (0, import_firestore.doc)(clientParent, ...segments);
  return new AdaptiveDocRef(clientRef, allSegments);
}
function collection(parent, ...segments) {
  let clientParent = parent;
  let allSegments = [];
  if (parent instanceof AdaptiveDocRef) {
    clientParent = parent.clientRef;
    allSegments = [parent.path, ...segments];
  } else if (parent instanceof AdaptiveCollectionRef) {
    clientParent = parent.clientRef;
    allSegments = [parent.path, ...segments];
  } else {
    allSegments = segments;
  }
  const clientRef = (0, import_firestore.collection)(clientParent, ...segments);
  return new AdaptiveCollectionRef(clientRef, allSegments);
}
function query(colRef, ...constraints) {
  let clientCol = colRef;
  let path2 = "";
  if (colRef instanceof AdaptiveCollectionRef) {
    clientCol = colRef.clientRef;
    path2 = colRef.path;
  } else if (colRef instanceof AdaptiveQuery) {
    clientCol = colRef.clientQueryRef;
    path2 = colRef.path;
  }
  const clientQRef = (0, import_firestore.query)(clientCol, ...constraints.map((c) => c.clientConstraint || c));
  const allConstraints = colRef instanceof AdaptiveQuery ? [...colRef.constraints, ...constraints] : constraints;
  return new AdaptiveQuery(clientQRef, path2, allConstraints);
}
function where(field, opStr, value) {
  const clientConstraint = (0, import_firestore.where)(field, opStr, value);
  return {
    type: "where",
    field,
    opStr,
    value,
    clientConstraint
  };
}
function orderBy(field, direction = "asc") {
  const clientConstraint = (0, import_firestore.orderBy)(field, direction);
  return {
    type: "orderBy",
    field,
    direction,
    clientConstraint
  };
}
async function getDoc(docRef) {
  const path2 = docRef instanceof AdaptiveDocRef ? docRef.path : docRef?.path || "";
  if (adminDb && path2) {
    try {
      const snap = await adminDb.doc(path2).get();
      return {
        exists: () => snap.exists,
        data: () => snap.data(),
        id: snap.id,
        ref: docRef
      };
    } catch (err) {
      console.warn(`[Adaptive DB] Admin fallback to Client for getDoc(${path2}):`, err);
    }
  }
  const clientRef = docRef instanceof AdaptiveDocRef ? docRef.clientRef : docRef;
  return await (0, import_firestore.getDoc)(clientRef);
}
async function getDocs(colOrQuery) {
  let path2 = "";
  let constraints = [];
  if (colOrQuery instanceof AdaptiveCollectionRef) {
    path2 = colOrQuery.path;
  } else if (colOrQuery instanceof AdaptiveQuery) {
    path2 = colOrQuery.path;
    constraints = colOrQuery.constraints;
  }
  if (adminDb && path2) {
    try {
      let queryRef = adminDb.collection(path2);
      for (const c of constraints) {
        if (c.type === "where") {
          queryRef = queryRef.where(c.field, c.opStr, c.value);
        } else if (c.type === "orderBy") {
          queryRef = queryRef.orderBy(c.field, c.direction);
        }
      }
      const snap = await queryRef.get();
      const docs = snap.docs.map((docSnap) => ({
        id: docSnap.id,
        data: () => docSnap.data(),
        ref: docSnap.ref
      }));
      return {
        docs,
        empty: snap.empty,
        forEach: (callback) => docs.forEach(callback),
        size: snap.size
      };
    } catch (err) {
      console.warn(`[Adaptive DB] Admin fallback to Client for getDocs(${path2}):`, err);
    }
  }
  const clientRef = colOrQuery instanceof AdaptiveCollectionRef ? colOrQuery.clientRef : colOrQuery instanceof AdaptiveQuery ? colOrQuery.clientQueryRef : colOrQuery;
  return await (0, import_firestore.getDocs)(clientRef);
}
async function setDoc(docRef, data, options) {
  const path2 = docRef instanceof AdaptiveDocRef ? docRef.path : docRef?.path || "";
  if (adminDb && path2) {
    try {
      await adminDb.doc(path2).set(data, options);
      return;
    } catch (err) {
      console.warn(`[Adaptive DB] Admin fallback to Client for setDoc(${path2}):`, err);
    }
  }
  const clientRef = docRef instanceof AdaptiveDocRef ? docRef.clientRef : docRef;
  return await (0, import_firestore.setDoc)(clientRef, data, options);
}
async function updateDoc(docRef, data) {
  const path2 = docRef instanceof AdaptiveDocRef ? docRef.path : docRef?.path || "";
  if (adminDb && path2) {
    try {
      await adminDb.doc(path2).update(data);
      return;
    } catch (err) {
      console.warn(`[Adaptive DB] Admin fallback to Client for updateDoc(${path2}):`, err);
    }
  }
  const clientRef = docRef instanceof AdaptiveDocRef ? docRef.clientRef : docRef;
  return await (0, import_firestore.updateDoc)(clientRef, data);
}
async function deleteDoc(docRef) {
  const path2 = docRef instanceof AdaptiveDocRef ? docRef.path : docRef?.path || "";
  if (adminDb && path2) {
    try {
      await adminDb.doc(path2).delete();
      return;
    } catch (err) {
      console.warn(`[Adaptive DB] Admin fallback to Client for deleteDoc(${path2}):`, err);
    }
  }
  const clientRef = docRef instanceof AdaptiveDocRef ? docRef.clientRef : docRef;
  return await (0, import_firestore.deleteDoc)(clientRef);
}
function onSnapshot(colOrQuery, callback, errorCallback) {
  let path2 = "";
  let constraints = [];
  if (colOrQuery instanceof AdaptiveCollectionRef) {
    path2 = colOrQuery.path;
  } else if (colOrQuery instanceof AdaptiveQuery) {
    path2 = colOrQuery.path;
    constraints = colOrQuery.constraints;
  }
  if (adminDb && path2) {
    try {
      let queryRef = adminDb.collection(path2);
      for (const c of constraints) {
        if (c.type === "where") {
          queryRef = queryRef.where(c.field, c.opStr, c.value);
        } else if (c.type === "orderBy") {
          queryRef = queryRef.orderBy(c.field, c.direction);
        }
      }
      return queryRef.onSnapshot((adminSnap) => {
        const docs = adminSnap.docs.map((docSnap) => ({
          id: docSnap.id,
          data: () => docSnap.data(),
          ref: docSnap.ref
        }));
        const docChanges = () => adminSnap.docChanges().map((change) => ({
          type: change.type,
          doc: {
            id: change.doc.id,
            data: () => change.doc.data()
          }
        }));
        callback({
          docs,
          empty: adminSnap.empty,
          forEach: (cb) => docs.forEach(cb),
          size: adminSnap.size,
          docChanges
        });
      }, (err) => {
        if (errorCallback) {
          errorCallback(err);
        } else {
          console.error("[Adaptive DB] onSnapshot error:", err);
        }
      });
    } catch (err) {
      console.warn(`[Adaptive DB] Admin fallback to Client for onSnapshot(${path2}):`, err);
    }
  }
  const clientRef = colOrQuery instanceof AdaptiveCollectionRef ? colOrQuery.clientRef : colOrQuery instanceof AdaptiveQuery ? colOrQuery.clientQueryRef : colOrQuery;
  return (0, import_firestore.onSnapshot)(clientRef, callback, errorCallback);
}
async function sendRealSmtpEmail(emailId, emailData) {
  try {
    const settingsDoc = await getDoc(doc(db, "settings", "gateway"));
    const settings = settingsDoc.exists() ? settingsDoc.data() : {};
    const host = process.env.SMTP_HOST || settings?.smtpHost;
    const port = parseInt(process.env.SMTP_PORT || settings?.smtpPort || "587");
    const user = process.env.SMTP_USER || settings?.smtpUser;
    const pass = process.env.SMTP_PASS || settings?.smtpPass;
    const sender = process.env.SMTP_SENDER || settings?.smtpSender || `The New Tips <${user}>`;
    if (!host || !user || !pass) {
      console.log(`[SMTP Daemon] Real email dispatch skipped for ${emailData.recipientEmail}: SMTP is not configured in Settings. (Host: ${host}, User: ${user}, Pass: ${pass ? "HIDDEN" : "MISSING"})`);
      return;
    }
    console.log(`[SMTP Daemon] Dispatching REAL email to ${emailData.recipientEmail} via ${host}:${port} (SSL: ${port === 465})...`);
    const transporter = import_nodemailer.default.createTransport({
      host,
      port,
      secure: port === 465,
      auth: {
        user,
        pass
      },
      tls: {
        rejectUnauthorized: false
      }
    });
    try {
      await transporter.verify();
    } catch (vErr) {
      console.error(`[SMTP Daemon] SMTP Verification failed for ${host}:`, vErr);
      throw new Error(`SMTP Verification failed: ${vErr.message}`);
    }
    const isWelcome = emailData.type === "WELCOME";
    const isNewCourse = emailData.type === "NEW_COURSE";
    const accentColor = isWelcome ? "#4f46e5" : isNewCourse ? "#0ea5e9" : "#10b981";
    const headerTitle = isWelcome ? "Welcome Onboard!" : isNewCourse ? "New Course Alert!" : "Payment Verified";
    const bannerBg = isWelcome ? "linear-gradient(135deg, #4f46e5 0%, #312e81 100%)" : isNewCourse ? "linear-gradient(135deg, #0ea5e9 0%, #0369a1 100%)" : "linear-gradient(135deg, #10b981 0%, #064e3b 100%)";
    const htmlBody = `
      <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #f3f4f6; padding: 40px 20px; color: #1f2937;">
        <div style="max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 24px; overflow: hidden; box-shadow: 0 10px 25px rgba(0,0,0,0.05); border: 1px solid #e5e7eb;">
          <div style="background: ${bannerBg}; padding: 40px; text-align: center; color: #ffffff;">
            <h1 style="margin: 0; font-size: 28px; font-weight: 800; letter-spacing: -0.025em; text-transform: uppercase;">${headerTitle}</h1>
            <p style="margin: 8px 0 0; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.15em; opacity: 0.85;">The New Tips Academic Notification</p>
          </div>
          
          <div style="padding: 40px; line-height: 1.6; font-size: 14px;">
            <p style="margin-top: 0; font-weight: 700; color: #111827; font-size: 16px;">Hello ${emailData.studentName || "Student"},</p>
            <div style="white-space: pre-wrap; color: #374151; margin-bottom: 30px; font-size: 14px;">${emailData.body}</div>
            
            <div style="background-color: #f9fafb; border: 1px dashed #e5e7eb; border-radius: 16px; padding: 20px; text-align: center;">
              <p style="margin: 0 0 10px; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em; color: #6b7280;">Secure Student Portal</p>
              <a href="${process.env.APP_URL || "https://thenewtips.com"}" style="display: inline-block; background-color: ${accentColor}; color: #ffffff; padding: 12px 30px; font-size: 12px; font-weight: 800; text-decoration: none; border-radius: 12px; text-transform: uppercase; letter-spacing: 0.05em;">Access Dashboard</a>
            </div>
          </div>
          
          <div style="background-color: #f9fafb; border-top: 1px solid #e5e7eb; padding: 20px 40px; text-align: center; font-size: 11px; color: #9ca3af;">
            <p style="margin: 0;">This email was sent to ${emailData.recipientEmail} because of an educational trigger.</p>
            <p style="margin: 4px 0 0; font-weight: 700;">&copy; ${(/* @__PURE__ */ new Date()).getFullYear()} The New Tips. All rights reserved.</p>
          </div>
        </div>
      </div>
    `;
    await transporter.sendMail({
      from: sender,
      to: emailData.recipientEmail,
      subject: emailData.subject,
      text: emailData.body,
      html: htmlBody
    });
    console.log(`[SMTP Daemon] Successfully sent REAL email to ${emailData.recipientEmail}!`);
    await updateDoc(doc(db, "email_notifications", emailId), {
      dispatched: true,
      status: "SENT",
      smtpError: null,
      dispatchedAt: Date.now()
    });
  } catch (err) {
    console.error(`[SMTP Daemon] Failed to dispatch REAL email to ${emailData.recipientEmail}:`, err);
    try {
      await updateDoc(doc(db, "email_notifications", emailId), {
        dispatched: false,
        smtpError: err.message || String(err)
      });
    } catch (dbErr) {
      console.error("[SMTP Daemon] Error updating error metadata in DB:", dbErr);
    }
  }
}
var isSmtpInitial = true;
var serverBootTime = Date.now();
console.log("[SMTP Daemon] Activating real-time SMTP dispatch daemon listener...");
onSnapshot(collection(db, "email_notifications"), (snapshot) => {
  if (isSmtpInitial) {
    isSmtpInitial = false;
    console.log("[SMTP Daemon] Initial snapshot loaded. Real-time outbound triggers are now ACTIVE! \u{1F680}");
    return;
  }
  snapshot.docChanges().forEach((change) => {
    if (change.type === "added" || change.type === "modified") {
      const emailData = change.doc.data();
      const isPending = emailData && !emailData.dispatched && !emailData.smtpError;
      const isFresh = emailData.timestamp >= serverBootTime - 24 * 60 * 60 * 1e3;
      if (isPending && isFresh) {
        console.log(`[SMTP Daemon] Detected pending email trigger: ${change.doc.id} for ${emailData.recipientEmail}`);
        sendRealSmtpEmail(change.doc.id, emailData).catch(
          (err) => console.error("[SMTP Daemon] Async dispatch error:", err)
        );
      }
    }
  });
}, (error) => {
  console.error("[SMTP Daemon] Critical onSnapshot listener error:", error);
});
var _aiSecurityAudit = null;
function getAiSecurityAudit() {
  if (!_aiSecurityAudit) {
    const apiKey = (process.env.GEMINI_API_KEY || "").trim();
    if (!apiKey || apiKey === "MISSING") throw new Error("GEMINI_API_KEY is missing from environment. Please add it to your secrets.");
    _aiSecurityAudit = new import_genai.GoogleGenAI({ apiKey, httpOptions: { headers: { "User-Agent": "aistudio-build" } } });
  }
  return _aiSecurityAudit;
}
var _aiBrokenLinkAutoFixer = null;
function getAiBrokenLinkAutoFixer() {
  if (!_aiBrokenLinkAutoFixer) {
    const apiKey = (process.env.GEMINI_API_KEY || "").trim();
    if (!apiKey || apiKey === "MISSING") throw new Error("GEMINI_API_KEY is missing from environment. Please add it to your secrets.");
    _aiBrokenLinkAutoFixer = new import_genai.GoogleGenAI({ apiKey, httpOptions: { headers: { "User-Agent": "aistudio-build" } } });
  }
  return _aiBrokenLinkAutoFixer;
}
var _aiChatSupport = null;
function getAiChatSupport() {
  if (!_aiChatSupport) {
    const apiKey = (process.env.GEMINI_API_KEY || "").trim();
    if (!apiKey || apiKey === "MISSING") throw new Error("GEMINI_API_KEY is missing from environment. Please add it to your secrets.");
    _aiChatSupport = new import_genai.GoogleGenAI({ apiKey, httpOptions: { headers: { "User-Agent": "aistudio-build" } } });
  }
  return _aiChatSupport;
}
var _aiCourseGenerator = null;
function getAiCourseGenerator() {
  if (!_aiCourseGenerator) {
    const apiKey = (process.env.GEMINI_API_KEY || "").trim();
    if (!apiKey || apiKey === "MISSING") throw new Error("GEMINI_API_KEY is missing from environment. Please add it to your secrets.");
    _aiCourseGenerator = new import_genai.GoogleGenAI({ apiKey, httpOptions: { headers: { "User-Agent": "aistudio-build" } } });
  }
  return _aiCourseGenerator;
}
var _hackingAiKey = null;
function getHackingAiKey() {
  if (!_hackingAiKey) {
    const apiKey = (process.env.GEMINI_API_KEY || "").trim();
    if (!apiKey || apiKey === "MISSING") throw new Error("GEMINI_API_KEY is missing/invalid in environment.");
    _hackingAiKey = new import_genai.GoogleGenAI({ apiKey, httpOptions: { headers: { "User-Agent": "aistudio-build" } } });
  }
  return _hackingAiKey;
}
var aiSecurityAudit = { get models() {
  return getAiSecurityAudit().models;
} };
var aiBrokenLinkAutoFixer = { get models() {
  return getAiBrokenLinkAutoFixer().models;
} };
var aiChatSupport = { get models() {
  return getAiChatSupport().models;
} };
var aiCourseGenerator = { get models() {
  return getAiCourseGenerator().models;
} };
var hackingAiKey = { get models() {
  return getHackingAiKey().models;
} };
var apiKeyMetrics = {
  aiSecurityAudit: { lastUsed: null, useCount: 0, limitTotal: 15, limitRemaining: 15, nextReset: Date.now() + 6e4, lastModelUsed: null, nextScheduledRun: "On demand" },
  aiBrokenLinkAutoFixer: { lastUsed: null, useCount: 0, limitTotal: 15, limitRemaining: 15, nextReset: Date.now() + 6e4, lastModelUsed: null, nextScheduledRun: "Every 2 hours automatically" },
  aiChatSupport: { lastUsed: null, useCount: 0, limitTotal: 15, limitRemaining: 15, nextReset: Date.now() + 6e4, lastModelUsed: null, nextScheduledRun: "On student query" },
  aiCourseGenerator: { lastUsed: null, useCount: 0, limitTotal: 15, limitRemaining: 15, nextReset: Date.now() + 6e4, lastModelUsed: null, nextScheduledRun: "Daily at 10:00 AM IST & On demand" },
  masterGeminiKey: { lastUsed: null, useCount: 0, limitTotal: 60, limitRemaining: 60, nextReset: Date.now() + 6e4, lastModelUsed: null, nextScheduledRun: "On demand / Core System" },
  hackingAiKey: { lastUsed: null, useCount: 0, limitTotal: 100, limitRemaining: 100, nextReset: Date.now() + 6e4, lastModelUsed: null, nextScheduledRun: "When generating Hacking courses" }
};
function trackApiCall(serviceName, model) {
  const metrics = apiKeyMetrics[serviceName];
  if (metrics) {
    const now = Date.now();
    if (now > metrics.nextReset) {
      metrics.limitRemaining = metrics.limitTotal;
      metrics.nextReset = now + 6e4;
    }
    metrics.lastUsed = now;
    metrics.useCount += 1;
    metrics.limitRemaining = Math.max(0, metrics.limitRemaining - 1);
    metrics.lastModelUsed = model;
  }
}
var lastAiCallTimestamp = 0;
var MIN_AI_CALL_GAP_MS = 1e4;
var serviceCooldowns = {};
var isGoogleSearchExhausted = true;
async function safeGenerateContent(client, params, retries = 3, delay = 1500) {
  const serviceName = params?.serviceName || "aiCourseGenerator";
  const isSearchActive = params?.tools && JSON.stringify(params.tools).includes("googleSearch") || params?.config?.tools && JSON.stringify(params.config.tools).includes("googleSearch");
  if (isSearchActive && isGoogleSearchExhausted) {
    console.log(`[AI-SEARCH-PREEMPTIVE] Google Search tool is marked as exhausted. Preemptively stripping from request for service: ${serviceName}`);
    params = { ...params };
    if (params.tools) {
      delete params.tools;
    }
    if (params.config) {
      params.config = { ...params.config };
      if (params.config.tools) {
        delete params.config.tools;
      }
    }
  }
  if (!params?._isRetry && serviceCooldowns[serviceName] && Date.now() < serviceCooldowns[serviceName]) {
    throw new Error(`QUOTA_COOLDOWN: Service ${serviceName} is cooling down to prevent rate limit exhaustion. Please wait a few minutes.`);
  }
  const now = Date.now();
  const timeSinceLastCall = now - lastAiCallTimestamp;
  if (timeSinceLastCall < MIN_AI_CALL_GAP_MS) {
    const waitTime = MIN_AI_CALL_GAP_MS - timeSinceLastCall;
    await new Promise((resolve) => setTimeout(resolve, waitTime + Math.floor(Math.random() * 500)));
  }
  lastAiCallTimestamp = Date.now();
  const modelChain = ["gemini-3.5-flash", "gemini-3.1-flash-lite"];
  let currentModel = params?.model || modelChain[0];
  if (currentModel.includes("pro")) {
    currentModel = "gemini-3.5-flash";
  } else if (currentModel.includes("lite") || currentModel.includes("flash-lite")) {
    currentModel = "gemini-3.1-flash-lite";
  } else if (currentModel === "gemini-flash-latest" || currentModel.includes("flash")) {
    currentModel = "gemini-3.5-flash";
  } else {
    currentModel = "gemini-3.5-flash";
  }
  trackApiCall(serviceName, currentModel);
  try {
    const updatedParams = { ...params, model: currentModel };
    if (updatedParams.serviceName) {
      delete updatedParams.serviceName;
    }
    if (!updatedParams.httpOptions) {
      updatedParams.httpOptions = { headers: { "User-Agent": "aistudio-build" } };
    } else if (!updatedParams.httpOptions.headers) {
      updatedParams.httpOptions.headers = { "User-Agent": "aistudio-build" };
    } else {
      updatedParams.httpOptions.headers["User-Agent"] = "aistudio-build";
    }
    if (!updatedParams.config) updatedParams.config = {};
    if (updatedParams.tools) {
      updatedParams.config.tools = updatedParams.tools;
      delete updatedParams.tools;
    }
    updatedParams.config.safetySettings = [
      { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_NONE" },
      { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_NONE" },
      { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_NONE" },
      { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_NONE" }
    ];
    return await client.models.generateContent(updatedParams);
  } catch (error) {
    const errorMsg = error?.message || String(error);
    const statusCode = error?.status || error?.statusCode || error?.code;
    const isQuotaError = statusCode === 429 || statusCode === 503 || statusCode === 404 || errorMsg.includes("429") || errorMsg.includes("RESOURCE_EXHAUSTED") || errorMsg.includes("quota") || errorMsg.includes("Quota") || errorMsg.includes("limit") || errorMsg.includes("503") || errorMsg.includes("not found") || errorMsg.includes("NOT_FOUND");
    const isTimeoutOrFetchError = errorMsg.includes("fetch failed") || errorMsg.includes("Timeout") || errorMsg.includes("timeout") || errorMsg.includes("HeadersTimeoutError") || errorMsg.includes("undici") || errorMsg.includes("connect");
    const hasSearch = params.tools && JSON.stringify(params.tools).includes("googleSearch") || params.config?.tools && JSON.stringify(params.config.tools).includes("googleSearch");
    if (hasSearch && retries > 0) {
      console.log(`[AI-SEARCH-FALLBACK] Retrying without search tool (error detail: ${errorMsg})`);
      isGoogleSearchExhausted = true;
      const nextParams = { ...params, serviceName, _isRetry: true };
      if (nextParams.tools) {
        delete nextParams.tools;
      }
      if (nextParams.config) {
        nextParams.config = { ...nextParams.config };
        if (nextParams.config.tools) {
          delete nextParams.config.tools;
        }
      }
      await new Promise((resolve) => setTimeout(resolve, 1e3));
      return safeGenerateContent(client, nextParams, retries - 1, delay);
    }
    if (isTimeoutOrFetchError) {
      const jitter = Math.floor(Math.random() * 2e3);
      const currentDelay = delay + jitter;
      console.warn(`[AI-TIMEOUT/FETCH] Model ${currentModel} hit timeout/fetch failure (error: ${errorMsg}). Service: ${serviceName}. Retries left: ${retries}`);
      if (retries > 0) {
        const nextParams = { ...params, serviceName, _isRetry: true };
        if (nextParams.config) {
          nextParams.config = { ...nextParams.config };
          if (nextParams.config.tools) {
            delete nextParams.config.tools;
          }
        }
        if (nextParams.tools) {
          delete nextParams.tools;
        }
        console.log(`[Info] Timeout/Fetch failed on model ${currentModel}. Retrying without search/grounding tools in ${currentDelay}ms... (Retries left: ${retries})`);
        await new Promise((resolve) => setTimeout(resolve, currentDelay));
        return safeGenerateContent(client, nextParams, retries - 1, delay * 1.5);
      }
    }
    if (isQuotaError) {
      const jitter = Math.floor(Math.random() * 2e3);
      const currentDelay = delay + jitter;
      console.warn(`[AI-QUOTA/404] Model ${currentModel} hit limit/404 (status: ${statusCode}). Service: ${serviceName}. Retries left: ${retries}`);
      if (modelChain.includes(currentModel)) {
        const currentIndex = modelChain.indexOf(currentModel);
        const nextIndex = (currentIndex + 1) % modelChain.length;
        const nextModel = modelChain[nextIndex];
        if (retries > 0) {
          console.log(`[Info] Model ${currentModel} hit limit/404. Dynamically shifting to ${nextModel}. Retrying in ${currentDelay}ms. (Retries left: ${retries})`);
          const newParams = { ...params, model: nextModel, serviceName, _isRetry: true };
          await new Promise((resolve) => setTimeout(resolve, currentDelay));
          return safeGenerateContent(client, newParams, retries - 1, delay * 1.5);
        }
      }
      if (retries > 0) {
        console.log(`[Info] Rate limited (429/503) on model ${currentModel}. Retrying in ${currentDelay}ms... (Retries left: ${retries})`);
        await new Promise((resolve) => setTimeout(resolve, currentDelay));
        return safeGenerateContent(client, { ...params, model: currentModel, serviceName, _isRetry: true }, retries - 1, delay * 2);
      }
      if (serviceName) {
        console.warn(`[AI-QUOTA-COOLDOWN] Service "${serviceName}" exhausted all retries. Setting a 5-minute cooldown.`);
        serviceCooldowns[serviceName] = Date.now() + 5 * 60 * 1e3;
      }
    }
    console.error(`[AI-FATAL-ERROR] [${serviceName}] [Model: ${currentModel}] Call failed definitively after retries:`, errorMsg);
    if (errorMsg.includes("API key not valid") || errorMsg.includes("INVALID_ARGUMENT")) {
      const keyError = new Error(`INVALID_API_KEY: The API key for ${serviceName} is invalid or has expired.`);
      keyError.status = 400;
      throw keyError;
    }
    throw error;
  }
}
function cleanAndParseJSON(str) {
  if (!str) return {};
  let cleaned = str.trim();
  if (cleaned.includes("```")) {
    const match = cleaned.match(/```(?:json)?\s*([\s\S]*?)```/i);
    if (match && match[1]) {
      cleaned = match[1].trim();
    } else {
      cleaned = cleaned.replace(/```(?:json)?/gi, "").replace(/```/g, "").trim();
    }
  }
  cleaned = cleaned.replace(/\/\*[\s\S]*?\*\/|([^\\:]|^)\/\/.*$/gm, "$1");
  cleaned = cleaned.replace(/,\s*([}\]])/g, "$1");
  try {
    return JSON.parse(cleaned);
  } catch (firstError) {
    try {
      let repaired = cleaned;
      repaired = repaired.replace(/([{,]\s*)'([^']+)'\s*:/g, '$1"$2":');
      repaired = repaired.replace(/([{,]\s*)([a-zA-Z0-9_$]+)\s*:/g, '$1"$2":');
      repaired = repaired.replace(/:\s*'([^']*)'\s*(?=\s*(?:,|\}|\]))/g, ':"$1"');
      repaired = repaired.replace(/:\s*"([\s\S]*?)"\s*(?=\s*(?:,|\}|\]))/g, (match, valContent) => {
        const escapedContent = valContent.replace(/(?<!\\)"/g, '\\"').replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\t/g, "\\t");
        return `: "${escapedContent}"`;
      });
      return JSON.parse(repaired);
    } catch (secondError) {
      try {
        const firstBrace = cleaned.indexOf("{");
        const lastBrace = cleaned.lastIndexOf("}");
        const firstBracket = cleaned.indexOf("[");
        const lastBracket = cleaned.lastIndexOf("]");
        let start = -1;
        let end = -1;
        if (firstBrace !== -1 && (firstBracket === -1 || firstBrace < firstBracket)) {
          start = firstBrace;
          end = lastBrace;
        } else if (firstBracket !== -1) {
          start = firstBracket;
          end = lastBracket;
        }
        if (start !== -1 && end !== -1 && end > start) {
          let extracted = cleaned.substring(start, end + 1);
          extracted = extracted.replace(/,\s*([}\]])/g, "$1");
          extracted = extracted.replace(/([{,]\s*)'([^']+)'\s*:/g, '$1"$2":');
          extracted = extracted.replace(/([{,]\s*)([a-zA-Z0-9_$]+)\s*:/g, '$1"$2":');
          extracted = extracted.replace(/:\s*'([^']*)'\s*(?=\s*(?:,|\}|\]))/g, ':"$1"');
          extracted = extracted.replace(/:\s*"([\s\S]*?)"\s*(?=\s*(?:,|\}|\]))/g, (match, valContent) => {
            const escapedContent = valContent.replace(/(?<!\\)"/g, '\\"').replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\t/g, "\\t");
            return `: "${escapedContent}"`;
          });
          return JSON.parse(extracted);
        }
      } catch (thirdError) {
      }
      console.warn("[JSON-PARSER-WARN] Final parse attempt failed. Chars 0-200:", cleaned.substring(0, 200));
      throw firstError;
    }
  }
}
var withTimeout = (promise, timeoutMs, errorMsg) => {
  return Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error(errorMsg)), timeoutMs))
  ]);
};
var verificationCache = /* @__PURE__ */ new Map();
var CACHE_DURATION = 3e5;
async function verifyVideoUrl(url, itemType) {
  if (!url || typeof url !== "string" || !url.startsWith("http")) {
    return false;
  }
  const cached = verificationCache.get(url);
  if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
    return cached.result;
  }
  const runVerify = async () => {
    if ((itemType === "video" || url.includes("youtube.com") || url.includes("youtu.be")) && !url.includes(".pdf")) {
      try {
        const oembedUrl = `https://www.youtube.com/oembed?url=${encodeURIComponent(url)}`;
        const response = await withTimeout(
          fetch(oembedUrl),
          5e3,
          "YouTube OEmbed Timeout"
        );
        if (response.status === 404 || response.status === 401 || response.status === 403) return false;
        if (!response.ok) return true;
        const data = await response.json();
        if (data.title && data.title.toLowerCase().includes("unavailable")) return false;
        return !!data.html;
      } catch (e) {
        return true;
      }
    }
    try {
      const response = await withTimeout(
        fetch(url, {
          method: "HEAD",
          headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Referer": "https://www.google.com/"
          }
        }),
        5e3,
        "URL Verification Timeout"
      );
      if (response.status === 404 || response.status === 410) return false;
      return true;
    } catch (e) {
      try {
        const response = await withTimeout(
          fetch(url, {
            method: "GET",
            headers: {
              "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
            }
          }),
          5e3,
          "URL Verification Timeout"
        );
        if (response.status === 404 || response.status === 410) return false;
        return true;
      } catch (e2) {
        return true;
      }
    }
  };
  const result = await runVerify();
  verificationCache.set(url, { result, timestamp: Date.now() });
  return result;
}
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = 3e3;
  app.use((0, import_cors.default)());
  app.use(import_express.default.json({
    verify: (req, res, buf) => {
      req.rawBody = buf;
    }
  }));
  app.get("/api/proxy/courses", async (req, res) => {
    try {
      const colRef = collection(db, "courses");
      const snapshot = await getDocs(colRef);
      const courses = [];
      snapshot.forEach((doc2) => {
        courses.push(doc2.data());
      });
      courses.sort((a, b) => b.createdAt - a.createdAt);
      res.json(courses);
    } catch (err) {
      console.error("Error proxying get courses:", err);
      res.status(500).json({ error: err.message });
    }
  });
  app.post("/api/proxy/courses", async (req, res) => {
    try {
      const course = req.body;
      if (!course || !course.id) {
        return res.status(400).json({ error: "Invalid course body" });
      }
      await setDoc(doc(db, "courses", course.id), course);
      res.json({ success: true });
    } catch (err) {
      console.error("Error proxying add course:", err);
      res.status(500).json({ error: err.message });
    }
  });
  app.put("/api/proxy/courses/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      await updateDoc(doc(db, "courses", id), updates);
      res.json({ success: true });
    } catch (err) {
      console.error("Error proxying update course:", err);
      res.status(500).json({ error: err.message });
    }
  });
  app.delete("/api/proxy/courses/:id", async (req, res) => {
    try {
      const { id } = req.params;
      await deleteDoc(doc(db, "courses", id));
      res.json({ success: true });
    } catch (err) {
      console.error("Error proxying delete course:", err);
      res.status(500).json({ error: err.message });
    }
  });
  app.get("/api/proxy/transactions", async (req, res) => {
    try {
      const colRef = collection(db, "transactions");
      const snapshot = await getDocs(colRef);
      const txs = [];
      snapshot.forEach((doc2) => {
        txs.push(doc2.data());
      });
      txs.sort((a, b) => b.timestamp - a.timestamp);
      res.json(txs);
    } catch (err) {
      console.error("Error proxying get transactions:", err);
      res.status(500).json({ error: err.message });
    }
  });
  app.post("/api/proxy/transactions", async (req, res) => {
    try {
      const tx = req.body;
      if (!tx || !tx.id) {
        return res.status(400).json({ error: "Invalid transaction body" });
      }
      await setDoc(doc(db, "transactions", tx.id), tx);
      res.json({ success: true });
    } catch (err) {
      console.error("Error proxying add transaction:", err);
      res.status(500).json({ error: err.message });
    }
  });
  app.put("/api/proxy/transactions/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const txDocRef = doc(db, "transactions", id);
      const txSnap = await getDoc(txDocRef);
      const txData = txSnap.exists() ? txSnap.data() : null;
      await updateDoc(txDocRef, updates);
      if (updates.status === "SUCCESS" && txData && txData.studentEmail && txData.courseId) {
        const studentEmail = txData.studentEmail;
        const courseId = txData.courseId;
        const sanitizedId = studentEmail.toLowerCase().replace(/[^a-zA-Z0-9]/g, "_");
        const userDocRef = doc(db, "app_users", sanitizedId);
        const userDoc = await getDoc(userDocRef);
        const userData = userDoc.exists() ? userDoc.data() : {};
        const unlockedCourses = userData.unlockedCourses || [];
        if (!unlockedCourses.includes(courseId)) {
          unlockedCourses.push(courseId);
          await setDoc(userDocRef, { ...userData, unlockedCourses });
          console.log(`[TRANSACTION PROXY UPDATE] Successfully unlocked course ${courseId} for student ${studentEmail}`);
        }
      }
      res.json({ success: true });
    } catch (err) {
      console.error("Error proxying update transaction:", err);
      res.status(500).json({ error: err.message });
    }
  });
  app.delete("/api/proxy/transactions/:id", async (req, res) => {
    try {
      const { id } = req.params;
      await deleteDoc(doc(db, "transactions", id));
      res.json({ success: true });
    } catch (err) {
      console.error("Error proxying delete transaction:", err);
      res.status(500).json({ error: err.message });
    }
  });
  app.get("/api/proxy/settings/gateway", async (req, res) => {
    try {
      const docRef = doc(db, "settings", "gateway");
      const snap = await getDoc(docRef);
      let data = snap.exists() ? snap.data() : {};
      if (RAZORPAY_KEY_ID) {
        data.razorpayKeyId = RAZORPAY_KEY_ID;
      }
      if (data.razorpayKeySecret || RAZORPAY_KEY_SECRET) {
        data.razorpayKeySecret = "********";
      }
      if (data.razorpayWebhookSecret || RAZORPAY_WEBHOOK_SECRET) {
        data.razorpayWebhookSecret = "********";
      }
      if (data.smtpPass) {
        data.smtpPass = "********";
      }
      if (data.adminPassword) {
        data.adminPassword = "********";
      }
      res.json(data);
    } catch (err) {
      console.error("Error proxying get settings:", err);
      res.status(500).json({ error: err.message });
    }
  });
  app.post("/api/proxy/settings/gateway", async (req, res) => {
    try {
      const newSettings = req.body;
      const docRef = doc(db, "settings", "gateway");
      const snap = await getDoc(docRef);
      const existingSettings = snap.exists() ? snap.data() : {};
      if (newSettings.razorpayKeySecret === "********") {
        newSettings.razorpayKeySecret = existingSettings.razorpayKeySecret || "";
      }
      if (newSettings.razorpayWebhookSecret === "********") {
        newSettings.razorpayWebhookSecret = existingSettings.razorpayWebhookSecret || "";
      }
      if (newSettings.smtpPass === "********") {
        newSettings.smtpPass = existingSettings.smtpPass || "";
      }
      if (newSettings.adminPassword === "********") {
        newSettings.adminPassword = existingSettings.adminPassword || "";
      }
      await setDoc(docRef, newSettings);
      res.json({ success: true });
    } catch (err) {
      console.error("Error proxying update settings:", err);
      res.status(500).json({ error: err.message });
    }
  });
  app.post("/api/proxy/analytics/views", async (req, res) => {
    try {
      const { id, page, courseId, timestamp, user, deviceId } = req.body;
      if (!id) {
        return res.status(400).json({ error: "Missing view ID" });
      }
      await setDoc(doc(db, "analytics_views", id), { id, page, courseId, timestamp, user, deviceId });
      res.json({ success: true });
    } catch (err) {
      console.error("Error proxying log page view:", err);
      res.status(500).json({ error: err.message });
    }
  });
  app.get("/api/proxy/courses/:courseId/reviews", async (req, res) => {
    try {
      const { courseId } = req.params;
      const reviewsRef = collection(db, "courses", courseId, "reviews");
      const q = query(reviewsRef, orderBy("timestamp", "desc"));
      const snapshot = await getDocs(q);
      const reviews = [];
      snapshot.forEach((doc2) => {
        reviews.push(doc2.data());
      });
      res.json(reviews);
    } catch (err) {
      console.error("Error proxying get reviews:", err);
      res.status(500).json({ error: err.message });
    }
  });
  app.post("/api/proxy/courses/:courseId/reviews", async (req, res) => {
    try {
      const { courseId } = req.params;
      const review = req.body;
      if (!review || !review.id) {
        return res.status(400).json({ error: "Invalid review body" });
      }
      await setDoc(doc(db, "courses", courseId, "reviews", review.id), review);
      res.json({ success: true });
    } catch (err) {
      console.error("Error proxying add review:", err);
      res.status(500).json({ error: err.message });
    }
  });
  app.get("/api/proxy/email_notifications", async (req, res) => {
    try {
      const q = query(collection(db, "email_notifications"), orderBy("timestamp", "desc"));
      const snapshot = await getDocs(q);
      const notifications = [];
      snapshot.forEach((doc2) => {
        notifications.push(doc2.data());
      });
      res.json(notifications);
    } catch (err) {
      console.error("Error proxying email notifications:", err);
      res.status(500).json({ error: err.message });
    }
  });
  app.post("/api/proxy/email_notifications", async (req, res) => {
    try {
      const { id, ...data } = req.body;
      await setDoc(doc(db, "email_notifications", id), { id, ...data });
      res.json({ success: true });
    } catch (err) {
      console.error("Error proxying email notifications save:", err);
      res.status(500).json({ error: err.message });
    }
  });
  app.get("/api/proxy/enrollment", async (req, res) => {
    try {
      const { email, courseId } = req.query;
      if (!email || !courseId) {
        return res.status(400).json({ error: "Missing email or courseId query params" });
      }
      const q = query(
        collection(db, "transactions"),
        where("studentEmail", "==", email),
        where("courseId", "==", courseId),
        where("status", "==", "SUCCESS")
      );
      const snapshot = await getDocs(q);
      res.json({ enrolled: !snapshot.empty });
    } catch (err) {
      console.error("Error proxying enrollment check:", err);
      res.status(500).json({ error: err.message });
    }
  });
  app.get("/api/proxy-download", async (req, res) => {
    try {
      const url = req.query.url;
      if (!url) {
        return res.status(400).json({ error: "URL is required." });
      }
      const fileName = url.split("/").pop() || "download.pdf";
      if (url.includes("github.com") || url.includes("figma.com") || url.includes("investopedia.com")) {
        console.warn(`Proxy 400: Blacklisted domain for ${url}`);
        return res.status(400).json({ error: "This is an external resource link, not a direct file. Use window.open instead." });
      }
      try {
        const response = await fetch(url, {
          redirect: "follow",
          headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
          }
        });
        if (response.ok) {
          const contentType = response.headers.get("content-type");
          if (contentType && (contentType.includes("text/html") || contentType.includes("application/xhtml+xml"))) {
            console.warn(`Proxy 400: Content type is HTML for ${url}, type: ${contentType}`);
            return res.status(400).json({ error: "URL points to a webpage, not a direct file." });
          }
          const buffer = Buffer.from(await response.arrayBuffer());
          res.setHeader("Content-Type", contentType || "application/octet-stream");
          res.setHeader("Content-Disposition", `attachment; filename="${fileName}"`);
          return res.send(buffer);
        } else {
          console.warn(`Proxy failed: ${response.status} for ${url}`);
        }
      } catch (fetchErr) {
        console.warn(`Failed to fetch remote URL: ${url}`, fetchErr);
      }
      res.status(404).json({ error: "Direct file not found at this URL." });
    } catch (error) {
      console.error("Error proxying download:", error);
      res.status(500).json({ error: "Failed to download file.", details: error.message });
    }
  });
  app.get("/api/verify-asset", async (req, res) => {
    try {
      const url = req.query.url;
      const type = req.query.type;
      if (!url) {
        return res.status(400).json({ error: "URL is required." });
      }
      const isValid = await verifyVideoUrl(url, type);
      res.json({ isValid });
    } catch (error) {
      console.error("Error verifying asset:", error);
      res.status(500).json({ error: "Failed to verify asset." });
    }
  });
  app.get("/api/courses/:id/download-guide", async (req, res) => {
    try {
      const { id } = req.params;
      const courseDoc = await getDoc(doc(db, "courses", id));
      if (!courseDoc.exists()) {
        return res.status(404).json({ error: "Course not found" });
      }
      const course = courseDoc.data();
      const title = course.title || "The New Tips Premium Course Study Guide";
      const docPdf = new import_pdfkit.default({
        margin: 50,
        info: {
          Title: title,
          Author: "The New Tips Hub",
          Subject: "Course Syllabus Guide and Lectures Index"
        }
      });
      const safeFilename = `${title.replace(/[^a-z0-9]/gi, "_")}_Study_Guide.pdf`;
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename="${safeFilename}"`);
      docPdf.pipe(res);
      docPdf.fontSize(22).fillColor("#1e1b4b").font("Helvetica-Bold").text("THE NEW TIPS", { align: "center" });
      docPdf.fontSize(10).fillColor("#4338ca").font("Helvetica-Oblique").text("Premium Course Study Manual & Verified Curriculum Guide", { align: "center" });
      docPdf.moveDown(1.5);
      const currentY = docPdf.y;
      docPdf.lineWidth(1).strokeColor("#e2e8f0").rect(50, currentY, 512, 55).stroke();
      docPdf.fontSize(11).fillColor("#1e293b").font("Helvetica-Bold").text(`Course: ${course.title}`, 60, currentY + 10);
      docPdf.fontSize(10).fillColor("#64748b").font("Helvetica").text(`Category: ${course.category || "General"}   |   Lectures: ${course.videos?.length || 0} Videos   |   Resources: ${course.attachments?.length || 0} Files`, 60, currentY + 30);
      docPdf.moveDown(3);
      docPdf.font("Helvetica-Bold").fontSize(14).fillColor("#1e1b4b").text("Detailed Step-by-Step Study Guide:", 50);
      docPdf.moveDown(0.5);
      const guideMarkdown = course.guideMarkdown || "Syllabus guidelines are loaded directly inside the portal.";
      const enrichedMarkdown = enrichSyllabusAndSummariesInHindi({
        ...course,
        guideMarkdown
      });
      const sanitizeForPdf = (text) => {
        return text.replace(/[^\x00-\x7F]/g, "");
      };
      const lines = enrichedMarkdown.split("\n");
      lines.forEach((line) => {
        const trimmed = line.trim();
        if (!trimmed) {
          docPdf.moveDown(0.5);
          return;
        }
        if (trimmed.startsWith("# ")) {
          docPdf.moveDown(1);
          docPdf.font("Helvetica-Bold").fontSize(15).fillColor("#1e1b4b").text(sanitizeForPdf(trimmed.replace("# ", "")), 50);
          docPdf.moveDown(0.3);
        } else if (trimmed.startsWith("## ")) {
          docPdf.moveDown(1);
          docPdf.font("Helvetica-Bold").fontSize(13).fillColor("#4338ca").text(sanitizeForPdf(trimmed.replace("## ", "")), 50);
          docPdf.moveDown(0.3);
        } else if (trimmed.startsWith("### ")) {
          docPdf.moveDown(0.8);
          docPdf.font("Helvetica-Bold").fontSize(11).fillColor("#1e293b").text(sanitizeForPdf(trimmed.replace("### ", "")), 50);
          docPdf.moveDown(0.2);
        } else if (trimmed.startsWith("* ") || trimmed.startsWith("- ")) {
          docPdf.font("Helvetica").fontSize(10).fillColor("#334155");
          const cleanText = trimmed.substring(2).replace(/\*\*/g, "").replace(/\*/g, "");
          docPdf.text(`  \u2022  ${sanitizeForPdf(cleanText)}`, { align: "justify", lineGap: 3 });
        } else {
          docPdf.font("Helvetica").fontSize(10).fillColor("#334155");
          const cleanText = trimmed.replace(/\*\*/g, "").replace(/\*/g, "");
          docPdf.text(sanitizeForPdf(cleanText), { align: "justify", lineGap: 3 });
        }
      });
      docPdf.moveDown(2);
      docPdf.fontSize(10).fillColor("#94a3b8").font("Helvetica-Oblique").text("============================================================", { align: "center" });
      docPdf.text("All materials, video guides, and downloads are fully verified & live!", { align: "center" });
      docPdf.text("Thank you for choosing The New Tips. Happy Learning!", { align: "center" });
      docPdf.text("============================================================", { align: "center" });
      docPdf.end();
    } catch (error) {
      console.error("Error serving download guide PDF:", error);
      res.status(500).json({ error: "Failed to generate download guide PDF.", details: error.message });
    }
  });
  app.post("/api/checkout/order", async (req, res) => {
    try {
      const { amount, currency, notes } = req.body;
      if (amount === void 0 || amount === null || isNaN(Number(amount))) {
        console.error("[CHECKOUT ORDER] Invalid or missing amount:", amount);
        return res.status(400).json({ error: "A valid amount is required to create a checkout order." });
      }
      const parsedAmount = Number(amount);
      const settingsDoc = await getDoc(doc(db, "settings", "gateway"));
      const dbSettings = settingsDoc.exists() ? settingsDoc.data() : null;
      const keyId = (RAZORPAY_KEY_ID || dbSettings?.razorpayKeyId || "").trim();
      const keySecret = (RAZORPAY_KEY_SECRET || dbSettings?.razorpayKeySecret || "").trim();
      if (!keyId || !keySecret) {
        console.warn("Razorpay credentials missing. Falling back to mock order.");
        return res.json({
          id: `order_mock_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
          amount: Math.round(parsedAmount * 100),
          currency: currency || "INR",
          isMock: true
        });
      }
      try {
        console.log("Attempting Razorpay order creation with key_id:", keyId.substring(0, 4) + "****");
        const razorpay = new import_razorpay.default({
          key_id: keyId,
          key_secret: keySecret
        });
        const options = {
          amount: Math.round(parsedAmount * 100),
          // Razorpay expects amount in paise
          currency: currency || "INR",
          receipt: `receipt_${Date.now()}`,
          notes: notes || {}
        };
        const order = await razorpay.orders.create(options);
        res.json({ ...order, isMock: false });
      } catch (rzpError) {
        console.error("Razorpay orders.create failed, falling back to mock order:", rzpError);
        res.json({
          id: `order_mock_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
          amount: Math.round(parsedAmount * 100),
          currency: currency || "INR",
          isMock: true,
          errorInfo: rzpError?.message || String(rzpError)
        });
      }
    } catch (error) {
      console.error("Error creating Razorpay order:", error);
      res.status(500).json({ error: "Could not create order", details: error?.error?.description || error?.message || String(error) });
    }
  });
  const logSimulatedEmail = async (transactionId, recipientEmail, studentName, courseTitle, amount, type, status) => {
    try {
      const emailId = `email_${type.toLowerCase()}_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
      let subject = "";
      let body = "";
      if (type === "WELCOME") {
        subject = `Welcome to "${courseTitle}"! \u{1F680}`;
        body = `Hi ${studentName},

Thank you for purchasing "${courseTitle}"! We are thrilled to have you onboard.

You can access your lectures and downloadable reference guides from your dashboard anytime.

Best regards,
The New Tips Team`;
      } else {
        subject = `Payment Verified: Course Unlocked! \u2705`;
        body = `Hi ${studentName},

Good news! Your transaction (ID: ${transactionId}) of \u20B9${amount} for "${courseTitle}" has been verified successfully. Your access is fully unlocked!

Start learning now: https://thenewtips.com/dashboard

Best regards,
The New Tips Team`;
      }
      await setDoc(doc(db, "email_notifications", emailId), {
        id: emailId,
        transactionId,
        recipientEmail,
        studentName,
        courseTitle,
        type,
        subject,
        body,
        status,
        timestamp: Date.now()
      });
    } catch (err) {
      console.error("Failed to log simulated email in server:", err);
    }
  };
  const logSimulatedNewCourseEmail = async (courseTitle, price) => {
    try {
      const txsSnapshot = await getDocs(collection(db, "transactions"));
      const studentEmails = /* @__PURE__ */ new Set();
      txsSnapshot.forEach((docSnap) => {
        const t = docSnap.data();
        if (t.studentEmail) {
          studentEmails.add(t.studentEmail.trim().toLowerCase());
        }
      });
      if (studentEmails.size === 0) {
        studentEmails.add("student@thenewtips.com");
      }
      for (const email of studentEmails) {
        const emailId = `email_newcourse_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
        const studentName = email.split("@")[0] || "Student";
        await setDoc(doc(db, "email_notifications", emailId), {
          id: emailId,
          transactionId: "N/A",
          recipientEmail: email,
          studentName,
          courseTitle,
          type: "NEW_COURSE",
          subject: `New Course Released: "${courseTitle}"! \u{1F393}`,
          body: `Hi ${studentName},

We have exciting news! A brand new premium course has just been published on our platform.

Course Title: "${courseTitle}"
Price: \u20B9${price}

Check it out and enroll today to start mastering this topic!

Best regards,
The New Tips Team`,
          status: "SENT",
          timestamp: Date.now()
        });
      }
    } catch (err) {
      console.error("Failed to log simulated new course email:", err);
    }
  };
  app.post("/api/checkout/verify", async (req, res) => {
    try {
      const {
        razorpay_order_id,
        razorpay_payment_id,
        razorpay_signature,
        studentEmail,
        courseId,
        courseTitle,
        amount,
        courses
        // Optional array of courses for bulk checkout
      } = req.body;
      if (!studentEmail) {
        console.error("[CHECKOUT VERIFY] Missing student email");
        return res.status(400).json({ success: false, error: "Student email is required for payment verification." });
      }
      const normalizedEmail = studentEmail.toLowerCase().trim();
      const isMockPayment = razorpay_signature === "mock_signature_approved" || razorpay_order_id && razorpay_order_id.startsWith("order_mock_");
      let isSignatureValid = false;
      if (isMockPayment) {
        const settingsDoc = await getDoc(doc(db, "settings", "gateway"));
        const dbSettings = settingsDoc.exists() ? settingsDoc.data() : null;
        if (dbSettings?.isLiveMode) {
          console.error("[CHECKOUT VERIFY] Attempted mock payment in LIVE mode.");
          return res.status(403).json({ success: false, error: "Mock payments are not allowed in live mode." });
        }
        isSignatureValid = true;
      } else {
        const settingsDoc = await getDoc(doc(db, "settings", "gateway"));
        const dbSettings = settingsDoc.exists() ? settingsDoc.data() : null;
        const keySecret = (RAZORPAY_KEY_SECRET || dbSettings?.razorpayKeySecret || "").trim();
        if (keySecret) {
          const body = razorpay_order_id + "|" + razorpay_payment_id;
          const expectedSignature = import_crypto.default.createHmac("sha256", keySecret).update(body.toString()).digest("hex");
          isSignatureValid = expectedSignature === razorpay_signature;
        }
      }
      if (isSignatureValid) {
        let finalCourseId = courseId;
        let finalCourseTitle = courseTitle;
        let finalCourses = courses;
        if (!isMockPayment && (!finalCourseId && (!finalCourses || finalCourses.length === 0))) {
          try {
            const settingsDoc = await getDoc(doc(db, "settings", "gateway"));
            const dbSettings = settingsDoc.exists() ? settingsDoc.data() : null;
            const keyId = (RAZORPAY_KEY_ID || dbSettings?.razorpayKeyId || "").trim();
            const keySecret = (RAZORPAY_KEY_SECRET || dbSettings?.razorpayKeySecret || "").trim();
            if (keyId && keySecret) {
              const razorpay = new import_razorpay.default({
                key_id: keyId,
                key_secret: keySecret
              });
              const rzpOrder = await razorpay.orders.fetch(razorpay_order_id);
              if (rzpOrder && rzpOrder.notes) {
                const notes = rzpOrder.notes;
                if (notes.coursesJson) {
                  try {
                    finalCourses = JSON.parse(String(notes.coursesJson));
                  } catch (e) {
                    console.error("JSON parse error for notes.coursesJson:", e);
                  }
                }
                if (notes.courseId) {
                  finalCourseId = String(notes.courseId);
                  finalCourseTitle = String(notes.courseTitle);
                }
              }
            }
          } catch (orderFetchErr) {
            console.error("Failed to fetch Razorpay order notes during verification:", orderFetchErr);
          }
        }
        const sanitizedId = normalizedEmail.replace(/[^a-zA-Z0-9]/g, "_");
        const userDocRef = doc(db, "app_users", sanitizedId);
        const userDoc = await getDoc(userDocRef);
        const userData = userDoc.exists() ? userDoc.data() : {};
        const unlockedCourses = userData.unlockedCourses || [];
        const studentName = userData.displayName || userData.fullName || normalizedEmail.split("@")[0] || "Student";
        if (finalCourses && Array.isArray(finalCourses) && finalCourses.length > 0) {
          for (let i = 0; i < finalCourses.length; i++) {
            const c = finalCourses[i];
            const txId = `txn_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
            await setDoc(doc(db, "transactions", txId), {
              id: txId,
              studentEmail: normalizedEmail,
              studentName,
              courseId: c.id,
              courseTitle: c.title,
              amount: c.price,
              status: "SUCCESS",
              method: isMockPayment ? "Simulated API (Auto-Confirm)" : "Razorpay API",
              referenceId: razorpay_payment_id || `pay_mock_${Date.now()}`,
              timestamp: Date.now()
            });
            if (!unlockedCourses.includes(c.id)) {
              unlockedCourses.push(c.id);
            }
            await logSimulatedEmail(txId, normalizedEmail, studentName, c.title, c.price, "WELCOME", "SENT");
            await logSimulatedEmail(txId, normalizedEmail, studentName, c.title, c.price, "VERIFICATION", "SENT");
          }
          await setDoc(userDocRef, { ...userData, unlockedCourses });
        } else if (finalCourseId) {
          const txId = `txn_${Date.now()}`;
          await setDoc(doc(db, "transactions", txId), {
            id: txId,
            studentEmail: normalizedEmail,
            studentName,
            courseId: finalCourseId,
            courseTitle: finalCourseTitle,
            amount: amount || 0,
            status: "SUCCESS",
            method: isMockPayment ? "Simulated API (Auto-Confirm)" : "Razorpay API",
            referenceId: razorpay_payment_id || `pay_mock_${Date.now()}`,
            timestamp: Date.now()
          });
          if (!unlockedCourses.includes(finalCourseId)) {
            unlockedCourses.push(finalCourseId);
            await setDoc(userDocRef, { ...userData, unlockedCourses });
          }
          await logSimulatedEmail(txId, normalizedEmail, studentName, finalCourseTitle, amount || 0, "WELCOME", "SENT");
          await logSimulatedEmail(txId, normalizedEmail, studentName, finalCourseTitle, amount || 0, "VERIFICATION", "SENT");
        }
        res.json({ success: true, message: "Payment verified and course(s) unlocked successfully!" });
      } else {
        res.status(400).json({ success: false, error: "Invalid payment signature." });
      }
    } catch (error) {
      console.error("Error verifying payment:", error);
      res.status(500).json({ error: "Server error during verification." });
    }
  });
  app.post("/api/checkout/webhook", async (req, res) => {
    try {
      const signature = req.headers["x-razorpay-signature"];
      if (!signature) {
        console.error("[RAZORPAY WEBHOOK] Missing x-razorpay-signature header");
        return res.status(400).json({ error: "Missing webhook signature" });
      }
      const settingsDoc = await getDoc(doc(db, "settings", "gateway"));
      const dbSettings = settingsDoc.exists() ? settingsDoc.data() : null;
      const secret = (RAZORPAY_WEBHOOK_SECRET || dbSettings?.razorpayWebhookSecret || process.env.RAZORPAY_WEBHOOK_SECRET || "").trim();
      if (!secret) {
        console.warn("[RAZORPAY WEBHOOK] Webhook Secret not configured in Settings. Proceeding for direct/local setup.");
      } else {
        const payloadStr = req.rawBody ? req.rawBody.toString("utf-8") : JSON.stringify(req.body);
        const expectedSignature = import_crypto.default.createHmac("sha256", secret).update(payloadStr).digest("hex");
        if (expectedSignature !== signature) {
          console.error("[RAZORPAY WEBHOOK] Signature verification failed. Expected vs Received mismatch.");
          return res.status(400).json({ error: "Signature verification failed" });
        }
        console.log("[RAZORPAY WEBHOOK] Webhook signature verified successfully!");
      }
      const { event, payload } = req.body;
      console.log(`[RAZORPAY WEBHOOK] Received event: ${event} | ID: ${payload?.payment?.entity?.id || payload?.order?.entity?.id}`);
      if (event === "payment.captured" || event === "order.paid") {
        const entity = event === "payment.captured" ? payload.payment.entity : payload.order.entity;
        let notes = entity.notes || {};
        let studentEmail = notes.studentEmail;
        let courseId = notes.courseId;
        let courseTitle = notes.courseTitle;
        let coursesJson = notes.coursesJson;
        const orderId = entity.order_id || (event === "order.paid" ? entity.id : null);
        if (!studentEmail && orderId) {
          try {
            console.log(`[RAZORPAY WEBHOOK] Missing studentEmail in notes. Attempting order notes fetch fallback for order_id: ${orderId}`);
            const keyId = (RAZORPAY_KEY_ID || dbSettings?.razorpayKeyId || "").trim();
            const keySecret = (RAZORPAY_KEY_SECRET || dbSettings?.razorpayKeySecret || "").trim();
            if (keyId && keySecret) {
              const razorpay = new import_razorpay.default({
                key_id: keyId,
                key_secret: keySecret
              });
              const rzpOrder = await razorpay.orders.fetch(orderId);
              if (rzpOrder && rzpOrder.notes) {
                notes = rzpOrder.notes;
                studentEmail = notes.studentEmail;
                courseId = notes.courseId;
                courseTitle = notes.courseTitle;
                coursesJson = notes.coursesJson;
                console.log(`[RAZORPAY WEBHOOK] Successfully retrieved notes from order fallback. Email: ${studentEmail}, CourseID: ${courseId}`);
              }
            }
          } catch (orderFetchErr) {
            console.error("[RAZORPAY WEBHOOK] Failed to fetch Razorpay order notes during fallback:", orderFetchErr);
          }
        }
        console.log(`[RAZORPAY WEBHOOK] Fulfillment metadata: Email: ${studentEmail}, CourseID: ${courseId}, Title: ${courseTitle}`);
        if (!studentEmail) {
          console.warn("[RAZORPAY WEBHOOK] Missing studentEmail in metadata notes. Full Entity:", JSON.stringify(entity, null, 2));
          return res.json({ status: "skipped", message: "Missing studentEmail in notes" });
        }
        const razorpay_payment_id = event === "payment.captured" ? entity.id : entity.payment_id || `wh_pay_${Date.now()}`;
        const amount = entity.amount ? entity.amount / 100 : 0;
        const sanitizedId = studentEmail.toLowerCase().replace(/[^a-zA-Z0-9]/g, "_");
        const userDocRef = doc(db, "app_users", sanitizedId);
        const userDoc = await getDoc(userDocRef);
        const userData = userDoc.exists() ? userDoc.data() : {};
        const unlockedCourses = userData.unlockedCourses || [];
        const studentName = userData.displayName || userData.fullName || studentEmail.split("@")[0] || "Student";
        let coursesList = [];
        if (coursesJson) {
          try {
            coursesList = JSON.parse(coursesJson);
          } catch (e) {
            console.error("[RAZORPAY WEBHOOK] JSON parse error for courses:", e);
          }
        }
        if (coursesList.length > 0) {
          for (const c of coursesList) {
            const txId = `txn_wh_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
            await setDoc(doc(db, "transactions", txId), {
              id: txId,
              studentEmail,
              studentName,
              courseId: c.id,
              courseTitle: c.title,
              amount: c.price,
              status: "SUCCESS",
              method: "Razorpay",
              refUtrId: razorpay_payment_id,
              referenceId: razorpay_payment_id,
              timestamp: Date.now()
            });
            if (!unlockedCourses.includes(c.id)) {
              unlockedCourses.push(c.id);
            }
            await logSimulatedEmail(txId, studentEmail, studentName, c.title, c.price, "WELCOME", "SENT");
            await logSimulatedEmail(txId, studentEmail, studentName, c.title, c.price, "VERIFICATION", "SENT");
          }
          await setDoc(userDocRef, { ...userData, unlockedCourses });
          console.log(`[RAZORPAY WEBHOOK] Bulk fulfillment successful for ${studentEmail}`);
        } else if (courseId) {
          const txId = `txn_wh_${Date.now()}`;
          await setDoc(doc(db, "transactions", txId), {
            id: txId,
            studentEmail,
            studentName,
            courseId,
            courseTitle,
            amount,
            status: "SUCCESS",
            method: "Razorpay",
            refUtrId: razorpay_payment_id,
            referenceId: razorpay_payment_id,
            timestamp: Date.now()
          });
          if (!unlockedCourses.includes(courseId)) {
            unlockedCourses.push(courseId);
            await setDoc(userDocRef, { ...userData, unlockedCourses });
            console.log(`[RAZORPAY WEBHOOK] Fulfillment successful for ${studentEmail} | Course: ${courseTitle}`);
          }
          await logSimulatedEmail(txId, studentEmail, studentName, courseTitle, amount, "WELCOME", "SENT");
          await logSimulatedEmail(txId, studentEmail, studentName, courseTitle, amount, "VERIFICATION", "SENT");
        }
        console.log(`[RAZORPAY WEBHOOK] Successful auto-unlock for: ${studentEmail}`);
        return res.json({ success: true, message: "Webhook payment processed, course unlocked." });
      }
      res.json({ success: true, message: "Webhook received but not an enrollment event." });
    } catch (err) {
      console.error("[RAZORPAY WEBHOOK] Process failed:", err);
      res.status(500).json({ error: "Webhook handler failed", details: err.message });
    }
  });
  const storage = import_multer.default.diskStorage({
    destination: (req, file, cb) => {
      const uploadsDir = import_path.default.join(process.cwd(), "uploads");
      if (!import_fs.default.existsSync(uploadsDir)) {
        import_fs.default.mkdirSync(uploadsDir, { recursive: true });
      }
      cb(null, uploadsDir);
    },
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
      const ext = import_path.default.extname(file.originalname);
      const baseName = import_path.default.basename(file.originalname, ext).replace(/[^a-zA-Z0-9]/g, "_");
      cb(null, `${baseName}-${uniqueSuffix}${ext}`);
    }
  });
  const upload = (0, import_multer.default)({
    storage,
    limits: { fileSize: 100 * 1024 * 1024 }
    // 100MB limit
  });
  app.post("/api/admin/upload", upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ success: false, error: "No file uploaded." });
      }
      const bytes = req.file.size;
      let sizeStr = "0 Bytes";
      if (bytes > 0) {
        const k = 1024;
        const dm = 1;
        const sizes = ["Bytes", "KB", "MB", "GB"];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        sizeStr = parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + " " + sizes[i];
      }
      const fileUrl = `/uploads/${req.file.filename}`;
      res.json({
        success: true,
        url: fileUrl,
        name: req.file.originalname,
        size: sizeStr
      });
    } catch (err) {
      console.error("Upload error:", err);
      res.status(500).json({ success: false, error: err.message || String(err) });
    }
  });
  app.get("/api/admin/ai-api-status", async (req, res) => {
    try {
      const keysToTrack = [
        { id: "masterGeminiKey", name: "Master Gemini API Key", purpose: "Primary Master Key powering all standard Gemini AI requests, chats, and automated course creations.", key: (process.env.GEMINI_API_KEY || "MISSING").substring(0, 10) + "...", limit: "60 RPM" },
        { id: "hackingAiKey", name: "Hacker AI Engine API Key", purpose: "Powers step-by-step PDF manuals, cybersecurity notebooks, and automated hacking course writers.", key: (process.env.HACKER_AI_KEY || process.env.GEMINI_API_KEY || "MISSING").substring(0, 10) + "...", limit: "100 RPM" },
        { id: "aiSecurityAudit", name: "Security Audit Key", purpose: "Used for system health check and finding vulnerabilities.", key: (process.env.GEMINI_API_KEY || "MISSING").substring(0, 10) + "...", limit: "Free Tier Defaults" },
        { id: "aiBrokenLinkAutoFixer", name: "Broken Link Fixer Key", purpose: "Auto-fixes broken video and attachment links.", key: (process.env.GEMINI_API_KEY || "MISSING").substring(0, 10) + "...", limit: "Free Tier Defaults" },
        { id: "aiChatSupport", name: "Chat Support Key", purpose: "Powers the real-time student AI chat assistant.", key: (process.env.GEMINI_API_KEY || "MISSING").substring(0, 10) + "...", limit: "Free Tier Defaults" },
        { id: "aiCourseGenerator", name: "Course Generator Key", purpose: "Generates new courses based on topics using AI.", key: (process.env.GEMINI_API_KEY || "MISSING").substring(0, 10) + "...", limit: "Free Tier Defaults" }
      ];
      const results = await Promise.all(keysToTrack.map(async (keyObj) => {
        const liveMetrics = apiKeyMetrics[keyObj.id] || { lastUsed: null, useCount: 0, limitTotal: 15, limitRemaining: 15, nextReset: Date.now() + 6e4, lastModelUsed: null, nextScheduledRun: "On demand" };
        const now = Date.now();
        let secondsUntilReset = Math.ceil((liveMetrics.nextReset - now) / 1e3);
        if (secondsUntilReset < 0) {
          liveMetrics.limitRemaining = liveMetrics.limitTotal;
          liveMetrics.nextReset = now + 6e4;
          secondsUntilReset = 60;
        }
        let isConfigured = false;
        if (keyObj.id === "hackingAiKey") {
          isConfigured = !!(process.env.HACKER_AI_KEY || process.env.GEMINI_API_KEY);
        } else {
          isConfigured = !!process.env.GEMINI_API_KEY;
        }
        const status = isConfigured ? "Active (Working)" : "Offline (Key Missing)";
        const errors = isConfigured ? "None" : `CRITICAL: ${keyObj.id === "hackingAiKey" ? "HACKER_AI_KEY" : "GEMINI_API_KEY"} environment variable is not set. AI features will fail.`;
        return {
          id: keyObj.id,
          name: keyObj.name,
          purpose: keyObj.purpose,
          status,
          errors,
          limitTotal: liveMetrics.limitTotal,
          limitRemaining: liveMetrics.limitRemaining,
          secondsUntilReset,
          useCount: liveMetrics.useCount,
          lastUsed: liveMetrics.lastUsed,
          lastModelUsed: liveMetrics.lastModelUsed || (keyObj.id === "hackingAiKey" ? "hacker-pdf-v1" : "None yet"),
          nextScheduledRun: liveMetrics.nextScheduledRun
        };
      }));
      res.json({ success: true, keys: results });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  });
  app.post("/api/admin/ping-key", async (req, res) => {
    try {
      const { id } = req.body;
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.status(401).json({ success: false, message: "AI API Key missing. Please add GEMINI_API_KEY to your secrets." });
      }
      if (id === "hackingAiKey") {
        const rawHKey = (process.env.HACKER_AI_KEY || "").trim();
        const isGeminiCompatible = rawHKey.startsWith("AIzaSy");
        const hKey = isGeminiCompatible ? rawHKey : (process.env.GEMINI_API_KEY || "").trim();
        if (!hKey || hKey === "MISSING") {
          return res.status(401).json({ success: false, message: "Hacker AI API Key / Fallback Gemini Key missing. Please check your secrets." });
        }
        const aiCheck2 = new import_genai.GoogleGenAI({ apiKey: hKey, httpOptions: { headers: { "User-Agent": "aistudio-build" } } });
        await safeGenerateContent(aiCheck2, {
          model: "gemini-3.5-flash",
          contents: "Respond with 'ok'",
          serviceName: id
        });
        const metrics2 = apiKeyMetrics[id];
        if (metrics2) {
          metrics2.lastUsed = Date.now();
          metrics2.useCount += 1;
          metrics2.lastModelUsed = "gemini-3.5-flash";
        }
        const displayKey = rawHKey ? rawHKey : hKey;
        const note = isGeminiCompatible ? `Hacker AI Engine is authorized and responding live.` : `Custom Hacker AI key configured. Falls back to Core Gemini Engine for generation.`;
        return res.json({
          success: true,
          message: `Ping successful! ${note} (Key: ${displayKey.substring(0, 10)}...)`
        });
      }
      if (id === "masterGeminiKey") {
        const aiCheck2 = new import_genai.GoogleGenAI({ apiKey, httpOptions: { headers: { "User-Agent": "aistudio-build" } } });
        await safeGenerateContent(aiCheck2, {
          model: "gemini-3.5-flash",
          contents: "Respond with 'ok'",
          serviceName: id
        });
        const metrics2 = apiKeyMetrics[id];
        if (metrics2) {
          metrics2.lastUsed = Date.now();
          metrics2.useCount += 1;
          metrics2.lastModelUsed = "gemini-3.5-flash";
        }
        return res.json({ success: true, message: "Ping successful! Master Gemini API Key is fully active and working live." });
      }
      const aiCheck = new import_genai.GoogleGenAI({ apiKey, httpOptions: { headers: { "User-Agent": "aistudio-build" } } });
      console.log(`[PING-TEST] Pinging service: ${id}`);
      await safeGenerateContent(aiCheck, {
        model: "gemini-3.5-flash",
        contents: "Respond with 'ok'",
        serviceName: id
      });
      const metrics = apiKeyMetrics[id];
      if (metrics) {
        metrics.lastUsed = Date.now();
      }
      res.json({ success: true, message: "Ping successful! Service is 100% active and working live." });
    } catch (err) {
      console.error("[PING-ERROR]", err);
      const errorMsg = err.message || String(err);
      let userFriendlyError = errorMsg;
      if (errorMsg.includes("API key not valid") || errorMsg.includes("INVALID_ARGUMENT") || errorMsg.includes("INVALID_API_KEY")) {
        userFriendlyError = "CRITICAL: The API Key is invalid. Please check your secrets and ensure the key is copied correctly with no extra spaces.";
      } else if (errorMsg.includes("429") || errorMsg.includes("QUOTA")) {
        userFriendlyError = "Rate limit reached for this key. Please try again in 60 seconds.";
      }
      res.status(500).json({
        success: false,
        errors: userFriendlyError
      });
    }
  });
  app.post("/api/admin/test-smtp", async (req, res) => {
    try {
      const { smtpHost, smtpPort, smtpUser, smtpPass, smtpSender, testRecipient } = req.body;
      if (!smtpHost || !smtpUser || !smtpPass) {
        return res.status(400).json({ success: false, error: "Required fields missing. Please provide SMTP Host, Username and Password." });
      }
      const port = parseInt(smtpPort || "587");
      const sender = smtpSender || `The New Tips <${smtpUser}>`;
      const recipient = testRecipient || smtpUser;
      console.log(`[SMTP Test API] Testing SMTP connection via ${smtpHost}:${port}...`);
      const transporter = import_nodemailer.default.createTransport({
        host: smtpHost,
        port,
        secure: port === 465,
        auth: {
          user: smtpUser,
          pass: smtpPass
        },
        tls: {
          rejectUnauthorized: false
        }
      });
      await transporter.verify();
      console.log(`[SMTP Test API] Connection verified. Dispatching test email to ${recipient}...`);
      await transporter.sendMail({
        from: sender,
        to: recipient,
        subject: "SMTP Real Connection Test: SUCCESS! \u2705",
        text: "Congratulations! Your SMTP settings are correctly configured. Real outbound emails will now be dispatched automatically to all students on register, welcome alerts, and course releases.",
        html: `
          <div style="font-family: -apple-system, BlinkMacSystemFont, sans-serif; background-color: #f3f4f6; padding: 40px 20px;">
            <div style="max-width: 550px; margin: 0 auto; background-color: #ffffff; border-radius: 20px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.05); border: 1px solid #e5e7eb;">
              <div style="background: linear-gradient(135deg, #4f46e5 0%, #312e81 100%); padding: 35px; text-align: center; color: #ffffff;">
                <h1 style="margin: 0; font-size: 24px; font-weight: 800; text-transform: uppercase; letter-spacing: -0.01em;">SMTP Connected Successfully! \u2705</h1>
                <p style="margin: 6px 0 0; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em; opacity: 0.85;">The New Tips Server Dispatcher</p>
              </div>
              <div style="padding: 35px; line-height: 1.6; font-size: 14px; color: #374151;">
                <p style="margin-top: 0; font-weight: 700; color: #111827;">SMTP configuration is active!</p>
                <p>Congratulations! Your SMTP email server settings are correctly configured. Your portal will now automatically dispatch 100% real-world emails to registered students for welcome greetings, verified payment receipts, and new course publications in real-time.</p>
                
                <div style="background-color: #f9fafb; border: 1px solid #e5e7eb; border-radius: 12px; padding: 18px; margin-top: 25px; font-size: 12px; color: #4b5563; font-family: monospace;">
                  <strong style="color: #111827;">Connection Parameters:</strong><br/>
                  \u2022 Host: ${smtpHost}<br/>
                  \u2022 Port: ${port}<br/>
                  \u2022 User: ${smtpUser}<br/>
                  \u2022 From: ${sender}
                </div>
              </div>
              <div style="background-color: #f9fafb; padding: 15px; text-align: center; font-size: 10px; color: #9ca3af; border-top: 1px solid #e5e7eb;">
                &copy; ${(/* @__PURE__ */ new Date()).getFullYear()} The New Tips. All rights reserved.
              </div>
            </div>
          </div>
        `
      });
      console.log(`[SMTP Test API] Real email dispatched to ${recipient} successfully.`);
      res.json({ success: true, message: `Real connection test succeeded! Real Gmail dispatched to ${recipient}.` });
    } catch (err) {
      console.error("[SMTP Test API] Failed to connect/send:", err);
      res.status(500).json({ success: false, error: err.message || String(err) });
    }
  });
  app.post("/api/admin/trigger-daily-auto-upload", async (req, res) => {
    try {
      console.log("[DAILY-AUTO-UPLOAD] Admin triggered manual daily check!");
      res.json({ success: true, message: "\u0921\u0948\u0932\u0940 \u0915\u094B\u0930\u094D\u0938 \u091C\u0928\u0930\u0947\u0936\u0928 \u092C\u0948\u0915\u0917\u094D\u0930\u093E\u0909\u0902\u0921 \u092E\u0947\u0902 \u0936\u0941\u0930\u0942 \u0939\u094B \u0917\u092F\u093E \u0939\u0948\u0964 \u0907\u0938\u0947 \u092A\u0942\u0930\u093E \u0939\u094B\u0928\u0947 \u092E\u0947\u0902 1-2 \u092E\u093F\u0928\u091F \u0932\u0917 \u0938\u0915\u0924\u0947 \u0939\u0948\u0902\u0964" });
      setTimeout(async () => {
        try {
          const coursesSnapshot = await getDocs(collection(db, "courses"));
          const allCourses = coursesSnapshot.docs.map((doc2) => doc2.data());
          const dailyTopicsPool = [
            "Kali Linux Ethical Hacking Beginner Course",
            "Nmap Network Scanning and Vulnerability Guide",
            "Metasploit Framework Practical Masterclass",
            "Wireshark Packet Analysis & Network Pentesting",
            "Bug Bounty Hunting & Web Security Basics",
            "Termux Mobile Pentesting and Linux Commands",
            "Hydra Password Cracking and SSH Hardening",
            "SQLmap Automated SQL Injection Pentesting Course",
            "Social Engineering Defensive and Practical Guide",
            "ChatGPT & Prompt Engineering Masterclass",
            "Stock Market & Options Trading Basics",
            "Figma UI/UX Designing Essentials Course"
          ];
          const unusedTopics = dailyTopicsPool.filter(
            (topic) => !allCourses.some((c) => (c.title || "").toLowerCase().includes(topic.toLowerCase()))
          );
          const finalTopic = unusedTopics.length > 0 ? unusedTopics[Math.floor(Math.random() * unusedTopics.length)] : dailyTopicsPool[Math.floor(Math.random() * dailyTopicsPool.length)] + ` v${Math.floor(Math.random() * 5) + 1}`;
          console.log(`[DAILY-AUTO-UPLOAD] Admin Force Run: Selected topic: "${finalTopic}"`);
          const newCourse = await generateAICourseService(finalTopic, true);
          console.log(`[DAILY-AUTO-UPLOAD] Successfully auto-uploaded & published course: "${newCourse?.title}"!`);
        } catch (bgErr) {
          console.error("[DAILY-AUTO-UPLOAD] Background generation failed:", bgErr);
        }
      }, 0);
    } catch (err) {
      console.error("[DAILY-AUTO-UPLOAD] Manual trigger check failed:", err);
      if (!res.headersSent) {
        res.status(500).json({ success: false, error: err.message || String(err) });
      }
    }
  });
  app.post("/api/admin/audit", async (req, res) => {
    try {
      let dbSettings = {};
      try {
        const settingsDoc = await getDoc(doc(db, "settings", "gateway"));
        dbSettings = settingsDoc.exists() ? settingsDoc.data() : {};
      } catch (err) {
        console.warn("[Auditor] Warning fetching settings from Firestore:", err?.message || err);
      }
      let coursesList = [];
      try {
        const coursesSnapshot = await getDocs(collection(db, "courses"));
        coursesList = coursesSnapshot.docs.map((d) => d.data());
      } catch (err) {
        console.warn("[Auditor] Warning fetching courses from Firestore:", err?.message || err);
      }
      let transactionsList = [];
      try {
        const transactionsSnapshot = await getDocs(collection(db, "transactions"));
        transactionsList = transactionsSnapshot.docs.map((d) => d.data());
      } catch (err) {
        console.warn("[Auditor] Warning fetching transactions from Firestore:", err?.message || err);
      }
      const auditSettings = {
        hasRazorpayKeyId: !!dbSettings.razorpayKeyId,
        hasRazorpayKeySecret: !!dbSettings.razorpayKeySecret,
        upiVpa: dbSettings.upiVpa || "Not Configured",
        isLiveMode: !!dbSettings.isLiveMode,
        isDefaultPasswordUsed: dbSettings.adminPassword === "@#$sitaram12@#$" || !dbSettings.adminPassword
      };
      const auditCourses = coursesList.map((c) => ({
        id: c.id,
        title: c.title,
        price: c.price,
        originalPrice: c.originalPrice,
        category: c.category,
        lecturesCount: c.lecturesCount || c.videos?.length || 0,
        filesCount: c.filesCount || c.attachments?.length || 0,
        hasDescription: !!c.description,
        hasThumbnail: !!c.thumbnail && typeof c.thumbnail === "string" && !c.thumbnail.includes("unsplash.com/photo-1547082299-de196ea013d6")
        // detect default thumbnail
      }));
      const auditTransactions = {
        totalCount: transactionsList.length,
        successCount: transactionsList.filter((t) => t && t.status === "SUCCESS").length,
        pendingCount: transactionsList.filter((t) => t && t.status === "PENDING").length
      };
      const auditData = {
        settings: auditSettings,
        courses: auditCourses,
        transactions: auditTransactions,
        platformName: "The New Tips Courses"
      };
      const auditPrompt = `
Analyze this education portal data and provide a highly professional, comprehensive Website Audit & Health Check report in Hindi and Hinglish. 

Data to Audit:
${JSON.stringify(auditData, null, 2)}

Provide clear, highly actionable, structured feedback under the following sections in Markdown:
1. \u{1F50D} **Overview & System Health (\u0935\u0930\u094D\u0924\u092E\u093E\u0928 \u0938\u094D\u0925\u093F\u0924\u093F \u0914\u0930 \u0938\u093F\u0938\u094D\u091F\u092E \u0939\u0947\u0932\u094D\u0925)**: Summarize how the portal is configured.
2. \u{1F6A8} **Critical Vulnerabilities & Areas to Fix (\u0917\u0902\u092D\u0940\u0930 \u0915\u092E\u093F\u092F\u093E\u0902 \u091C\u094B \u0920\u0940\u0915 \u0915\u0930\u0928\u0940 \u0939\u0948\u0902)**: Point out defaults, missing values, empty curricula, etc. Be extremely specific.
3. \u{1F6E0}\uFE0F **Feature Check & Optimization (\u092B\u0940\u091A\u0930 \u091A\u0947\u0915\u093F\u0902\u0917 \u0914\u0930 \u0938\u0941\u0927\u093E\u0930 \u0915\u0947 \u0909\u092A\u093E\u092F)**: Evaluate if course categories (including ETHICAL HACKING) are working. Recommend updates.
4. \u{1F4C8} **Conversion Booster (\u0938\u0947\u0932\u094D\u0938 \u0914\u0930 \u0915\u0928\u094D\u0935\u0930\u094D\u0936\u0928 \u092C\u0922\u093C\u093E\u0928\u0947 \u0915\u0947 \u0930\u0923\u0928\u0940\u0924\u093F\u0915 \u0909\u092A\u093E\u092F)**: Give creative marketing recommendations.
`;
      const systemInstruction = `
You are an expert Chief Technology Officer (CTO) and UI/UX Conversion Specialist for "The New Tips" Premium Course Portal.
Your tone should be highly professional, intelligent, constructive, and business-focused.
You must speak in a blend of polite Hindi (Devanagari script) and English (Hinglish) to keep recommendations highly engaging and readable for Indian admins.
`;
      let aiText = "";
      let geminiSuccess = false;
      try {
        const cooldownActive = serviceCooldowns["aiSecurityAudit"] && Date.now() < serviceCooldowns["aiSecurityAudit"];
        if (!cooldownActive) {
          console.log(`Auditor attempting audit generation via safeGenerateContent`);
          const response = await withTimeout(
            safeGenerateContent(aiSecurityAudit, {
              model: "gemini-3.5-flash",
              contents: [{ role: "user", parts: [{ text: auditPrompt }] }],
              serviceName: "aiSecurityAudit",
              config: {
                systemInstruction,
                temperature: 0.3
              }
            }),
            3e5,
            // 5 minute timeout for audit
            `CTO Audit generation timed out`
          );
          if (response && response.text) {
            aiText = response.text;
            geminiSuccess = true;
          }
        } else {
          console.log(`[Auditor] Skipping audit generation due to cooldown.`);
        }
      } catch (err) {
        console.error("[Auditor] Smart Auditor generation failed:", err);
      }
      if (!geminiSuccess || !aiText) {
        aiText = `### \u{1F50D} **\u0938\u093F\u0938\u094D\u091F\u092E \u0939\u0947\u0932\u094D\u0925 \u0930\u093F\u092A\u094B\u0930\u094D\u091F (\u0911\u091F\u094B\u092E\u0947\u091F\u0947\u0921 \u0915\u094D\u0935\u093F\u0915 \u0930\u093F\u092A\u094B\u0930\u094D\u091F)**
        
\u0935\u0930\u094D\u0924\u092E\u093E\u0928 \u092E\u0947\u0902 AI \u0938\u0930\u094D\u0935\u0930 \u092C\u0939\u0941\u0924 \u0935\u094D\u092F\u0938\u094D\u0924 \u0939\u094B\u0928\u0947 \u0915\u0947 \u0915\u093E\u0930\u0923 \u0935\u093F\u0938\u094D\u0924\u0943\u0924 \u0911\u0921\u093F\u091F \u0930\u093F\u092A\u094B\u0930\u094D\u091F \u0932\u094B\u0921 \u0928\u0939\u0940\u0902 \u0939\u094B \u0938\u0915\u0940\u0964 \u0932\u0947\u0915\u093F\u0928 \u0906\u092A\u0915\u0947 \u0932\u093E\u0907\u0935 \u0938\u093F\u0938\u094D\u091F\u092E \u0915\u0940 \u092A\u094D\u0930\u093E\u0925\u092E\u093F\u0915 \u091C\u093E\u0902\u091A \u0915\u0947 \u092A\u0930\u093F\u0923\u093E\u092E \u0928\u093F\u092E\u094D\u0928\u0932\u093F\u0916\u093F\u0924 \u0939\u0948\u0902:

* **\u092A\u0947\u092E\u0947\u0902\u091F \u0917\u0947\u091F\u0935\u0947 (Payment Gateway)**: ${auditSettings.hasRazorpayKeyId ? "\u2705 Razorpay Key ID \u0938\u0915\u094D\u0930\u093F\u092F \u0939\u0948" : "\u274C Razorpay Key ID \u0909\u092A\u0932\u092C\u094D\u0927 \u0928\u0939\u0940\u0902 \u0939\u0948"}
* **UPI VPA**: \`${auditSettings.upiVpa || "not_configured"}\`
* **\u0938\u0915\u094D\u0930\u093F\u092F \u0915\u094B\u0930\u094D\u0938\u0947\u0938 (Active Courses)**: \`${auditCourses.length}\` \u0915\u094B\u0930\u094D\u0938\u0947\u0938 \u0932\u093E\u0907\u0935 \u0939\u0948\u0902\u0964
* **\u092A\u093E\u0938\u0935\u0930\u094D\u0921 \u0938\u094D\u091F\u0947\u091F\u0938**: ${auditSettings.isDefaultPasswordUsed ? "\u26A0\uFE0F \u0921\u093F\u092B\u093C\u0949\u0932\u094D\u091F \u092A\u093E\u0938\u0935\u0930\u094D\u0921 \u0915\u093E \u0909\u092A\u092F\u094B\u0917 \u0939\u094B \u0930\u0939\u093E \u0939\u0948, \u0915\u0943\u092A\u092F\u093E \u0907\u0938\u0947 \u092C\u0926\u0932\u0947\u0902\u0964" : "\u2705 \u090F\u0921\u092E\u093F\u0928 \u092A\u0948\u0928\u0932 \u0938\u0941\u0930\u0915\u094D\u0937\u093F\u0924 \u0939\u0948\u0964"}

\u0915\u0943\u092A\u092F\u093E \u0935\u093F\u0938\u094D\u0924\u0943\u0924 \u0930\u093F\u092A\u094B\u0930\u094D\u091F \u0915\u0947 \u0932\u093F\u090F \u0925\u094B\u0921\u093C\u0940 \u0926\u0947\u0930 \u092C\u093E\u0926 \u092A\u0941\u0928\u0903 \u092A\u094D\u0930\u092F\u093E\u0938 \u0915\u0930\u0947\u0902\u0964`;
      }
      res.json({ success: true, report: aiText, rawStats: auditData });
    } catch (error) {
      console.error("Error in AI Audit API route:", error);
      res.status(500).json({ error: "Internal server error during audit check.", details: error?.message || String(error) });
    }
  });
  const POOL_VIDEOS = [
    {
      keywords: ["react", "vite", "frontend", "hooks", "mern", "web", "html", "css", "javascript", "js", "tailwind", "next"],
      items: [
        { url: "https://www.youtube.com/watch?v=kYJ462wX1i0", title: "React 19 & Vite Full Practical Guide" },
        { url: "https://www.youtube.com/watch?v=SqcY0GlETPk", title: "React JS Crash Course for Beginners" },
        { url: "https://www.youtube.com/watch?v=Ke90Tje7VS0", title: "React Integration with Gemini AI" },
        { url: "https://www.youtube.com/watch?v=mU6an7qMCsc", title: "HTML & CSS Complete Web Development Tutorial" },
        { url: "https://www.youtube.com/watch?v=PkZNo7MFNFg", title: "JavaScript Programming Language Crash Course" },
        { url: "https://www.youtube.com/watch?v=UBOj6rqRUME", title: "Tailwind CSS & Modern UI Design Frameworks" },
        { url: "https://www.youtube.com/watch?v=wm5gMKuwSYk", title: "Next.js 14 Full Stack Development Roadmap" },
        { url: "https://www.youtube.com/watch?v=Oe421EPjeBE", title: "Node.js & Express.js Backend API Development" }
      ]
    },
    {
      keywords: ["express", "node", "backend", "api", "mongodb", "server", "sql", "database"],
      items: [
        { url: "https://www.youtube.com/watch?v=ZfKn_7YtK04", title: "Express & Node JS Server Setup" },
        { url: "https://www.youtube.com/watch?v=7CqJlxBYj-M", title: "Node.js and Express API Complete Guide" },
        { url: "https://www.youtube.com/watch?v=Oe421EPjeBE", title: "Node.js & Express.js Backend API Development" },
        { url: "https://www.youtube.com/watch?v=HXV3zeQKqGY", title: "Introduction to Computer Science & Coding Basics" },
        { url: "https://www.youtube.com/watch?v=vLnPwxZdW4Y", title: "C++ Programming for Game Development" }
      ]
    },
    {
      keywords: ["ai", "chatgpt", "gemini", "automation", "prompt", "llm", "agent", "artificial", "machine learning"],
      items: [
        { url: "https://www.youtube.com/watch?v=mBYu5NoWdSU", title: "ChatGPT Prompt Engineering Masterclass for Beginners" },
        { url: "https://www.youtube.com/watch?v=7CqJlxBYj-M", title: "AI Automation Agency (AAA) & No-Code Workflow Setup" },
        { url: "https://www.youtube.com/watch?v=gDiEcL_r6p4", title: "YouTube & Instagram AI Video Content Automation Secrets" },
        { url: "https://www.youtube.com/watch?v=rfscVS0vtbw", title: "Python Programming Course for Absolute Beginners" },
        { url: "https://www.youtube.com/watch?v=5sLYAQS9s8U", title: "Generative AI & LLMs Explained - Modern Guide" },
        { url: "https://www.youtube.com/watch?v=H68qB_eU6Hk", title: "No-Code AI App Building with Bubble & Zapier" }
      ]
    },
    {
      keywords: ["seo", "marketing", "google ads", "social media", "ads", "digital marketing", "sales", "facebook ads"],
      items: [
        { url: "https://www.youtube.com/watch?v=nU-IIXBWlS4", title: "Digital Marketing Full Course - 12 Hours Masterclass" },
        { url: "https://www.youtube.com/watch?v=8p9vD0H6lU0", title: "Social Media Marketing Strategy for Beginners" },
        { url: "https://www.youtube.com/watch?v=DvwS7cV9GmQ", title: "SEO (Search Engine Optimization) Complete Tutorial" },
        { url: "https://www.youtube.com/watch?v=9jD_v17oHIs", title: "Facebook & Instagram Ads Masterclass Guide" },
        { url: "https://www.youtube.com/watch?v=1pE6mX_h7yY", title: "Google Ads Tutorial for Beginners 2024" },
        { url: "https://www.youtube.com/watch?v=un50Bs4BvZ8", title: "Content Marketing Mastery - Zero to Hero" }
      ]
    },
    {
      keywords: ["ethical hacking", "hacking", "cyber", "security", "penetration", "cybersecurity", "termux", "bug bounty", "nmap", "pentest"],
      items: [
        { url: "https://www.youtube.com/watch?v=S0169R_C_S0", title: "Termux Ethical Hacking: Complete A to Z Practical Course" },
        { url: "https://www.youtube.com/watch?v=bO763TclD9I", title: "Linux Command Line Basics for Beginners in Termux" },
        { url: "https://www.youtube.com/watch?v=N_v9yU19Q1k", title: "Metasploit Framework Installation & Usage in Termux" },
        { url: "https://www.youtube.com/watch?v=X0K1Tq2A-M4", title: "Nmap Network Scanning Practical Guide for Students" },
        { url: "https://www.youtube.com/watch?v=kYmZ6v2E5vA", title: "Wireless Security & Pentesting Roadmap 2024" },
        { url: "https://www.youtube.com/watch?v=hW6N2j_W_A4", title: "Bug Bounty Hunting for Beginners - Step by Step" },
        { url: "https://www.youtube.com/watch?v=3Kq1MIfTWCE", title: "Ethical Hacking & Penetration Testing Course" },
        { url: "https://www.youtube.com/watch?v=sWbUDq4SdyI", title: "Linux for Ethical Hackers - Full Tutorial" }
      ]
    },
    {
      keywords: ["trading", "finance", "stock", "option", "market", "crypto", "share", "wealth", "investment"],
      items: [
        { url: "https://www.youtube.com/watch?v=Xn7KPTGZ6B8", title: "Stock Market Basics for Beginners (Hindi Masterclass)" },
        { url: "https://www.youtube.com/watch?v=gT8BfG2L3uA", title: "Price Action Trading Strategies: Support & Resistance" },
        { url: "https://www.youtube.com/watch?v=9N5r8bV2w_w", title: "Risk Management & Trading Psychology Secrets" },
        { url: "https://www.youtube.com/watch?v=L_T3W0F7zC8", title: "Options Trading & Strategy Builder for Students" },
        { url: "https://www.youtube.com/watch?v=rYQgy8QDEBI", title: "Cryptocurrency & Blockchain Technology Full Course" }
      ]
    },
    {
      keywords: ["figma", "ui", "ux", "design", "photoshop", "illustrator", "graphic", "video", "edit", "premiere"],
      items: [
        { url: "https://www.youtube.com/watch?v=c9Wg6Ry_YgU", title: "Figma UI/UX Design Complete Course for Beginners" },
        { url: "https://www.youtube.com/watch?v=y7Ssc_X-HSw", title: "Auto Layout, Resizable Components & Design Systems" },
        { url: "https://www.youtube.com/watch?v=f0v23KscCIE", title: "Video Editing Foundations: Complete Premiere Pro Guide" },
        { url: "https://www.youtube.com/watch?v=un50Bs4BvZ8", title: "Graphic Designing Principles & Essential Freelancing Tips" },
        { url: "https://www.youtube.com/watch?v=Ib8UBwu3yTQ", title: "Adobe Illustrator Crash Course for Designers" },
        { url: "https://www.youtube.com/watch?v=w_P9U4E_z_U", title: "After Effects Motion Graphics Masterclass" },
        { url: "https://www.youtube.com/watch?v=vV1p8_iP7M0", title: "Photoshop Editing Masterclass - Zero to Hero" }
      ]
    },
    {
      keywords: ["kotlin", "android", "app", "ios", "swift", "mobile", "flutter", "react native"],
      items: [
        { url: "https://www.youtube.com/watch?v=fis26HlhDII", title: "Android App Development with Kotlin Studio Setup" },
        { url: "https://www.youtube.com/watch?v=FJRmhyMx060", title: "Kotlin Programming Language Fundamentals Masterclass" },
        { url: "https://www.youtube.com/watch?v=Ch5pH8v8SFA", title: "Jetpack Compose: Building Modern Android App UIs" },
        { url: "https://www.youtube.com/watch?v=EExSSotojxs", title: "REST APIs, Retrofit & Firebase Mobile Database Setup" },
        { url: "https://www.youtube.com/watch?v=VPvVD8t02U8", title: "Flutter App Development Crash Course - 2024" },
        { url: "https://www.youtube.com/watch?v=0-S5a0eXPoc", title: "React Native Mobile Apps for iOS & Android" }
      ]
    },
    {
      keywords: ["python", "automation", "scripting", "programming", "coding"],
      items: [
        { url: "https://www.youtube.com/watch?v=rfscVS0vtbw", title: "Python Programming Course for Absolute Beginners" },
        { url: "https://www.youtube.com/watch?v=HXV3zeQKqGY", title: "Introduction to Computer Science & Coding Basics" }
      ]
    }
  ];
  const POOL_ATTACHMENTS = [
    {
      keywords: ["react", "vite", "frontend", "hooks", "mern", "web", "html", "css", "javascript", "js", "tailwind", "next"],
      items: [
        { url: "https://raw.githubusercontent.com/duong-g/react-cheat-sheet/master/react-cheat-sheet.pdf", title: "React_19_Vite_Core_Cheat_Sheet.pdf" },
        { url: "https://github.com/getify/You-Dont-Know-JS", title: "You_Dont_Know_JS_E_Book.pdf" },
        { url: "https://github.com/sudheerj/reactjs-interview-questions", title: "ReactJS_Best_Practices_Notes.pdf" }
      ]
    },
    {
      keywords: ["express", "node", "backend", "api", "mongodb", "server", "sql", "database"],
      items: [
        { url: "https://raw.githubusercontent.com/duong-g/react-cheat-sheet/master/react-cheat-sheet.pdf", title: "Express_Boilerplate_Architecture_Guide.pdf" },
        { url: "https://github.com/donnemartin/system-design-primer", title: "System_Design_And_API_Handbook.pdf" }
      ]
    },
    {
      keywords: ["ai", "chatgpt", "gemini", "automation", "prompt", "llm", "agent", "artificial", "machine learning"],
      items: [
        { url: "https://github.com/google-gemini/cookbook", title: "Gemini_API_Quickstart_Handbook.pdf" },
        { url: "https://static.googleusercontent.com/media/www.google.com/en//webmasters/docs/search-engine-optimization-starter-guide.pdf", title: "ChatGPT_Prompt_Engineering_Workbook.pdf" }
      ]
    },
    {
      keywords: ["seo", "marketing", "google ads", "social media", "ads", "digital marketing", "sales", "facebook ads"],
      items: [
        { url: "https://static.googleusercontent.com/media/www.google.com/en//webmasters/docs/search-engine-optimization-starter-guide.pdf", title: "Google_Search_Engine_Optimization_Starter_Guide.pdf" },
        { url: "https://raw.githubusercontent.com/dianper/copywriting-templates/master/README.md", title: "High_Converting_Copywriting_Templates.pdf" }
      ]
    },
    {
      keywords: ["ethical hacking", "hacking", "cyber", "security", "penetration", "cybersecurity", "termux", "bug bounty", "nmap", "pentest"],
      items: [
        { url: "https://owasp.org/www-project-top-ten/", title: "OWASP_Top_10_Security_Reference_Guide.pdf" },
        { url: "https://github.com/swisskyrepo/PayloadsAllTheThings", title: "Penetration_Testing_Payloads_Cheat_Sheet.pdf" },
        { url: "https://github.com/vavkamil/awesome-bugbounty-tools/blob/master/README.md", title: "Termux_Hacking_Step_By_Step_Guide.pdf" },
        { url: "https://github.com/mrd0x/The-Hacker-Playbook/blob/master/README.md", title: "Ethical_Hacking_Practical_Workbook_Notes.pdf" }
      ]
    },
    {
      keywords: ["trading", "finance", "stock", "option", "market", "crypto", "share", "wealth", "investment"],
      items: [
        { url: "https://www.investopedia.com/articles/basics/06/invest1000.asp", title: "Stock_Market_Trading_Masterclass_Guide.pdf" },
        { url: "https://github.com/tradier/tradier-python/blob/master/README.md", title: "Practical_Options_Trading_Strategy_Manual.pdf" }
      ]
    },
    {
      keywords: ["figma", "ui", "ux", "design", "photoshop", "illustrator", "graphic", "video", "edit", "premiere"],
      items: [
        { url: "https://www.figma.com/community/file/1023347101562916848", title: "UI_UX_Design_Systems_Template_Workbook.pdf" },
        { url: "https://github.com/awesome-selfhosted/awesome-selfhosted", title: "Graphic_Design_Principles_Resource.pdf" }
      ]
    },
    {
      keywords: ["kotlin", "android", "app", "ios", "swift", "mobile", "flutter", "react native"],
      items: [
        { url: "https://github.com/asweigart/inventwithpython", title: "Kotlin_Programming_Fundamentals_Handbook.pdf" },
        { url: "https://roadmap.sh/software-design-architecture", title: "Mobile_App_Architecture_Roadmap.pdf" }
      ]
    },
    {
      keywords: ["python", "automation", "scripting", "programming", "coding"],
      items: [
        { url: "https://docs.python.org/3/", title: "Python_3_Official_Reference_Guide.pdf" }
      ]
    }
  ];
  function getFallbackUrl(itemType, courseTitle, itemTitle, currentUrl, index, usedUrls) {
    const textToSearch = `${courseTitle || ""} ${itemTitle || ""} ${currentUrl || ""}`.toLowerCase();
    const fallbackList = itemType === "video" ? POOL_VIDEOS : POOL_ATTACHMENTS;
    for (const group of fallbackList) {
      if (group.keywords.some((keyword) => textToSearch.includes(keyword))) {
        if (usedUrls && usedUrls.size > 0) {
          for (let k = 0; k < group.items.length; k++) {
            const candidateIndex = (index + k) % group.items.length;
            const candidate = group.items[candidateIndex];
            const candidateUrlLower = candidate.url.trim().toLowerCase();
            if (!usedUrls.has(candidateUrlLower)) {
              usedUrls.add(candidateUrlLower);
              return candidate;
            }
          }
        }
        const item = group.items[index % group.items.length];
        if (usedUrls) usedUrls.add(item.url.trim().toLowerCase());
        return item;
      }
    }
    if (itemType === "video") {
      const defaultUrl = "https://www.youtube.com/watch?v=Ke90Tje7VS0";
      if (usedUrls) usedUrls.add(defaultUrl.trim().toLowerCase());
      return {
        url: defaultUrl,
        title: itemTitle || "Premium Verified Video Lesson"
      };
    } else {
      const defaultUrl = "https://raw.githubusercontent.com/duong-g/react-cheat-sheet/master/react-cheat-sheet.pdf";
      if (usedUrls) usedUrls.add(defaultUrl.trim().toLowerCase());
      return {
        url: defaultUrl,
        title: itemTitle || "Premium Verified Digital Resource.pdf"
      };
    }
  }
  async function generateAndPostDailyCourse() {
    console.log("[AUTO-GENERATOR] Starting daily course generation...");
    try {
      const cooldownActive = serviceCooldowns["aiCourseGenerator"] && Date.now() < serviceCooldowns["aiCourseGenerator"];
      if (cooldownActive) {
        console.log("[AUTO-GENERATOR] Skipping daily course generation due to AI cooldown.");
        return;
      }
      const systemInstruction = `You are an expert course creator. Choose a specific, trending technical topic in programming, cybersecurity, or development. Create a structured course content in Hindi about this topic.
        The course MUST include:
        - Title (in Hindi, descriptive of the topic)
        - Description (in Hindi)
        - Thumbnail URL: A placeholder URL for a high-quality thumbnail image relevant to the topic.
        - Price: A number between 99 and 199.
        - 5 Modules/Tools:
          Each tool must include:
          - Name (in Hindi, related to the topic)
          - Practical Guide (in Hindi, with detailed commands and instructions for both Termux app and PC/Laptop terminals. The guide MUST clearly distinguish between Termux and PC commands where applicable).
          - Video: A placeholder YouTube URL (assume Hindi language tutorial related to the topic).
          - Attachment: A placeholder PDF URL (must be a Hindi guide containing all commands, codes, and instructions for Termux and PC/Laptop terminals related to the topic).
        
        Strictly return a JSON object with this exact structure:
        {
          "title": "...",
          "description": "...",
          "thumbnailUrl": "...",
          "price": 99,
          "tools": [
            { "name": "...", "practicalGuide": "...", "videoUrl": "...", "pdfUrl": "..." },
            ... (5 tools)
          ]
        }`;
      const prompt = "Generate a new, trending technical course for today. Ensure all content (title, videos, guides, pdfs) strictly revolves around the chosen topic.";
      const response = await safeGenerateContent(aiCourseGenerator, {
        model: "gemini-3.5-flash",
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        serviceName: "aiCourseGenerator",
        config: {
          systemInstruction,
          temperature: 0.8,
          responseMimeType: "application/json"
        }
      });
      const courseData = cleanAndParseJSON(response.text || "{}");
      const newCourse = {
        id: `course_${Date.now()}`,
        title: courseData.title,
        description: courseData.description,
        thumbnail: courseData.thumbnailUrl || `https://source.unsplash.com/featured/?${encodeURIComponent(courseData.title.split(" ").slice(0, 3).join(","))}`,
        price: courseData.price,
        originalPrice: courseData.price * 1.5,
        category: "DEVELOPMENT",
        lecturesCount: courseData.tools?.length || 0,
        filesCount: courseData.tools?.length || 0,
        videos: (courseData.tools || []).map((t) => ({ id: `v_${Date.now()}_${t.name}`, title: t.name, url: t.videoUrl, isVerified: true })),
        attachments: (courseData.tools || []).map((t) => ({ id: `a_${Date.now()}_${t.name}`, name: `${t.name}_Guide.pdf`, url: t.pdfUrl })),
        createdAt: Date.now(),
        isAIGenerated: true,
        status: "published"
      };
      await setDoc(doc(db, "courses", newCourse.id), newCourse);
      await setDoc(doc(db, "system_config", "latest_course"), {
        courseId: newCourse.id,
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      });
      console.log(`[AUTO-GENERATOR] Course generated and saved: ${newCourse.title}`);
    } catch (err) {
      console.error("[AUTO-GENERATOR] Failed to generate course:", err);
    }
  }
  async function autoHealAllCourses() {
    console.log("[AUTO-HEALER] Starting automatic background self-healing audit for all courses...");
    try {
      const coursesSnapshot = await getDocs(collection(db, "courses"));
      let totalChecked = 0;
      let totalHealed = 0;
      let aiFixesThisRun = 0;
      const MAX_AI_FIXES_PER_RUN = 3;
      let isAiDisabledThisRun = false;
      for (const courseDoc of coursesSnapshot.docs) {
        const course = courseDoc.data();
        let updated = false;
        if (!course.thumbnail || course.thumbnail.trim() === "" || course.thumbnail.includes("placeholder")) {
          course.thumbnail = `https://source.unsplash.com/featured/?${encodeURIComponent(course.title.split(" ").slice(0, 3).join(","))}`;
          updated = true;
        }
        const currentPrice = Number(course.price || 0);
        if (currentPrice < 299 || currentPrice > 699) {
          course.price = currentPrice < 299 ? 299 : 699;
          course.originalPrice = course.price * 5 - 1;
          updated = true;
          console.log(`[AUTO-HEALER] Corrected price for course "${course.title}": ${currentPrice} -> ${course.price}`);
        }
        const videos = course.videos ? [...course.videos] : [];
        const attachments = course.attachments ? [...course.attachments] : [];
        const usedUrlsInCourse = /* @__PURE__ */ new Set();
        videos.forEach((v) => {
          if (v.url && v.url.trim() !== "") usedUrlsInCourse.add(v.url.trim().toLowerCase());
        });
        const videoResults = [];
        for (let vIdx = 0; vIdx < videos.length; vIdx++) {
          const v = videos[vIdx];
          totalChecked++;
          let isWorking = v.isVerified === true && v.url && v.url !== "#" && v.url.trim() !== "";
          if (!isWorking) {
            isWorking = await verifyVideoUrl(v.url, "video");
          }
          if (v.isVerified !== isWorking) {
            updated = true;
          }
          let url = v.url;
          let title = v.title;
          if (!isWorking || !url || url === "#" || url.trim() === "") {
            usedUrlsInCourse.delete((v.url || "").trim().toLowerCase());
            let aiSuccess = false;
            let newUrl = "";
            let newTitle = "";
            const prompt = `
            Please use Google Search to find a high-quality, real, active, and working YouTube video URL on the internet.
            We are replacing a broken/invalid URL in our digital course.
            Course Topic: ${course.title}
            Item Title: ${v.title}
            Broken/Old URL: ${v.url}
            
            Instructions:
            1. Search the web/YouTube to find a real, valid, and active working video URL.
            2. Do NOT guess or make up a fake URL. It must be a real URL.
            3. Return ONLY a valid JSON object matching this schema:
            { "newUrl": "...", "newTitle": "..." }
            `;
            try {
              const cooldownActive = serviceCooldowns["aiBrokenLinkAutoFixer"] && Date.now() < serviceCooldowns["aiBrokenLinkAutoFixer"];
              if (aiFixesThisRun < MAX_AI_FIXES_PER_RUN && !isAiDisabledThisRun && !cooldownActive) {
                console.log(`[AUTO-HEALER] Attempting to fix broken video: ${v.title}`);
                aiFixesThisRun++;
                const response = await safeGenerateContent(aiBrokenLinkAutoFixer, {
                  model: "gemini-3.5-flash",
                  contents: [{ role: "user", parts: [{ text: prompt }] }],
                  serviceName: "aiBrokenLinkAutoFixer",
                  config: {
                    responseMimeType: "application/json"
                  },
                  tools: [{ googleSearch: {} }]
                });
                await new Promise((r) => setTimeout(r, 4e3));
                if (response) {
                  const responseText = response.text || "{}";
                  const aiData = cleanAndParseJSON(responseText);
                  if (aiData.newUrl && aiData.newUrl.startsWith("http") && !usedUrlsInCourse.has(aiData.newUrl.trim().toLowerCase())) {
                    newUrl = aiData.newUrl;
                    newTitle = aiData.newTitle || v.title;
                    aiSuccess = true;
                  }
                }
              }
            } catch (err) {
              console.log(`[Info] Background auto-heal Gemini link fix failed/rate-limited for video ${v.title}:`, err);
              const errMsg = err?.message || String(err);
              if (errMsg.includes("QUOTA") || errMsg.includes("429") || errMsg.includes("cooldown") || errMsg.includes("exhausted") || err?.status === 429) {
                isAiDisabledThisRun = true;
                serviceCooldowns["aiBrokenLinkAutoFixer"] = Date.now() + 3 * 60 * 1e3;
              }
            }
            if (!aiSuccess) {
              const fallback = getFallbackUrl("video", course.title, v.title, v.url, vIdx, usedUrlsInCourse);
              url = fallback.url;
              title = fallback.title || v.title;
            } else {
              url = newUrl;
              title = newTitle;
              usedUrlsInCourse.add(url.trim().toLowerCase());
            }
            isWorking = await verifyVideoUrl(url, "video");
            updated = true;
            totalHealed++;
            console.log(`[AUTO-HEALER] Replacing BROKEN video in course "${course.title}": "${v.title}" (Old: ${v.url}, New: ${url})`);
          }
          videoResults.push({ ...v, url, title, isVerified: isWorking });
        }
        const usedAttsInCourse = /* @__PURE__ */ new Set();
        attachments.forEach((a) => {
          if (a.url && a.url.trim() !== "") usedAttsInCourse.add(a.url.trim().toLowerCase());
        });
        const attResults = [];
        for (let aIdx = 0; aIdx < attachments.length; aIdx++) {
          const a = attachments[aIdx];
          totalChecked++;
          let isWorking = a.isVerified === true && a.url && a.url !== "#" && a.url.trim() !== "";
          if (!isWorking) {
            isWorking = await verifyVideoUrl(a.url, "attachment");
          }
          if (a.isVerified !== isWorking) {
            updated = true;
          }
          let url = a.url;
          let name = a.name;
          if (!isWorking || !url || url === "#" || url.trim() === "") {
            usedAttsInCourse.delete((a.url || "").trim().toLowerCase());
            let aiSuccess = false;
            let newUrl = "";
            let newTitle = "";
            const prompt = `
            Please use Google Search to find a high-quality, real, active, and working educational PDF/resource URL on the internet.
            We are replacing a broken/invalid URL in our digital course.
            Course Topic: ${course.title}
            Item Title: ${a.name}
            Broken/Old URL: ${a.url}
            
            Instructions:
            1. Search the web to find a real, valid, and active working PDF or document resource URL.
            2. Do NOT guess or make up a fake URL. It must be a real URL.
            3. Return ONLY a valid JSON object matching this schema:
            { "newUrl": "...", "newTitle": "..." }
            `;
            try {
              const cooldownActive = serviceCooldowns["aiBrokenLinkAutoFixer"] && Date.now() < serviceCooldowns["aiBrokenLinkAutoFixer"];
              if (aiFixesThisRun < MAX_AI_FIXES_PER_RUN && !isAiDisabledThisRun && !cooldownActive) {
                console.log(`[AUTO-HEALER] Attempting to fix broken attachment: ${a.name}`);
                aiFixesThisRun++;
                const response = await safeGenerateContent(aiBrokenLinkAutoFixer, {
                  model: "gemini-3.5-flash",
                  contents: [{ role: "user", parts: [{ text: prompt }] }],
                  serviceName: "aiBrokenLinkAutoFixer",
                  config: {
                    responseMimeType: "application/json"
                  },
                  tools: [{ googleSearch: {} }]
                });
                await new Promise((r) => setTimeout(r, 4e3));
                if (response) {
                  const responseText = response.text || "{}";
                  const aiData = cleanAndParseJSON(responseText);
                  if (aiData.newUrl && aiData.newUrl.startsWith("http") && !usedAttsInCourse.has(aiData.newUrl.trim().toLowerCase())) {
                    newUrl = aiData.newUrl;
                    newTitle = aiData.newTitle || a.name;
                    if (!newTitle.toLowerCase().endsWith(".pdf")) {
                      newTitle = `${newTitle.replace(/\.[^/.]+$/, "")}.pdf`;
                    }
                    aiSuccess = true;
                  }
                }
              }
            } catch (err) {
              console.log(`[Info] Background auto-heal Gemini link fix failed/rate-limited for attachment ${a.name}:`, err);
              const errMsg = err?.message || String(err);
              if (errMsg.includes("QUOTA") || errMsg.includes("429") || errMsg.includes("cooldown") || errMsg.includes("exhausted") || err?.status === 429) {
                isAiDisabledThisRun = true;
                serviceCooldowns["aiBrokenLinkAutoFixer"] = Date.now() + 3 * 60 * 1e3;
              }
            }
            if (!aiSuccess) {
              const fallback = getFallbackUrl("attachment", course.title, a.name, a.url, aIdx, usedAttsInCourse);
              url = fallback.url;
              name = fallback.title || a.name;
            } else {
              url = newUrl;
              name = newTitle;
              usedAttsInCourse.add(url.trim().toLowerCase());
            }
            isWorking = await verifyVideoUrl(url, "attachment");
            updated = true;
            totalHealed++;
            console.log(`[AUTO-HEALER] Replacing BROKEN link in course "${course.title}": "${a.name}" (Old: ${a.url}, New: ${url})`);
          }
          attResults.push({ ...a, url, name, isVerified: isWorking });
        }
        if (updated) {
          console.log(`[AUTO-HEALER] Saving healed course in DB: "${course.title}" (${courseDoc.id})`);
          await updateDoc(doc(db, "courses", courseDoc.id), {
            thumbnail: course.thumbnail,
            videos: videoResults,
            attachments: attResults
          });
        }
      }
      console.log(`[AUTO-HEALER] Finished automatic background audit. Checked ${totalChecked} items. Healed ${totalHealed} items.`);
    } catch (err) {
      console.error("[AUTO-HEALER] Error in auto-healer background process:", err);
    }
  }
  app.post("/api/admin/reset-database", async (req, res) => {
    try {
      const DEFAULT_COURSES_RELOAD = DEFAULT_COURSES;
      for (const c of DEFAULT_COURSES_RELOAD) {
        await setDoc(doc(db, "courses", c.id), c);
      }
      res.json({ success: true, message: "Database re-seeded successfully with 100% working links!" });
    } catch (err) {
      console.error("Error resetting database:", err);
      res.status(500).json({ success: false, error: err.message });
    }
  });
  app.post("/api/admin/verify-all-links", async (req, res) => {
    try {
      const { mode = "all" } = req.body || {};
      const coursesSnapshot = await getDocs(collection(db, "courses"));
      const allResults = [];
      for (const courseDoc of coursesSnapshot.docs) {
        const course = courseDoc.data();
        let updated = false;
        const videos = course.videos ? [...course.videos] : [];
        const attachments = course.attachments ? [...course.attachments] : [];
        const usedUrlsInCourse = /* @__PURE__ */ new Set();
        videos.forEach((v) => {
          if (v.url && v.url !== "#" && v.url.trim() !== "") {
            usedUrlsInCourse.add(v.url.trim().toLowerCase());
          }
        });
        const videoResults = [];
        for (let vIdx = 0; vIdx < videos.length; vIdx++) {
          const v = videos[vIdx];
          if (mode === "broken-only" && v.isVerified === true && v.url && v.url !== "#" && v.url.trim() !== "") {
            videoResults.push(v);
            continue;
          }
          let isWorking = await verifyVideoUrl(v.url, "video");
          let url = v.url;
          let title = v.title;
          if (!isWorking || !url || url === "#" || url.trim() === "") {
            usedUrlsInCourse.delete((v.url || "").trim().toLowerCase());
            let aiSuccess = false;
            let newUrl = "";
            let newTitle = "";
            const prompt = `
            Please use Google Search to find a high-quality, real, active, and working YouTube video URL on the internet.
            We are replacing a broken/invalid URL in our digital course.
            Course Topic: ${course.title}
            Item Title: ${v.title}
            Broken/Old URL: ${v.url}
            
            Instructions:
            1. Search the web/YouTube to find a real, valid, and active working video URL.
            2. Do NOT guess or make up a fake URL. It must be a real URL.
            3. Return ONLY a valid JSON object matching this schema:
            { "newUrl": "...", "newTitle": "..." }
            `;
            try {
              const cooldownActive = serviceCooldowns["aiBrokenLinkAutoFixer"] && Date.now() < serviceCooldowns["aiBrokenLinkAutoFixer"];
              if (!cooldownActive) {
                const response = await safeGenerateContent(aiBrokenLinkAutoFixer, {
                  model: "gemini-3.5-flash",
                  contents: [{ role: "user", parts: [{ text: prompt }] }],
                  serviceName: "aiBrokenLinkAutoFixer",
                  config: {
                    responseMimeType: "application/json"
                  },
                  tools: [{ googleSearch: {} }]
                });
                await new Promise((r) => setTimeout(r, 4e3));
                if (response) {
                  const responseText = response.text || "{}";
                  const aiData = cleanAndParseJSON(responseText);
                  if (aiData.newUrl && aiData.newUrl.startsWith("http") && !usedUrlsInCourse.has(aiData.newUrl.trim().toLowerCase())) {
                    newUrl = aiData.newUrl;
                    newTitle = aiData.newTitle || v.title;
                    aiSuccess = true;
                  }
                }
              }
            } catch (err) {
              const errMsg = err?.message || String(err);
              if (errMsg.includes("QUOTA") || errMsg.includes("429") || errMsg.includes("cooldown") || errMsg.includes("exhausted") || err?.status === 429) {
                console.log(`[Info] Mass verify auto-heal hit quota limits. Setting cooldown for aiBrokenLinkAutoFixer.`);
                serviceCooldowns["aiBrokenLinkAutoFixer"] = Date.now() + 15 * 60 * 1e3;
              } else {
                console.log(`[Info] Mass verify auto-heal Gemini link fix failed for video ${v.title}:`, err);
              }
            }
            if (!aiSuccess) {
              const fallback = getFallbackUrl("video", course.title, v.title, v.url, vIdx, usedUrlsInCourse);
              url = fallback.url;
              title = fallback.title || v.title;
            } else {
              url = newUrl;
              title = newTitle;
              usedUrlsInCourse.add(url.trim().toLowerCase());
            }
            isWorking = await verifyVideoUrl(url, "video");
            updated = true;
          }
          videoResults.push({ ...v, url, title, isVerified: isWorking });
        }
        const usedAttsInCourse = /* @__PURE__ */ new Set();
        attachments.forEach((a) => {
          if (a.url && a.url !== "#" && a.url.trim() !== "") {
            usedAttsInCourse.add(a.url.trim().toLowerCase());
          }
        });
        const attResults = [];
        for (let aIdx = 0; aIdx < attachments.length; aIdx++) {
          const a = attachments[aIdx];
          if (mode === "broken-only" && a.isVerified === true && a.url && a.url !== "#" && a.url.trim() !== "") {
            attResults.push(a);
            continue;
          }
          let isWorking = await verifyVideoUrl(a.url, "attachment");
          let url = a.url;
          let name = a.name;
          if (!isWorking || !url || url === "#" || url.trim() === "") {
            usedAttsInCourse.delete((a.url || "").trim().toLowerCase());
            let aiSuccess = false;
            let newUrl = "";
            let newTitle = "";
            const prompt = `
            Please use Google Search to find a high-quality, real, active, and working educational PDF/resource URL on the internet.
            We are replacing a broken/invalid URL in our digital course.
            Course Topic: ${course.title}
            Item Title: ${a.name}
            Broken/Old URL: ${a.url}
            
            Instructions:
            1. Search the web to find a real, valid, and active working PDF or document resource URL.
            2. Do NOT guess or make up a fake URL. It must be a real URL.
            3. Return ONLY a valid JSON object matching this schema:
            { "newUrl": "...", "newTitle": "..." }
            `;
            try {
              const cooldownActive = serviceCooldowns["aiBrokenLinkAutoFixer"] && Date.now() < serviceCooldowns["aiBrokenLinkAutoFixer"];
              if (!cooldownActive) {
                const response = await safeGenerateContent(aiBrokenLinkAutoFixer, {
                  model: "gemini-3.5-flash",
                  contents: [{ role: "user", parts: [{ text: prompt }] }],
                  serviceName: "aiBrokenLinkAutoFixer",
                  config: {
                    responseMimeType: "application/json"
                  },
                  tools: [{ googleSearch: {} }]
                });
                await new Promise((r) => setTimeout(r, 4e3));
                if (response) {
                  const responseText = response.text || "{}";
                  const aiData = cleanAndParseJSON(responseText);
                  if (aiData.newUrl && aiData.newUrl.startsWith("http") && !usedAttsInCourse.has(aiData.newUrl.trim().toLowerCase())) {
                    newUrl = aiData.newUrl;
                    newTitle = aiData.newTitle || a.name;
                    if (!newTitle.toLowerCase().endsWith(".pdf")) {
                      newTitle = `${newTitle.replace(/\.[^/.]+$/, "")}.pdf`;
                    }
                    aiSuccess = true;
                  }
                }
              }
            } catch (err) {
              const errMsg = err?.message || String(err);
              if (errMsg.includes("QUOTA") || errMsg.includes("429") || errMsg.includes("cooldown") || errMsg.includes("exhausted") || err?.status === 429) {
                console.log(`[Info] Mass verify auto-heal hit quota limits. Setting cooldown for aiBrokenLinkAutoFixer.`);
                serviceCooldowns["aiBrokenLinkAutoFixer"] = Date.now() + 15 * 60 * 1e3;
              } else {
                console.log(`[Info] Mass verify auto-heal Gemini link fix failed for attachment ${a.name}:`, err);
              }
            }
            if (!aiSuccess) {
              const fallback = getFallbackUrl("attachment", course.title, a.name, a.url, aIdx, usedAttsInCourse);
              url = fallback.url;
              name = fallback.title || a.name;
            } else {
              url = newUrl;
              name = newTitle;
              usedAttsInCourse.add(url.trim().toLowerCase());
            }
            isWorking = await verifyVideoUrl(url, "attachment");
            updated = true;
          }
          attResults.push({ ...a, url, name, isVerified: isWorking });
        }
        if (updated) {
          await updateDoc(doc(db, "courses", courseDoc.id), {
            videos: videoResults,
            attachments: attResults
          });
          allResults.push({ id: courseDoc.id, title: course.title, status: "updated", videos: videoResults, attachments: attResults });
        } else {
          allResults.push({ id: courseDoc.id, title: course.title, status: "ok", videos: videoResults, attachments: attResults });
        }
      }
      res.json({ success: true, results: allResults });
    } catch (error) {
      console.error("Error mass verifying links:", error);
      res.status(500).json({ success: false, error: error.message });
    }
  });
  app.post("/api/admin/verify-single-link", async (req, res) => {
    try {
      const { url, itemType } = req.body;
      const isWorking = await verifyVideoUrl(url, itemType);
      res.json({ success: true, isWorking });
    } catch (error) {
      console.error("Error pre-verifying link:", error);
      res.status(500).json({ success: false, error: error.message });
    }
  });
  app.post("/api/admin/fix-course-links", async (req, res) => {
    try {
      const { courseId } = req.body;
      const courseRef = doc(db, "courses", courseId);
      const courseDoc = await getDoc(courseRef);
      if (!courseDoc.exists()) {
        return res.status(404).json({ success: false, error: "Course not found." });
      }
      const course = courseDoc.data();
      let updated = false;
      const videos = course.videos ? [...course.videos] : [];
      const attachments = course.attachments ? [...course.attachments] : [];
      const usedUrlsInCourse = /* @__PURE__ */ new Set();
      videos.forEach((v) => {
        if (v.url && v.url !== "#" && v.url.trim() !== "") {
          usedUrlsInCourse.add(v.url.trim().toLowerCase());
        }
      });
      const usedAttsInCourse = /* @__PURE__ */ new Set();
      attachments.forEach((a) => {
        if (a.url && a.url !== "#" && a.url.trim() !== "") {
          usedAttsInCourse.add(a.url.trim().toLowerCase());
        }
      });
      const videoResults = [];
      for (let vIdx = 0; vIdx < videos.length; vIdx++) {
        const v = videos[vIdx];
        let isWorking = await verifyVideoUrl(v.url, "video");
        let url = v.url;
        let title = v.title;
        if (!isWorking || !url || url === "#" || url.trim() === "") {
          usedUrlsInCourse.delete(v.url.trim().toLowerCase());
          let aiSuccess = false;
          let newUrl = "";
          let newTitle = "";
          const prompt = `
          Please use Google Search to find a high-quality, real, active, and working YouTube video URL on the internet.
          We are replacing a broken/invalid URL in our digital course.
          Course Topic: ${course.title}
          Item Title: ${v.title}
          Broken/Old URL: ${v.url}
          
          Instructions:
          1. Search the web/YouTube to find a real, valid, and active working video URL.
          2. Do NOT guess or make up a fake URL. It must be a real URL.
          3. Return ONLY a valid JSON object matching this schema:
          { "newUrl": "...", "newTitle": "..." }
          `;
          try {
            const cooldownActive = serviceCooldowns["aiBrokenLinkAutoFixer"] && Date.now() < serviceCooldowns["aiBrokenLinkAutoFixer"];
            if (!cooldownActive) {
              const response = await safeGenerateContent(aiBrokenLinkAutoFixer, {
                model: "gemini-3.5-flash",
                contents: [{ role: "user", parts: [{ text: prompt }] }],
                serviceName: "aiBrokenLinkAutoFixer",
                config: {
                  responseMimeType: "application/json",
                  tools: [{ googleSearch: {} }]
                }
              });
              const responseText = response.text || "{}";
              const aiData = cleanAndParseJSON(responseText);
              if (aiData.newUrl && aiData.newUrl.startsWith("http") && !usedUrlsInCourse.has(aiData.newUrl.trim().toLowerCase())) {
                newUrl = aiData.newUrl;
                newTitle = aiData.newTitle || v.title;
                aiSuccess = true;
              }
            }
          } catch (err) {
            const errMsg = err?.message || String(err);
            if (errMsg.includes("QUOTA") || errMsg.includes("429") || errMsg.includes("cooldown") || errMsg.includes("exhausted") || err?.status === 429) {
              console.log(`[Info] Fix course links hit quota limits. Setting cooldown for aiBrokenLinkAutoFixer.`);
              serviceCooldowns["aiBrokenLinkAutoFixer"] = Date.now() + 15 * 60 * 1e3;
            } else {
              console.log(`[Info] Gemini link auto-fix failed for video ${v.title}:`, err);
            }
          }
          if (!aiSuccess) {
            const fallback = getFallbackUrl("video", course.title, v.title, v.url, vIdx, usedUrlsInCourse);
            url = fallback.url;
            title = fallback.title || v.title;
          } else {
            url = newUrl;
            title = newTitle;
            usedUrlsInCourse.add(url.trim().toLowerCase());
          }
          isWorking = await verifyVideoUrl(url, "video");
          updated = true;
          videoResults.push({ ...v, url, title, isVerified: isWorking });
        } else {
          videoResults.push(v);
        }
      }
      const attResults = [];
      for (let aIdx = 0; aIdx < attachments.length; aIdx++) {
        const a = attachments[aIdx];
        let isWorking = await verifyVideoUrl(a.url, "attachment");
        let url = a.url;
        let name = a.name;
        if (!isWorking || !url || url === "#" || url.trim() === "") {
          usedAttsInCourse.delete(a.url.trim().toLowerCase());
          let aiSuccess = false;
          let newUrl = "";
          let newTitle = "";
          const prompt = `
          Please use Google Search to find a high-quality, real, active, and working educational PDF/resource URL on the internet.
          We are replacing a broken/invalid URL in our digital course.
          Course Topic: ${course.title}
          Item Title: ${a.name}
          Broken/Old URL: ${a.url}
          
          Instructions:
          1. Search the web to find a real, valid, and active working PDF or document resource URL.
          2. Do NOT guess or make up a fake URL. It must be a real URL.
          3. Return ONLY a valid JSON object matching this schema:
          { "newUrl": "...", "newTitle": "..." }
          `;
          try {
            const cooldownActive = serviceCooldowns["aiBrokenLinkAutoFixer"] && Date.now() < serviceCooldowns["aiBrokenLinkAutoFixer"];
            if (!cooldownActive) {
              const response = await safeGenerateContent(aiBrokenLinkAutoFixer, {
                model: "gemini-3.5-flash",
                contents: [{ role: "user", parts: [{ text: prompt }] }],
                serviceName: "aiBrokenLinkAutoFixer",
                config: {
                  responseMimeType: "application/json",
                  tools: [{ googleSearch: {} }]
                }
              });
              const responseText = response.text || "{}";
              const aiData = cleanAndParseJSON(responseText);
              if (aiData.newUrl && aiData.newUrl.startsWith("http") && !usedAttsInCourse.has(aiData.newUrl.trim().toLowerCase())) {
                newUrl = aiData.newUrl;
                newTitle = aiData.newTitle || a.name;
                aiSuccess = true;
              }
            }
          } catch (err) {
            const errMsg = err?.message || String(err);
            if (errMsg.includes("QUOTA") || errMsg.includes("429") || errMsg.includes("cooldown") || errMsg.includes("exhausted") || err?.status === 429) {
              console.log(`[Info] Fix course links hit quota limits. Setting cooldown for aiBrokenLinkAutoFixer.`);
              serviceCooldowns["aiBrokenLinkAutoFixer"] = Date.now() + 15 * 60 * 1e3;
            } else {
              console.log(`[Info] Gemini link auto-fix failed for attachment ${a.name}:`, err);
            }
          }
          if (!aiSuccess) {
            const fallback = getFallbackUrl("attachment", course.title, a.name, a.url, aIdx, usedAttsInCourse);
            url = fallback.url;
            name = fallback.title || a.name;
          } else {
            url = newUrl;
            name = newTitle;
            usedAttsInCourse.add(url.trim().toLowerCase());
          }
          isWorking = await verifyVideoUrl(url, "attachment");
          updated = true;
          attResults.push({ ...a, url, name, isVerified: isWorking });
        } else {
          attResults.push(a);
        }
      }
      if (updated) {
        await updateDoc(courseRef, {
          videos: videoResults,
          attachments: attResults
        });
        res.json({ success: true, updatedVideos: videoResults, updatedAttachments: attResults });
      } else {
        res.json({ success: true, updatedVideos: videos, updatedAttachments: attachments });
      }
    } catch (error) {
      console.error("Error atomic auto-fixing course links:", error);
      res.status(500).json({ success: false, error: error.message });
    }
  });
  app.post("/api/admin/reverify-link", async (req, res) => {
    try {
      const { courseId, itemType, itemIndex, currentUrl } = req.body;
      const isWorking = await verifyVideoUrl(currentUrl, itemType);
      const courseRef = doc(db, "courses", courseId);
      const courseDoc = await getDoc(courseRef);
      if (!courseDoc.exists()) throw new Error("Course not found.");
      const course = courseDoc.data();
      if (itemType === "video") {
        course.videos[itemIndex].isVerified = isWorking;
      } else {
        course.attachments[itemIndex].isVerified = isWorking;
      }
      await updateDoc(courseRef, {
        videos: course.videos,
        attachments: course.attachments
      });
      res.json({ success: true, isVerified: isWorking });
    } catch (error) {
      console.error("Error re-verifying link:", error);
      res.status(500).json({ success: false, error: error.message });
    }
  });
  app.post("/api/admin/fix-link", async (req, res) => {
    try {
      const { courseId, itemType, itemIndex, newUrl, isManual, currentTitle, currentUrl, courseTitle } = req.body;
      const courseRef = doc(db, "courses", courseId);
      const courseDoc = await getDoc(courseRef);
      if (!courseDoc.exists()) throw new Error("Course not found.");
      const course = courseDoc.data();
      let finalUrl = newUrl;
      let finalTitle = currentTitle;
      let aiData = { newUrl: "", newTitle: "" };
      if (isManual) {
        aiData = { newUrl, newTitle: currentTitle };
      } else {
        const usedUrlsInCourse = /* @__PURE__ */ new Set();
        if (itemType === "video" && course.videos) {
          course.videos.forEach((v, idx) => {
            if (idx !== itemIndex && v.url && v.url !== "#" && v.url.trim() !== "") {
              usedUrlsInCourse.add(v.url.trim().toLowerCase());
            }
          });
        } else if (itemType === "attachment" && course.attachments) {
          course.attachments.forEach((a, idx) => {
            if (idx !== itemIndex && a.url && a.url !== "#" && a.url.trim() !== "") {
              usedUrlsInCourse.add(a.url.trim().toLowerCase());
            }
          });
        }
        const prompt = `
        Find a high-quality, working replacement URL for a broken ${itemType === "video" ? "YouTube video" : "educational PDF/resource"} in a course.
        
        Course Topic: ${courseTitle}
        Item Title: ${currentTitle}
        Broken URL: ${currentUrl}
        
        Requirements:
        1. Search the web for a REAL, HIGH-QUALITY, AND WORKING replacement.
        2. If video: Provide a working YouTube URL from a reputable channel.
        3. If attachment: Provide a REAL, WORKING educational resource URL (GitHub repo, PDF documentation, or official site).
        4. Return ONLY a JSON object with: { "newUrl": "...", "newTitle": "..." }
        
        RULES:
        - NO Hallucinations. The URL MUST exist.
        - The title must match the content of the new URL.
        `;
        let success = false;
        try {
          const cooldownActive = serviceCooldowns["aiBrokenLinkAutoFixer"] && Date.now() < serviceCooldowns["aiBrokenLinkAutoFixer"];
          if (!cooldownActive) {
            const response = await safeGenerateContent(aiBrokenLinkAutoFixer, {
              model: "gemini-3.5-flash",
              contents: [{ role: "user", parts: [{ text: prompt }] }],
              serviceName: "aiBrokenLinkAutoFixer",
              config: {
                responseMimeType: "application/json"
              },
              tools: [{ googleSearch: {} }]
            });
            if (response && response.text) {
              const text = response.text;
              aiData = cleanAndParseJSON(text);
              if (aiData.newUrl && aiData.newUrl.startsWith("http")) {
                success = true;
              }
            }
          }
        } catch (err) {
          const errMsg = err?.message || String(err);
          if (errMsg.includes("QUOTA") || errMsg.includes("429") || errMsg.includes("cooldown") || errMsg.includes("exhausted") || err?.status === 429) {
            console.log(`[Info] Fix-link hit quota limits. Setting cooldown for aiBrokenLinkAutoFixer.`);
            serviceCooldowns["aiBrokenLinkAutoFixer"] = Date.now() + 15 * 60 * 1e3;
          } else {
            console.log(`[Info] Fix-link Gemini auto-fix failed:`, err);
          }
        }
        if (!success) {
          const fallback = getFallbackUrl(itemType, courseTitle, currentTitle, currentUrl, itemIndex, usedUrlsInCourse);
          aiData = {
            newUrl: fallback.url,
            newTitle: fallback.title
          };
          success = true;
        }
      }
      if (itemType === "video") {
        course.videos[itemIndex].url = aiData.newUrl;
        course.videos[itemIndex].title = aiData.newTitle || currentTitle;
        const isStillBroken = !await verifyVideoUrl(aiData.newUrl, itemType);
        course.videos[itemIndex].isVerified = !isStillBroken;
      } else {
        course.attachments[itemIndex].url = aiData.newUrl;
        course.attachments[itemIndex].name = aiData.newTitle || currentTitle;
        const isStillBroken = !await verifyVideoUrl(aiData.newUrl, itemType);
        course.attachments[itemIndex].isVerified = !isStillBroken;
      }
      await updateDoc(courseRef, {
        videos: course.videos,
        attachments: course.attachments
      });
      res.json({ success: true, updatedItem: itemType === "video" ? course.videos[itemIndex] : course.attachments[itemIndex] });
    } catch (error) {
      console.error("Error fixing broken link:", error);
      res.status(500).json({ success: false, error: error.message });
    }
  });
  app.post("/api/admin/validate-link", async (req, res) => {
    try {
      const { courseId, itemType, itemIndex } = req.body;
      const courseRef = doc(db, "courses", courseId);
      const courseDoc = await getDoc(courseRef);
      if (!courseDoc.exists()) throw new Error("Course not found.");
      const course = courseDoc.data();
      if (itemType === "video") {
        course.videos[itemIndex].isVerified = true;
      } else {
        course.attachments[itemIndex].isVerified = true;
      }
      await updateDoc(courseRef, {
        videos: course.videos,
        attachments: course.attachments
      });
      res.json({ success: true });
    } catch (err) {
      console.error(err);
      res.status(500).json({ success: false, error: "Failed to validate link." });
    }
  });
  app.post("/api/support/chat", async (req, res) => {
    try {
      const { studentEmail, studentName, message, courseId, history } = req.body;
      if (!studentEmail || !message) {
        return res.status(400).json({ error: "Email and message are required." });
      }
      let coursesText = "No courses currently listed.";
      try {
        const coursesSnapshot = await getDocs(collection(db, "courses"));
        const coursesList = [];
        coursesSnapshot.forEach((doc2) => {
          coursesList.push(doc2.data());
        });
        if (coursesList.length > 0) {
          coursesText = coursesList.map((c, i) => {
            return `Course ${i + 1}:
- ID: ${c.id}
- Title: ${c.title}
- Description: ${c.description}
- Category: ${c.category}
- Price: \u20B9${c.price} (Original Price: \u20B9${c.originalPrice})
- Number of Lectures: ${c.lecturesCount || 1}
- Included Files: ${c.filesCount || (c.attachments ? c.attachments.length : 0)}`;
          }).join("\n\n");
        }
      } catch (e) {
        console.error("Error loading courses for support chat context:", e);
      }
      const chatHistory = Array.isArray(history) ? history : [];
      const recentHistory = chatHistory.slice(-15);
      const contents = [
        ...recentHistory.map((m) => {
          const isUser = m.senderId?.toLowerCase() !== "admin@admin.com";
          return {
            role: isUser ? "user" : "model",
            parts: [{ text: `${m.senderName || "Student"}: ${m.message}` }]
          };
        }),
        {
          role: "user",
          parts: [{ text: `${studentName || "Student"}: ${message}` }]
        }
      ];
      const systemInstruction = `
You are a highly helpful, intelligent, and professional human Customer Support Representative for our premium course portal (The New Tips Courses).
Your primary goal is to chat with students as a human support agent, answer their queries exactly, and guide them through their journey.

CRITICAL INSTRUCTIONS:
1. NO AI/BOT ATTRIBUTION:
- You must NEVER mention, reveal, or suggest that you are an AI, a chatbot, an assistant, a model, or Gemini.
- Always speak as a real human member of the "Support Team" or "Admin". If asked, say you are a human support representative of The New Tips Courses.
- Do not use bot-like phrases or templates that sound like a robotic automated assistant.

2. LANGUAGE:
- You must speak in Hindi (Devanagari script, e.g., "\u0928\u092E\u0938\u094D\u0924\u0947! \u092E\u0948\u0902 \u0906\u092A\u0915\u0940 \u0915\u0948\u0938\u0947 \u092E\u0926\u0926 \u0915\u0930 \u0938\u0915\u0924\u093E \u0939\u0942\u0901?"), Hinglish (Hindi written in English alphabet, e.g., "Aap is course me enroll kar sakte hain."), or English based on how the student interacts with you. Give a high preference to Hindi and Hinglish since most of our students communicate in Hindi.
- If they ask in Hindi, respond beautifully in clear Hindi (Devanagari).

3. STRICT RELEVANCE & NO DUMPING OF ALL COURSES:
- DO NOT list or mention all courses unless the user explicitly asks to show or list all available courses.
- Only answer EXACTLY what is asked about the website or a specific course. For example, if they ask about "React" or a specific fee, talk only about that. Do not provide details or lists of unrelated courses.
- If they ask a general question about the portal, answer precisely.

Here is our course catalog for your reference (use this ONLY to find details for the specific item the user is asking about):
${coursesText}

Helpful guidelines for interaction:
- Be extremely polite, positive, warm, and professional.
- Mention that payment is fully secured and processed instantly through UPI or Razorpay, unlocking immediate lifetime access to lecture videos and downloadable study guides.
- Keep answers concise, direct, highly scannable, and extremely targeted.
`;
      let aiText = "";
      let geminiSuccess = false;
      try {
        const cooldownActive = serviceCooldowns["aiChatSupport"] && Date.now() < serviceCooldowns["aiChatSupport"];
        if (!cooldownActive) {
          const response = await safeGenerateContent(aiChatSupport, {
            model: "gemini-3.5-flash",
            contents,
            serviceName: "aiChatSupport",
            config: {
              systemInstruction,
              temperature: 0.7
            }
          });
          if (response && response.text) {
            aiText = response.text;
            geminiSuccess = true;
          }
        }
      } catch (modelError) {
        const errMsg = modelError?.message || String(modelError);
        if (errMsg.includes("429") || errMsg.includes("quota") || errMsg.includes("RESOURCE_EXHAUSTED") || modelError?.status === 429) {
          console.log(`[Info] Support chat hit a temporary rate limit or quota. Setting cooldown for aiChatSupport.`);
          serviceCooldowns["aiChatSupport"] = Date.now() + 15 * 60 * 1e3;
        } else {
          console.log(`[Info] Support chat Gemini call failed:`, modelError);
        }
      }
      if (!geminiSuccess || !aiText) {
        console.warn("Gemini API is currently experiencing high demand. Using offline friendly fallback response.");
        aiText = "\u0928\u092E\u0938\u094D\u0924\u0947! \u0938\u0930\u094D\u0935\u0930 \u092A\u0930 \u0905\u092D\u0940 \u0925\u094B\u0921\u093C\u093E \u0905\u0927\u093F\u0915 \u091F\u094D\u0930\u0948\u092B\u093F\u0915 \u0939\u094B\u0928\u0947 \u0915\u0947 \u0915\u093E\u0930\u0923 \u092E\u0948\u0902 \u0924\u0941\u0930\u0902\u0924 \u0935\u093F\u0938\u094D\u0924\u0943\u0924 \u091C\u0935\u093E\u092C \u0928\u0939\u0940\u0902 \u0926\u0947 \u092A\u093E \u0930\u0939\u093E \u0939\u0942\u0901\u0964 \u0932\u0947\u0915\u093F\u0928 \u0906\u092A \u0928\u093F\u0936\u094D\u091A\u093F\u0902\u0924 \u0930\u0939\u0947\u0902, \u0939\u092E\u093E\u0930\u0947 \u0915\u094B\u0930\u094D\u0938\u0947\u0938 \u092A\u0930 \u0905\u092D\u0940 \u092C\u0947\u0939\u0924\u0930\u0940\u0928 \u0911\u092B\u0930 \u091A\u0932 \u0930\u0939\u0947 \u0939\u0948\u0902 \u0914\u0930 \u092A\u0947\u092E\u0947\u0902\u091F \u092A\u0942\u0930\u0940 \u0924\u0930\u0939 \u0938\u0941\u0930\u0915\u094D\u0937\u093F\u0924 \u0939\u0948\u0964 \u092F\u0926\u093F \u0906\u092A\u0915\u093E \u0915\u094B\u0908 \u0935\u093F\u0936\u0947\u0937 \u0938\u0935\u093E\u0932 \u0939\u0948, \u0924\u094B \u0906\u092A \u0939\u092E\u0947\u0902 \u0938\u0940\u0927\u0947 \u0938\u0902\u092A\u0930\u094D\u0915 \u0915\u0930 \u0938\u0915\u0924\u0947 \u0939\u0948\u0902 \u092F\u093E \u0925\u094B\u0921\u093C\u0940 \u0926\u0947\u0930 \u092E\u0947\u0902 \u092B\u093F\u0930 \u0938\u0947 \u092E\u0948\u0938\u0947\u091C \u092D\u0947\u091C \u0938\u0915\u0924\u0947 \u0939\u0948\u0902\u0964 \u0927\u0928\u094D\u092F\u0935\u093E\u0926!";
      }
      const replyDocId = `reply_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
      await setDoc(doc(db, "support_messages", replyDocId), {
        id: replyDocId,
        senderId: "admin@admin.com",
        senderName: "Support Team",
        message: aiText,
        timestamp: Date.now(),
        isRead: false,
        courseId: courseId || null,
        recipientId: studentEmail.toLowerCase()
      });
      res.json({ success: true, response: aiText });
    } catch (error) {
      console.error("Error in support chat API route:", error);
      res.status(500).json({ error: "Internal server error.", details: error?.message || String(error) });
    }
  });
  function enrichSyllabusAndSummariesInHindi(course) {
    let markdown = course.guideMarkdown || "";
    let videoSummarySection = `

---

## \u{1F4CB} Complete Video Course Details (Video Lectures Index in Hinglish)

Is course ke sabhi video lectures ka poora detail niche diya gaya hai. Ye sabhi videos practical tools aur aasan Hindi/Hinglish language me hain taaki aap bina kisi pareshani ke seekh sakein:

`;
    course.videos.forEach((v, index) => {
      videoSummarySection += `### \u{1F3A5} Lecture ${index + 1}: ${v.title}
`;
      videoSummarySection += `* **Ye video kya sikhata hai**: `;
      const titleLower = v.title.toLowerCase();
      if (titleLower.includes("termux") || titleLower.includes("hack") || titleLower.includes("security")) {
        videoSummarySection += `Is video me aap Termux emulator ko setup karna aur basic cyber security commands ka use seekhenge. Ye bilkul safe aur ethical tareeqo se kaam karta hai.
`;
      } else if (titleLower.includes("stock") || titleLower.includes("option") || titleLower.includes("trad") || titleLower.includes("market") || titleLower.includes("chart")) {
        videoSummarySection += `Ye video aapko share market ke basic rules, chart reading aur support/resistance ki pehchan karna aasan Hindi/Hinglish me sikhayega.
`;
      } else if (titleLower.includes("figma") || titleLower.includes("design") || titleLower.includes("ux") || titleLower.includes("ui")) {
        videoSummarySection += `Is video me Figma UI/UX tool ka live demonstration kiya gaya hai. Aap seekhenge ki kaise beautiful websites aur apps ke UI layouts ready kiye jaate hain.
`;
      } else if (titleLower.includes("prompt") || titleLower.includes("chatgpt") || titleLower.includes("ai") || titleLower.includes("automation")) {
        videoSummarySection += `Is video me aap Artificial Intelligence (AI) aur ChatGPT ka use karke automation workflow banana seekhenge, jisse aapka time aur effort bachega.
`;
      } else if (titleLower.includes("html") || titleLower.includes("css") || titleLower.includes("web") || titleLower.includes("react") || titleLower.includes("javascript")) {
        videoSummarySection += `Is video me web development ke main pillars (HTML/CSS/JavaScript/React) ko live coding project ke saath aasan tareeqe se samjhaya gaya hai.
`;
      } else if (titleLower.includes("kotlin") || titleLower.includes("android") || titleLower.includes("app") || titleLower.includes("flutter")) {
        videoSummarySection += `Is video me mobile application banane ke liye jaruri software install karne aur ek basic working mobile app banane ka practical tarika dikhaya gaya hai.
`;
      } else {
        videoSummarySection += `Ye video is course ka ek bahut important part hai, jisme aapko practical examples aur live screen demonstration ke saath main principles sikhaye gaye hain.
`;
      }
      videoSummarySection += `* **Ye kaise kaam karega**: Video play button par click karein. Sabhi videos live streaming aur high-definition quality me chalenge. Ensure karein ki aapka internet connection active hai.

`;
    });
    let pdfSummarySection = `
## \u{1F4C2} Premium Resources and PDF Download Directory (Resources Guide)

Is course me diye gaye sabhi study materials aur PDF files ki details aur unhe use karne ka tarika niche diya gaya hai:

`;
    const printableAttachments = (course.attachments || []).filter((a) => a.id !== "att_hindi_syllabus_guide");
    printableAttachments.forEach((a, index) => {
      pdfSummarySection += `### \u{1F4C4} Resource ${index + 1}: ${a.name}
`;
      pdfSummarySection += `* **Is PDF me kya hai**: `;
      const nameLower = a.name.toLowerCase();
      if (nameLower.includes("guide") || nameLower.includes("handwritten") || nameLower.includes("notes") || nameLower.includes("syllabus")) {
        pdfSummarySection += `Is guide me poore syllabus ke written aur short notes hain, jinhe padhkar aap bahut jaldi poore course ka revision kar sakte hain. Isme important commands aur formulas hain.
`;
      } else if (nameLower.includes("cheat") || nameLower.includes("sheet")) {
        pdfSummarySection += `Ye ek quick reference cheat-sheet hai, jisme is technology ke sabhi jaruri codes, shortcuts aur terms ek hi jagah collect kiye gaye hain.
`;
      } else if (nameLower.includes("code") || nameLower.includes("source") || nameLower.includes("pdf") || nameLower.includes("github")) {
        pdfSummarySection += `Is file me practical lessons ke sources aur important step-by-step documentation available hai, jise aap reference ke liye padh sakte hain.
`;
      } else {
        pdfSummarySection += `Ye ek premium study manual aur resource guide hai, jo aapko practical knowledge badhane aur live projects ko complete karne me help karegi.
`;
      }
      pdfSummarySection += `* **Ye kaise kaam karega aur isko kaise use karein**: Download button par click karke file ko apne device par save karein. PDF reader ya web browser se ise open karein aur practical practice karte waqt iska help lein.

`;
    });
    return markdown + videoSummarySection + pdfSummarySection;
  }
  function getHighQualityThumbnail(title, category) {
    const lowerTitle = title.toLowerCase();
    if (category === "ETHICAL HACKING") {
      if (lowerTitle.includes("termux")) return "https://images.unsplash.com/photo-1601597111158-2fceff270190?w=800&auto=format&fit=crop";
      if (lowerTitle.includes("kali") || lowerTitle.includes("linux")) return "https://images.unsplash.com/photo-1629654297299-c8506221ca97?w=800&auto=format&fit=crop";
      if (lowerTitle.includes("network") || lowerTitle.includes("nmap") || lowerTitle.includes("scan")) return "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=800&auto=format&fit=crop";
      return "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&auto=format&fit=crop";
    }
    if (category === "TRADING & FINANCE") {
      if (lowerTitle.includes("option") || lowerTitle.includes("future")) return "https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?w=800&auto=format&fit=crop";
      if (lowerTitle.includes("crypto") || lowerTitle.includes("bitcoin")) return "https://images.unsplash.com/photo-1516245834210-c4c142787335?w=800&auto=format&fit=crop";
      return "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=800&auto=format&fit=crop";
    }
    if (category === "AI & AUTOMATION") {
      if (lowerTitle.includes("chatgpt") || lowerTitle.includes("prompt")) return "https://images.unsplash.com/photo-1677442136019-21780efad99a?w=800&auto=format&fit=crop";
      return "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop";
    }
    if (category === "WEB DEVELOPMENT") {
      if (lowerTitle.includes("react")) return "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=800&auto=format&fit=crop";
      return "https://images.unsplash.com/photo-1547082299-de196ea013d6?w=800&auto=format&fit=crop";
    }
    if (category === "APP DEVELOPMENT") {
      return "https://images.unsplash.com/photo-1607252650355-f7fd0460ccdb?w=800&auto=format&fit=crop";
    }
    if (category === "DESIGN & EDITING") {
      if (lowerTitle.includes("figma") || lowerTitle.includes("ui") || lowerTitle.includes("ux")) return "https://images.unsplash.com/photo-1611532736597-de2d4265fba3?w=800&auto=format&fit=crop";
      return "https://images.unsplash.com/photo-1626785774573-4b799315345d?w=800&auto=format&fit=crop";
    }
    return "https://images.unsplash.com/photo-1516116211223-4c599762411e?w=800&auto=format&fit=crop";
  }
  const videoPools = {
    "ETHICAL HACKING": [
      { title: "Termux Ethical Hacking: Complete A to Z Practical Course", url: "https://www.youtube.com/watch?v=S0169R_C_S0" },
      { title: "Linux Command Line Basics for Beginners in Termux", url: "https://www.youtube.com/watch?v=bO763TclD9I" },
      { title: "Metasploit Framework Installation & Usage in Termux", url: "https://www.youtube.com/watch?v=N_v9yU19Q1k" },
      { title: "Nmap Network Scanning Practical Guide for Students", url: "https://www.youtube.com/watch?v=X0K1Tq2A-M4" },
      { title: "Wireless Security & Pentesting Roadmap 2024", url: "https://www.youtube.com/watch?v=kYmZ6v2E5vA" },
      { title: "Bug Bounty Hunting for Beginners - Step by Step", url: "https://www.youtube.com/watch?v=hW6N2j_W_A4" }
    ],
    "TRADING & FINANCE": [
      { title: "Stock Market Basics for Beginners (Hindi Masterclass)", url: "https://www.youtube.com/watch?v=Xn7KPTGZ6B8" },
      { title: "Price Action Trading Strategies: Support & Resistance", url: "https://www.youtube.com/watch?v=gT8BfG2L3uA" },
      { title: "Risk Management & Trading Psychology Secrets", url: "https://www.youtube.com/watch?v=9N5r8bV2w_w" },
      { title: "Options Trading & Strategy Builder for Students", url: "https://www.youtube.com/watch?v=L_T3W0F7zC8" },
      { title: "Cryptocurrency & Blockchain Technology Full Course", url: "https://www.youtube.com/watch?v=rYQgy8QDEBI" }
    ],
    "DESIGN & EDITING": [
      { title: "Figma UI/UX Design Complete Course for Beginners", url: "https://www.youtube.com/watch?v=c9Wg6Ry_YgU" },
      { title: "Auto Layout, Resizable Components & Design Systems", url: "https://www.youtube.com/watch?v=y7Ssc_X-HSw" },
      { title: "Video Editing Foundations: Complete Premiere Pro Guide", url: "https://www.youtube.com/watch?v=f0v23KscCIE" },
      { title: "Graphic Designing Principles & Essential Freelancing Tips", url: "https://www.youtube.com/watch?v=un50Bs4BvZ8" },
      { title: "Adobe Illustrator Crash Course for Designers", url: "https://www.youtube.com/watch?v=Ib8UBwu3yTQ" },
      { title: "After Effects Motion Graphics Masterclass", url: "https://www.youtube.com/watch?v=w_P9U4E_z_U" },
      { title: "Photoshop Editing Masterclass - Zero to Hero", url: "https://www.youtube.com/watch?v=vV1p8_iP7M0" }
    ],
    "AI & AUTOMATION": [
      { title: "ChatGPT Prompt Engineering Masterclass for Beginners", url: "https://www.youtube.com/watch?v=mBYu5NoWdSU" },
      { title: "AI Automation Agency (AAA) & No-Code Workflow Setup", url: "https://www.youtube.com/watch?v=7CqJlxBYj-M" },
      { title: "YouTube & Instagram AI Video Content Automation Secrets", url: "https://www.youtube.com/watch?v=gDiEcL_r6p4" },
      { title: "Python Programming Course for Absolute Beginners", url: "https://www.youtube.com/watch?v=rfscVS0vtbw" },
      { title: "Generative AI & LLMs Explained - Modern Guide", url: "https://www.youtube.com/watch?v=5sLYAQS9s8U" },
      { title: "No-Code AI App Building with Bubble & Zapier", url: "https://www.youtube.com/watch?v=H68qB_eU6Hk" }
    ],
    "WEB DEVELOPMENT": [
      { title: "HTML & CSS Complete Web Development Tutorial", url: "https://www.youtube.com/watch?v=mU6an7qMCsc" },
      { title: "JavaScript Programming Language Crash Course", url: "https://www.youtube.com/watch?v=PkZNo7MFNFg" },
      { title: "React JS Core Concepts, Hooks & State Management", url: "https://www.youtube.com/watch?v=Ke90Tje7VS0" },
      { title: "MERN Stack Web Application Integration Guide", url: "https://www.youtube.com/watch?v=7CqJlxBYj-M" },
      { title: "Tailwind CSS & Modern UI Design Frameworks", url: "https://www.youtube.com/watch?v=UBOj6rqRUME" },
      { title: "Next.js 14 Full Stack Development Roadmap", url: "https://www.youtube.com/watch?v=wm5gMKuwSYk" },
      { title: "Node.js & Express.js Backend API Development", url: "https://www.youtube.com/watch?v=Oe421EPjeBE" }
    ],
    "APP DEVELOPMENT": [
      { title: "Android App Development with Kotlin Studio Setup", url: "https://www.youtube.com/watch?v=fis26HlhDII" },
      { title: "Kotlin Programming Language Fundamentals Masterclass", url: "https://www.youtube.com/watch?v=FJRmhyMx060" },
      { title: "Jetpack Compose: Building Modern Android App UIs", url: "https://www.youtube.com/watch?v=Ch5pH8v8SFA" },
      { title: "REST APIs, Retrofit & Firebase Mobile Database Setup", url: "https://www.youtube.com/watch?v=EExSSotojxs" },
      { title: "Flutter App Development Crash Course - 2024", url: "https://www.youtube.com/watch?v=VPvVD8t02U8" },
      { title: "React Native Mobile Apps for iOS & Android", url: "https://www.youtube.com/watch?v=0-S5a0eXPoc" }
    ],
    "DEVELOPMENT": [
      { title: "Python Programming Course for Absolute Beginners", url: "https://www.youtube.com/watch?v=rfscVS0vtbw" },
      { title: "Introduction to Computer Science & Coding Basics", url: "https://www.youtube.com/watch?v=HXV3zeQKqGY" },
      { title: "Git, GitHub & Version Control Roadmap", url: "https://www.youtube.com/watch?v=Ke90Tje7VS0" },
      { title: "Web Development Career Roadmap & Building Projects", url: "https://www.youtube.com/watch?v=7CqJlxBYj-M" },
      { title: "SQL & Database Design Masterclass for Developers", url: "https://www.youtube.com/watch?v=HXV3zeQKqGY" },
      { title: "C++ Programming for Game Development", url: "https://www.youtube.com/watch?v=vLnPwxZdW4Y" }
    ],
    "MARKETING": [
      { title: "Digital Marketing Full Course - 12 Hours Masterclass", url: "https://www.youtube.com/watch?v=nU-IIXBWlS4" },
      { title: "Social Media Marketing Strategy for Beginners", url: "https://www.youtube.com/watch?v=8p9vD0H6lU0" },
      { title: "SEO (Search Engine Optimization) Complete Tutorial", url: "https://www.youtube.com/watch?v=DvwS7cV9GmQ" },
      { title: "Facebook & Instagram Ads Masterclass Guide", url: "https://www.youtube.com/watch?v=9jD_v17oHIs" },
      { title: "Google Ads Tutorial for Beginners 2024", url: "https://www.youtube.com/watch?v=1pE6mX_h7yY" },
      { title: "Content Marketing Mastery - Zero to Hero", url: "https://www.youtube.com/watch?v=un50Bs4BvZ8" }
    ]
  };
  const attachmentPools = {
    "ETHICAL HACKING": [
      { name: "Termux Hacking Step-by-Step Guide (Full Hindi/English).pdf", url: "https://github.com/vavkamil/awesome-bugbounty-tools/blob/master/README.md", size: "15.4 MB" },
      { name: "Ethical Hacking Practical Workbook & Notes.pdf", url: "https://github.com/mrd0x/The-Hacker-Playbook/blob/master/README.md", size: "8.2 MB" },
      { name: "Linux Termux Command Master Cheat Sheet.pdf", url: "https://cheatsheetseries.owasp.org/cheatsheets/Web_Application_Penetration_Testing_Cheat_Sheet.html", size: "5.1 MB" }
    ],
    "MARKETING": [
      { name: "Digital Marketing Step-by-Step Master Plan.pdf", url: "https://www.investopedia.com/terms/d/digital-marketing.asp", size: "10.1 MB" },
      { name: "Social Media Strategy Builder Template.pdf", url: "https://github.com/vavkamil/awesome-bugbounty-tools/blob/master/README.md", size: "7.4 MB" },
      { name: "SEO Optimization Cheat Sheet & Checklist.pdf", url: "https://github.com/mrd0x/The-Hacker-Playbook/blob/master/README.md", size: "4.8 MB" }
    ],
    "TRADING & FINANCE": [
      { name: "Stock Market Trading Masterclass Guide (Step-by-Step).pdf", url: "https://www.investopedia.com/articles/basics/06/invest1000.asp", size: "12.2 MB" },
      { name: "Practical Options Trading Strategy Manual.pdf", url: "https://github.com/tradier/tradier-python/blob/master/README.md", size: "9.5 MB" },
      { name: "Wealth Building & Finance Roadmap (Detailed).pdf", url: "https://www.investopedia.com/terms/f/financial-freedom.asp", size: "4.5 MB" }
    ],
    "DESIGN & EDITING": [
      { name: "UI/UX Design Systems Template.pdf", url: "https://www.figma.com/community/file/1023347101562916848", size: "18.2 MB" },
      { name: "Graphic Design Master Bundle.pdf", url: "https://github.com/awesome-selfhosted/awesome-selfhosted", size: "3.4 MB" },
      { name: "Video Editing Asset Pack.pdf", url: "https://github.com/mifi/lossless-cut", size: "25.0 MB" }
    ],
    "WEB DEVELOPMENT": [
      { name: "Full Stack Web Development E-Book.pdf", url: "https://github.com/getify/You-Dont-Know-JS", size: "15.0 MB" },
      { name: "React JS Best Practices Cheat Sheet.pdf", url: "https://github.com/sudheerj/reactjs-interview-questions", size: "3.2 MB" },
      { name: "MERN Stack Project Source Code.pdf", url: "https://github.com/adrianhajdin/project_mern_memories", size: "10.5 MB" }
    ],
    "DEVELOPMENT": [
      { name: "Python Programming Master Resource.pdf", url: "https://github.com/asweigart/inventwithpython", size: "22.1 MB" },
      { name: "Coding Interview Patterns Guide.pdf", url: "https://github.com/donnemartin/system-design-primer", size: "8.9 MB" },
      { name: "Software Engineering Career Roadmap.pdf", url: "https://roadmap.sh/software-design-architecture", size: "2.4 MB" }
    ]
  };
  const unsplashPool = {
    "ETHICAL HACKING": "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&auto=format&fit=crop",
    "TRADING & FINANCE": "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=800&auto=format&fit=crop",
    "DESIGN & EDITING": "https://images.unsplash.com/photo-1626785774573-4b799315345d?w=800&auto=format&fit=crop",
    "AI & AUTOMATION": "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop",
    "WEB DEVELOPMENT": "https://images.unsplash.com/photo-1547082299-de196ea013d6?w=800&auto=format&fit=crop",
    "APP DEVELOPMENT": "https://images.unsplash.com/photo-1607252650355-f7fd0460ccdb?w=800&auto=format&fit=crop",
    "DEVELOPMENT": "https://images.unsplash.com/photo-1516116211223-4c599762411e?w=800&auto=format&fit=crop"
  };
  function calculateReasonablePrice(category, numVideos) {
    let price = 499;
    if (category === "ETHICAL HACKING" || category === "TRADING & FINANCE") {
      price = 699;
    } else if (category === "AI & AUTOMATION" || category === "WEB DEVELOPMENT") {
      price = 499;
    } else {
      price = 299 + numVideos % 5 * 50;
    }
    if (price < 299) price = 299;
    if (price > 699) price = 699;
    const originalPrice = price * 5 - 1;
    return {
      price,
      originalPrice
    };
  }
  async function generateAICourseService(selectedTopic, isAutoUpload = false) {
    console.log(`[COURSE-GENERATOR] Initiating generation service for topic: "${selectedTopic}" (AutoUpload: ${isAutoUpload})`);
    const coursesSnapshot = await getDocs(collection(db, "courses"));
    const allCourses = coursesSnapshot.docs.map((doc2) => doc2.data());
    const existingTitles = allCourses.map((c) => c.title).join(", ");
    const usedGlobalVideoUrls = /* @__PURE__ */ new Set();
    const usedGlobalAttachmentUrls = /* @__PURE__ */ new Set();
    allCourses.forEach((c) => {
      if (c.videos) c.videos.forEach((v) => {
        if (v.url && v.url !== "#" && v.url.trim() !== "") usedGlobalVideoUrls.add(v.url.trim().toLowerCase());
      });
      if (c.attachments) c.attachments.forEach((a) => {
        if (a.url && a.url !== "#" && a.url.trim() !== "") usedGlobalAttachmentUrls.add(a.url.trim().toLowerCase());
      });
    });
    const lowerTopic = selectedTopic.toLowerCase();
    let resolvedCategory = "DEVELOPMENT";
    if (lowerTopic.includes("hack") || lowerTopic.includes("cyber") || lowerTopic.includes("ethical") || lowerTopic.includes("security") || lowerTopic.includes("pentest") || lowerTopic.includes("exploit") || lowerTopic.includes("pdf") || lowerTopic.includes("manual") || lowerTopic.includes("kali") || lowerTopic.includes("nmap") || lowerTopic.includes("metasploit") || lowerTopic.includes("wireshark") || lowerTopic.includes("bug bounty") || lowerTopic.includes("termux") || lowerTopic.includes("hydra") || lowerTopic.includes("sqlmap") || lowerTopic.includes("social engine") || lowerTopic.includes("vulnerability") || lowerTopic.includes("scanning")) {
      resolvedCategory = "ETHICAL HACKING";
    } else if (lowerTopic.includes("trad") || lowerTopic.includes("stock") || lowerTopic.includes("option") || lowerTopic.includes("share") || lowerTopic.includes("finance") || lowerTopic.includes("market") || lowerTopic.includes("crypto")) {
      resolvedCategory = "TRADING & FINANCE";
    } else if (lowerTopic.includes("figma") || lowerTopic.includes("ux") || lowerTopic.includes("ui") || lowerTopic.includes("design") || lowerTopic.includes("photoshop") || lowerTopic.includes("graphic") || lowerTopic.includes("video") || lowerTopic.includes("edit")) {
      resolvedCategory = "DESIGN & EDITING";
    } else if (lowerTopic.includes("python") || lowerTopic.includes("machine") || lowerTopic.includes("artificial") || lowerTopic.includes("ai") || lowerTopic.includes("prompt") || lowerTopic.includes("chatgpt") || lowerTopic.includes("automation") || lowerTopic.includes("youtube") || lowerTopic.includes("instagram")) {
      resolvedCategory = "AI & AUTOMATION";
    } else if (lowerTopic.includes("mern") || lowerTopic.includes("web") || lowerTopic.includes("react") || lowerTopic.includes("js") || lowerTopic.includes("node") || lowerTopic.includes("html") || lowerTopic.includes("css") || lowerTopic.includes("javascript")) {
      resolvedCategory = "WEB DEVELOPMENT";
    } else if (lowerTopic.includes("kotlin") || lowerTopic.includes("android") || lowerTopic.includes("app") || lowerTopic.includes("ios") || lowerTopic.includes("swift") || lowerTopic.includes("mobile")) {
      resolvedCategory = "APP DEVELOPMENT";
    } else if (lowerTopic.includes("market") || lowerTopic.includes("social") || lowerTopic.includes("seo") || lowerTopic.includes("ads") || lowerTopic.includes("content") || lowerTopic.includes("facebook") || lowerTopic.includes("instagram") || lowerTopic.includes("sales")) {
      resolvedCategory = "MARKETING";
    }
    const defaultThumb = getHighQualityThumbnail(selectedTopic, resolvedCategory);
    const hackerApiPromptClause = resolvedCategory === "ETHICAL HACKING" ? `CRITICAL HACKER-AI RULE: This is an Ethical Hacking topic. You MUST write an exceptionally rich, extensive, full step-by-step PDF manual / ebook under guideMarkdown.
- Explicitly state at the top of the manual that it is "Powered by Hacker AI & Securely Authorized via AI-Engine-Sync".
- Your step-by-step guide must cover exactly 5 or more prominent cybersecurity tools (such as Termux, Nmap, Metasploit, Wireshark, SQLmap, Hydra, Burp Suite) and clearly detail setup, commands, practical usage and defensive remediation steps.
- The "videos" array MUST contain EXACTLY 5 or more practical, real, working video lectures corresponding to each of these 5+ specific tools. No duplicate or extra videos are allowed. Let each video title describe the practical demo of the tool.
- The "attachments" array MUST contain EXACTLY 5 or more detailed PDF guides/manuals, one dedicated to EACH of the 5 tools described in the guide.` : ``;
    const prompt = `
Generate a fully complete, professional, premium-quality online course in JSON format for the topic: "${selectedTopic}".
The course must be tailored for students who want a real, actionable, step-by-step masterclass (A to Z tutorial series).

CRITICAL: You MUST generate a completely unique course. DO NOT generate a course with a title similar to any of these existing courses: ${existingTitles || "None"}. Make sure the topic is fresh.

${hackerApiPromptClause}

Generate a single JSON object matching the following TypeScript interface:

interface Video {
  id: string;
  title: string; // Must be in Hindi / Hinglish and clearly describe the practical video lecture content
  url: string; // Must be a valid, standard, high-quality YouTube video URL on this topic (e.g. from popular free courses, playlists, or channels)
}

interface Attachment {
  id: string;
  name: string; // Must end strictly with the '.pdf' extension. Must be detailed and in Hindi (e.g. 'Termux_Hacking_Full_Details_Hindi.pdf').
  url: string; // A working downloadable URL for study materials, PDF, or GitHub repository. Ensure that EVERY attachment name ends strictly with the '.pdf' extension (e.g. 'Termux_Basics.pdf').
  size: string; // e.g., "4.5 MB" or "12.1 MB"
}

interface Course {
  id: string; // prefix with "course_ai_" followed by timestamp/random string
  title: string; // e.g., "Advanced Ethical Hacking Masterclass (A to Z)"
  description: string; // High-value rich description explaining what the user will learn
  guideMarkdown: string; // EXTREMELY DETAILED Step-by-Step Practical Guide in Markdown format (minimum 1000 words). Use Hinglish (Hindi + English). Ensure to describe at least 5 tools and setup commands step-by-step.
  price: number; // MUST be strictly set between 299 and 699. Pick a value like 399, 499, or 699 based on course complexity.
  originalPrice: number; // Set to price * 5
  thumbnail: string; // A beautiful, realistic, high-resolution technology-focused image URL from Unsplash
  category: string; // Must be "${resolvedCategory}"
  lecturesCount: number; // Number of video lectures generated (must match length of videos array). AIM FOR EXACTLY 5 TO 10 LECTURES.
  filesCount: number; // Number of attachments generated (must match length of attachments array).
  videos: Video[]; // Create EXACTLY 5 to 10 highly structured, logically ordered lessons. Use REAL, FUNCTIONAL YouTube URLs for the topic. Titles MUST be in Hindi/Hinglish.
  attachments: Attachment[]; // Create EXACTLY 3 to 5 detailed PDF guides or resource cheatsheets in Hindi.
  isAIGenerated: boolean; // Set this strictly to true
  createdAt: number; // Timestamp of current time
}

Ensure the output is ONLY valid JSON. No Markdown formatting backticks. Just the JSON object.
`;
    const systemInstruction = `
You are a senior technical curriculum designer and expert content recruiter.
Your goal is to build PREMIUM, HIGH-VALUE courses that students will actually pay for.
CRITICAL REQUIREMENTS:
1. Videos: Use ONLY real, working, public YouTube links. NEVER invent or hallucinate URLs. ALWAYS search the web to find active, relevant tutorials from major channels. Ensure there are AT LEAST 5 working videos.
2. Content Quality: Every video must have a real title in Hindi/Hinglish that matches the YouTube video's actual content.
3. Description: This must be a SUMMARY of the course value in Hindi/Hinglish.
4. guideMarkdown: This must be a COMPLETE STEP-BY-STEP PRACTICAL MASTERCLASS GUIDE in Hindi/Hinglish (Hinglish/Hindi + English). Explain exactly HOW to do things (e.g. "Step 1: Install Termux", "Step 2: Type pkg install git"). It must be very long and detailed (minimum 1000 words). It MUST include a dedicated "## \u{1F4E6} Project Assets & Downloads" section listing the attachments as downloadable resources.
5. Language: Use Hinglish (Hindi + English) for description, titles, and guideMarkdown to make it feel local and personal.
6. Professionalism: Do not mention AI, bots, or Gemini. The course must look like it was written by a human expert.
7. Attachments: ALWAYS generate high-quality downloadable PDF guides, cheat sheets, checklists, ebooks, or documentation URLs. Ensure that EVERY attachment name ends strictly with the '.pdf' extension (e.g., 'Kali_Linux_Setup_Guide_Hindi.pdf', 'Nmap_Scanning_Commands_Hindi.pdf'). Ensure there are AT LEAST 3 detailed PDFs in Hindi/Hinglish.
8. Strict pricing: The price must be between \u20B9299 and \u20B9699.
`;
    let aiText = "";
    try {
      console.log(`[COURSE-GENERATOR] Initiating generation for "${selectedTopic}"...`);
      const targetService = resolvedCategory === "ETHICAL HACKING" ? hackingAiKey : aiCourseGenerator;
      const targetServiceName = resolvedCategory === "ETHICAL HACKING" ? "hackingAiKey" : "aiCourseGenerator";
      const response = await withTimeout(
        safeGenerateContent(targetService, {
          model: "gemini-3.5-flash",
          contents: [{ role: "user", parts: [{ text: prompt }] }],
          serviceName: targetServiceName,
          config: {
            systemInstruction,
            temperature: 0.8,
            responseMimeType: "application/json"
          },
          tools: [{ googleSearch: {} }]
          // Enable search to find REAL working video URLs
        }),
        3e5,
        // Increased timeout to 5 minutes for search-enabled generation
        `Gemini generation timed out`
      );
      if (response && response.text) {
        aiText = response.text;
        console.log(`[COURSE-GENERATOR] Successful generation for "${selectedTopic}". Length: ${aiText.length}`);
      } else {
        console.error(`[COURSE-GENERATOR] Generation failed: No response text.`, JSON.stringify(response));
      }
    } catch (modelError) {
      console.error(`[COURSE-GENERATOR] Generation failed for "${selectedTopic}" but continuing with robust fallback:`, modelError?.message || String(modelError));
    }
    let generatedCourse;
    if (aiText) {
      try {
        let cleanedJson = aiText.trim();
        if (cleanedJson.startsWith("```")) {
          cleanedJson = cleanedJson.replace(/^```json\s*/i, "").replace(/```$/, "").trim();
        }
        generatedCourse = cleanAndParseJSON(cleanedJson);
        generatedCourse.thumbnail = getHighQualityThumbnail(generatedCourse.title || selectedTopic, resolvedCategory);
        generatedCourse.category = resolvedCategory;
        const verifiedVideos = [];
        const seenUrls = /* @__PURE__ */ new Set();
        for (let i = 0; i < (generatedCourse.videos || []).length; i++) {
          let v = generatedCourse.videos[i];
          const normalized = (v.url || "").trim().toLowerCase();
          if (normalized && !seenUrls.has(normalized)) {
            seenUrls.add(normalized);
            v.isVerified = false;
            v.id = v.id || `v_${verifiedVideos.length + 1}`;
            verifiedVideos.push(v);
          }
        }
        if (verifiedVideos.length < 5) {
          const selectedPool = videoPools[resolvedCategory] || videoPools["DEVELOPMENT"];
          for (let i = 0; i < selectedPool.length; i++) {
            if (verifiedVideos.length >= 5) break;
            const v = selectedPool[i];
            if (!seenUrls.has(v.url.trim().toLowerCase())) {
              seenUrls.add(v.url.trim().toLowerCase());
              verifiedVideos.push({ id: `v_${verifiedVideos.length + 1}`, title: v.title, url: v.url, isVerified: true });
            }
          }
        }
        generatedCourse.videos = verifiedVideos;
        generatedCourse.lecturesCount = generatedCourse.videos.length;
        const verifiedAttachments = [];
        const seenAttachments = /* @__PURE__ */ new Set();
        for (let i = 0; i < (generatedCourse.attachments || []).length; i++) {
          let a = generatedCourse.attachments[i];
          const normalized = (a.url || "").trim().toLowerCase();
          if (normalized && !seenAttachments.has(normalized)) {
            seenAttachments.add(normalized);
            a.isVerified = false;
            a.id = a.id || `att_${verifiedAttachments.length + 1}`;
            if (!a.name.toLowerCase().endsWith(".pdf")) {
              a.name = `${a.name.replace(/\.[^/.]+$/, "")}.pdf`;
            }
            verifiedAttachments.push(a);
          }
        }
        if (verifiedAttachments.length < 3) {
          const selectedAttachmentPool = attachmentPools[resolvedCategory] || attachmentPools["DEVELOPMENT"];
          for (let i = 0; i < selectedAttachmentPool.length; i++) {
            if (verifiedAttachments.length >= 3) break;
            const a = selectedAttachmentPool[i];
            if (!seenAttachments.has(a.url.trim().toLowerCase())) {
              seenAttachments.add(a.url.trim().toLowerCase());
              verifiedAttachments.push({ id: `att_${verifiedAttachments.length + 1}`, name: a.name, url: a.url, size: a.size, isVerified: true });
            }
          }
        }
        generatedCourse.attachments = verifiedAttachments;
        const priceObj = calculateReasonablePrice(generatedCourse.category, generatedCourse.videos.length);
        generatedCourse.price = priceObj.price;
        generatedCourse.originalPrice = priceObj.originalPrice;
        const targetId = `course_ai_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
        generatedCourse.id = targetId;
        generatedCourse.attachments.unshift({
          id: "att_hindi_syllabus_guide",
          name: `[\u0905\u0924\u093F\u0930\u093F\u0915\u094D\u0924 \u092E\u093E\u0930\u094D\u0917\u0926\u0930\u094D\u0936\u0928] \u0938\u092D\u0940 \u0935\u0940\u0921\u093F\u092F\u094B \u0914\u0930 \u092A\u0940\u0921\u0940\u090F\u092B \u0915\u0940 \u091C\u093E\u0928\u0915\u093E\u0930\u0940 \u0914\u0930 \u0909\u092A\u092F\u094B\u0917 \u0935\u093F\u0927\u093F (Hindi).pdf`,
          url: `/api/courses/${targetId}/download-guide`,
          size: "4.5 MB",
          isVerified: true
        });
        generatedCourse.filesCount = generatedCourse.attachments.length;
        generatedCourse.status = isAutoUpload ? "published" : "draft";
        if (resolvedCategory === "ETHICAL HACKING") {
          let baseMarkdown = generatedCourse.guideMarkdown || generatedCourse.description || "";
          if (!baseMarkdown.includes("hsb_bacf5")) {
            generatedCourse.guideMarkdown = `### \u2699\uFE0F **Hacker AI Integration Authorized & Validated**
*This hacking tools manual has been written & authorized using the **Hacker AI Engine API Key** (\`hsb_bacf5b9daca8efbf6c5ed272a1145b33ccb5159a33635181d161669c62342328\`)*

` + baseMarkdown;
          }
        }
        if (!generatedCourse.guideMarkdown || generatedCourse.guideMarkdown.length < 200) {
          generatedCourse.guideMarkdown = generatedCourse.description;
        }
        generatedCourse.guideMarkdown = enrichSyllabusAndSummariesInHindi(generatedCourse);
      } catch (parseErr) {
        console.error("[COURSE-GENERATOR] Error parsing Gemini course JSON, falling back...", parseErr);
      }
    }
    if (!aiText || !generatedCourse) {
      console.warn("[COURSE-GENERATOR] Running offline high-quality fallback generator...");
      const targetId = `course_ai_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      let title = `${selectedTopic} Complete Masterclass (A to Z)`;
      const pool = videoPools[resolvedCategory] || videoPools["DEVELOPMENT"];
      const videos = [];
      const seenFallbackUrls = /* @__PURE__ */ new Set();
      for (let i = 0; i < pool.length; i++) {
        const v = pool[i];
        if (!seenFallbackUrls.has(v.url)) {
          seenFallbackUrls.add(v.url);
          videos.push({
            id: `v_${videos.length + 1}`,
            title: v.title,
            url: v.url,
            isVerified: true
          });
        }
      }
      let attachments = [
        {
          id: "att_1",
          name: `${selectedTopic.replace(/[^a-zA-Z0-9 ]/g, "")} \u0938\u0902\u092A\u0942\u0930\u094D\u0923 \u092A\u094D\u0930\u0948\u0915\u094D\u091F\u093F\u0915\u0932 \u0917\u093E\u0907\u0921 \u0914\u0930 \u0908-\u092C\u0941\u0915 (Hindi Guide).pdf`,
          url: "https://raw.githubusercontent.com/vishwapatel/ethical-hacking-cheat-sheets/master/Ethical-Hacking-Cheat-Sheet.pdf",
          size: "4.8 MB",
          isVerified: true
        },
        {
          id: "att_2",
          name: `${selectedTopic.replace(/[^a-zA-Z0-9 ]/g, "")} \u0939\u0948\u0902\u0921\u094D\u0938-\u0911\u0928 \u0932\u0948\u092C \u0935\u0930\u094D\u0915\u092C\u0941\u0915 (Hindi Lab Workbook).pdf`,
          url: "https://raw.githubusercontent.com/vishwapatel/ethical-hacking-cheat-sheets/master/Ethical-Hacking-Cheat-Sheet.pdf",
          size: "3.2 MB",
          isVerified: true
        },
        {
          id: "att_3",
          name: `${selectedTopic.replace(/[^a-zA-Z0-9 ]/g, "")} \u092E\u0939\u0924\u094D\u0935\u092A\u0942\u0930\u094D\u0923 \u091F\u0942\u0932\u094D\u0938 \u091A\u0940\u091F-\u0936\u0940\u091F \u0914\u0930 \u0928\u094B\u091F\u094D\u0938 (Hindi Cheat-Sheet).pdf`,
          url: "https://raw.githubusercontent.com/vishwapatel/ethical-hacking-cheat-sheets/master/Ethical-Hacking-Cheat-Sheet.pdf",
          size: "1.9 MB",
          isVerified: true
        }
      ];
      const priceObj = calculateReasonablePrice(resolvedCategory, videos.length);
      generatedCourse = {
        id: targetId,
        title,
        description: resolvedCategory === "ETHICAL HACKING" ? `### \u{1F6E1}\uFE0F **Complete Ethical Hacking & Cyber Security Masterclass**

\u0907\u0938 \u0935\u093F\u0936\u0947\u0937 \u0915\u094B\u0930\u094D\u0938 \u092E\u0947\u0902 \u0906\u092A Nmap, Metasploit, Termux \u0914\u0930 Wireshark \u091C\u0948\u0938\u0940 \u0906\u0927\u0941\u0928\u093F\u0915 \u0939\u0948\u0915\u093F\u0902\u0917 \u0914\u0930 \u0938\u093E\u0907\u092C\u0930 \u0938\u0941\u0930\u0915\u094D\u0937\u093E \u091F\u0942\u0932\u094D\u0938 \u0915\u094B \u092C\u093F\u0932\u094D\u0915\u0941\u0932 \u092A\u094D\u0930\u0948\u0915\u094D\u091F\u093F\u0915\u0932 \u0930\u0942\u092A \u0938\u0947 \u0938\u0940\u0916\u0947\u0902\u0917\u0947\u0964 \u092F\u0939 \u0915\u094B\u0930\u094D\u0938 100% \u0935\u094D\u092F\u093E\u0935\u0939\u093E\u0930\u093F\u0915 \u0939\u0948 \u0914\u0930 \u0938\u092D\u0940 \u0935\u094D\u092F\u093E\u0916\u094D\u092F\u093E\u0928 \u0939\u093F\u0902\u0926\u0940/Hinglish \u092E\u0947\u0902 \u0926\u093F\u090F \u0917\u090F \u0939\u0948\u0902\u0964

#### **\u0935\u093F\u0936\u0947\u0937 \u0935\u093F\u0935\u0930\u0923:**
* **Hacker AI Engine Authorized**: \`hsb_bacf5b9daca8efbf6c5ed272a1145b33ccb5159a33635181d161669c62342328\`
* **Step-by-Step Hands-on labs**.` : `### \u{1F31F} **${title}**

\u092F\u0939 \u0935\u094D\u092F\u093E\u092A\u0915 \u0915\u094B\u0930\u094D\u0938 \u0935\u093F\u0936\u0947\u0937 \u0930\u0942\u092A \u0938\u0947 \u0909\u0928 \u091B\u093E\u0924\u094D\u0930\u094B\u0902 \u0915\u0947 \u0932\u093F\u090F \u092C\u0928\u093E\u092F\u093E \u0917\u092F\u093E \u0939\u0948 \u091C\u094B \u092C\u093F\u0932\u094D\u0915\u0941\u0932 \u0936\u0941\u0930\u0941\u0906\u0924\u0940 \u0938\u094D\u0924\u0930 \u0938\u0947 \u0936\u0941\u0930\u0942 \u0915\u0930\u0915\u0947 \u0907\u0938 \u0935\u093F\u0937\u092F \u092E\u0947\u0902 \u092E\u0939\u093E\u0930\u0924 \u0939\u093E\u0938\u093F\u0932 \u0915\u0930\u0928\u093E \u091A\u093E\u0939\u0924\u0947 \u0939\u0948\u0902\u0964 \u0907\u0938\u092E\u0947\u0902 \u0939\u0930 \u090F\u0915 \u092E\u0949\u0921\u094D\u092F\u0942\u0932 \u0915\u094B \u092C\u0939\u0941\u0924 \u0939\u0940 \u0938\u0930\u0932 \u092D\u093E\u0937\u093E (Hinglish) \u092E\u0947\u0902 \u0938\u092E\u091D\u093E\u092F\u093E \u0917\u092F\u093E \u0939\u0948\u0964`,
        guideMarkdown: resolvedCategory === "ETHICAL HACKING" ? `# \u{1F6E1}\uFE0F Hacking Tools Practical Guide (Authorized via Hacker AI)

*This premium manual is authorized & printed using Hacker AI Engine (Key: \`hsb_bacf5b9daca8efbf6c5ed272a1145b33ccb5159a33635181d161669c62342328\`)*

## \u{1F6E0}\uFE0F Step 1: Nmap Scanning Setup
Nmap is a powerful network discovery tool. Install it on Termux or Kali Linux:
\`\`\`bash
pkg install nmap -y
\`\`\`
Run a basic scan on your target environment:
\`\`\`bash
nmap -sV -O scanme.nmap.org
\`\`\`

## \u{1F6E0}\uFE0F Step 2: Metasploit Framework Setup
Metasploit allows you to test network vulnerabilities securely:
\`\`\`bash
pkg install metasploit -y
\`\`\`
Start MSF Console:
\`\`\`bash
msfconsole
\`\`\`

## \u{1F6E0}\uFE0F Step 3: Wireshark Packet Analysis
Capture live network packets and inspect them to secure your personal Wi-Fi network.

## \u{1F6E0}\uFE0F Step 4: Hydra Password Audit
Verify the strength of your SSH credentials:
\`\`\`bash
hydra -l admin -P wordlist.txt ssh://localhost
\`\`\`

## \u{1F6E0}\uFE0F Step 5: SQLmap DB Injection Testing
Test web forms securely against SQL injections:
\`\`\`bash
sqlmap -u "http://testphp.vulnweb.com/listproducts.php?cat=1" --dbs
\`\`\`
` : `# ${selectedTopic} - Practical Masterclass Guide

Is practical guide me hum **${selectedTopic}** ko step-by-step detail me sikhenge. Ye guide beginners se lekar professionals tak sabhi ke liye design ki gayi hai.

## \u{1F4CC} Introduction
Is topic ko samajhne ke liye sabse pehle humein iske core concepts ko clear karna hoga. Ye section aapko basic foundations provide karega.

## \u{1F6E0}\uFE0F Step 1: Necessary Tools & Setup
Kisi bhi kaam ko shuru karne se pehle sahi tools ka hona bahut zaroori hai.
* Agar aap hacking sikh rahe hain to **Termux** ya **Linux** setup karein.
* Agar aap coding kar rahe hain to **VS Code** install karein.
* Agar aap trading kar rahe hain to ek demo account (Paper Trading) se shuru karein.

## \u{1F4BB} Step 2: Practical Implementation (Hands-on)
Ab waqt hai practical karke dekhne ka.
1. **First Module**: Basics commands ya features ko try karein.
2. **Second Module**: Complex tasks ko parts me divide karein.
3. **Troubleshooting**: Errors ko solve karna sikhein (Ye ek real expert ki nishani hai).

## \u2705 Conclusion
Ye guide sirf ek shuruat hai. Continuous practice hi aapko expert banayegi. Humare dashboard me diye gaye videos ko zaroor dekhein.`,
        price: priceObj.price,
        originalPrice: priceObj.originalPrice,
        thumbnail: defaultThumb,
        category: resolvedCategory,
        lecturesCount: videos.length,
        filesCount: attachments.length,
        videos,
        attachments,
        isAIGenerated: true,
        createdAt: Date.now()
      };
      generatedCourse.attachments.unshift({
        id: "att_hindi_syllabus_guide",
        name: `[\u0905\u0924\u093F\u0930\u093F\u0915\u094D\u0924 \u092E\u093E\u0930\u094D\u0917\u0926\u0930\u094D\u0936\u0928] \u0938\u092D\u0940 \u0935\u0940\u0921\u093F\u092F\u094B \u0914\u0930 \u092A\u0940\u0921\u0940\u090F\u092B \u0915\u0940 \u091C\u093E\u0928\u0915\u093E\u0930\u0940 \u0914\u0930 \u0909\u092A\u092F\u094B\u0917 \u0935\u093F\u0927\u093F (Hindi).pdf`,
        url: `/api/courses/${targetId}/download-guide`,
        size: "4.5 MB",
        isVerified: true
      });
      generatedCourse.filesCount = generatedCourse.attachments.length;
      generatedCourse.status = isAutoUpload ? "published" : "draft";
      generatedCourse.guideMarkdown = enrichSyllabusAndSummariesInHindi(generatedCourse);
    }
    generatedCourse.isAIGenerated = true;
    generatedCourse.createdAt = generatedCourse.createdAt || Date.now();
    await setDoc(doc(db, "courses", generatedCourse.id), generatedCourse);
    console.log(`[COURSE-GENERATOR] Course stored successfully. ID: ${generatedCourse.id}`);
    await logSimulatedNewCourseEmail(generatedCourse.title, generatedCourse.price);
    try {
      console.log(`[COURSE-GENERATOR] Pre-verifying & self-healing links for newly generated course: "${generatedCourse.title}"`);
      const updatedVideos = await Promise.all((generatedCourse.videos || []).map(async (v, index) => {
        const isWorking = await verifyVideoUrl(v.url, "video");
        return { ...v, isVerified: isWorking };
      }));
      const updatedAttachments = await Promise.all((generatedCourse.attachments || []).map(async (a, index) => {
        const isWorking = await verifyVideoUrl(a.url, "attachment");
        return { ...a, isVerified: isWorking };
      }));
      const updatedCourse = {
        ...generatedCourse,
        videos: updatedVideos,
        attachments: updatedAttachments
      };
      await setDoc(doc(db, "courses", generatedCourse.id), updatedCourse);
      console.log(`[COURSE-GENERATOR] Validation completed. Newly created course is fully green & active!`);
      return updatedCourse;
    } catch (healErr) {
      console.warn(`[COURSE-GENERATOR] Targeted self-heal validation failed, course saved with defaults.`, healErr);
      return generatedCourse;
    }
  }
  async function checkAndTriggerDailyAutoUpload() {
    try {
      console.log("[DAILY-AUTO-UPLOAD] Running scheduled routine audit...");
      const coursesSnapshot = await getDocs(collection(db, "courses"));
      const allCourses = coursesSnapshot.docs.map((doc2) => doc2.data());
      const last24Hours = Date.now() - 24 * 60 * 60 * 1e3;
      const uploadedInLast24Hours = allCourses.some((c) => c.createdAt && c.createdAt > last24Hours);
      if (uploadedInLast24Hours) {
        console.log("[DAILY-AUTO-UPLOAD] A course has already been uploaded in the last 24 hours. Skipping automatic daily upload.");
        return;
      }
      console.log("[DAILY-AUTO-UPLOAD] No course uploaded in the last 24 hours. Initiating automatic daily upload!");
      const dailyTopicsPool = [
        "Kali Linux Ethical Hacking Beginner Course",
        "Nmap Network Scanning and Vulnerability Guide",
        "Metasploit Framework Practical Masterclass",
        "Wireshark Packet Analysis & Network Pentesting",
        "Bug Bounty Hunting & Web Security Basics",
        "Termux Mobile Pentesting and Linux Commands",
        "Hydra Password Cracking and SSH Hardening",
        "SQLmap Automated SQL Injection Pentesting Course",
        "Social Engineering Defensive and Practical Guide",
        "ChatGPT & Prompt Engineering Masterclass",
        "Stock Market & Options Trading Basics",
        "Figma UI/UX Designing Essentials Course"
      ];
      const unusedTopics = dailyTopicsPool.filter(
        (topic) => !allCourses.some((c) => (c.title || "").toLowerCase().includes(topic.toLowerCase()))
      );
      const finalTopic = unusedTopics.length > 0 ? unusedTopics[Math.floor(Math.random() * unusedTopics.length)] : dailyTopicsPool[Math.floor(Math.random() * dailyTopicsPool.length)] + ` v${Math.floor(Math.random() * 5) + 1}`;
      console.log(`[DAILY-AUTO-UPLOAD] Selected topic for daily generation: "${finalTopic}"`);
      const newCourse = await generateAICourseService(finalTopic, true);
      console.log(`[DAILY-AUTO-UPLOAD] Successfully auto-uploaded & published course: "${newCourse.title}"!`);
    } catch (error) {
      console.error("[DAILY-AUTO-UPLOAD] Scheduled automatic upload failed:", error);
    }
  }
  app.post("/api/admin/generate-ai-course", async (req, res) => {
    try {
      const { topic } = req.body;
      const topics = [
        "Ethical Hacking & Cyber Security",
        "Android App Development with Kotlin",
        "Complete Web Development BootCamp (MERN)",
        "Python Programming & Artificial Intelligence",
        "Stock Market & Options Trading Mastery",
        "Mastering Figma: Premium UI/UX Design Course",
        "Advanced Graphic Designing & Video Editing",
        "ChatGPT & Prompt Engineering for Professionals"
      ];
      const selectedTopic = topic || topics[Math.floor(Math.random() * topics.length)];
      const generatedCourse = await generateAICourseService(selectedTopic, false);
      res.json({ success: true, course: generatedCourse });
    } catch (error) {
      console.error("Error generating manual AI course:", error);
      if (!res.headersSent) {
        res.status(500).json({ error: "Failed to generate AI course", details: error?.message || String(error) });
      }
    }
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.use((err, req, res, next) => {
    console.error("[GLOBAL-ERROR]", err);
    if (!res.headersSent) {
      res.status(500).json({
        success: false,
        error: "Internal Server Error",
        message: err.message || String(err)
      });
    }
  });
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
    setTimeout(async () => {
      try {
        const metricsDoc = await getDoc(doc(db, "settings", "api_metrics"));
        if (metricsDoc.exists()) {
          const savedMetrics = metricsDoc.data();
          Object.keys(apiKeyMetrics).forEach((key) => {
            if (savedMetrics[key]) {
              apiKeyMetrics[key] = { ...apiKeyMetrics[key], ...savedMetrics[key] };
            }
          });
          console.log("[METRICS] Loaded persistent API metrics from Firestore.");
        }
      } catch (err) {
        console.error("[METRICS] Error loading persistent metrics:", err);
      }
      autoHealAllCourses().catch((err) => console.error("Startup auto-heal failed:", err));
    }, 6e4);
    setInterval(async () => {
      try {
        await setDoc(doc(db, "settings", "api_metrics"), apiKeyMetrics);
      } catch (err) {
        console.error("[METRICS] Error persisting metrics:", err);
      }
    }, 12e4);
    setTimeout(() => {
      checkAndTriggerDailyAutoUpload().catch((err) => console.error("Startup daily auto-upload check failed:", err));
    }, 3e4);
    setInterval(() => {
      autoHealAllCourses().catch((err) => console.error("Periodic background auto-heal failed:", err));
    }, 432e5);
    import_node_cron.default.schedule("0 10 * * *", () => {
      checkAndTriggerDailyAutoUpload().catch((err) => console.error("Scheduled daily auto-upload check failed:", err));
    });
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
